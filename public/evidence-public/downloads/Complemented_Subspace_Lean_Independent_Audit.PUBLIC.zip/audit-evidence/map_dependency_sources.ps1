$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
# Hand-selected principal source references; this is not the kernel dependency walker.
# Each declaration location is mechanically checked against the current source.
$requests = @'
RealMainTheorem|realMainTheorem|target theorem
TheoremStatement|RealMainTheoremStatement|target proposition definition
TheoremStatement|HasSeparatedRange|range assertion definition
TheoremStatement|HasRealBanachLatticeOrder|lattice assertion definition
Ambient|BlockParameters|parameter data structure
Ambient|Block|ambient block abbreviation
Ambient|Ambient|ambient sum abbreviation
LocalUnconditional|chiDPR|DPR constant definition
LocalUnconditional|lambdaDPR|local DPR constant definition
LocalUnconditional|unconditionalConstant|finite-basis infimum definition
LocalUnconditional|unconditionalBasisConstant|basis constant definition
LocalUnconditional|chiGL|GL constant definition
LocalUnconditional|lambdaGL|local GL constant definition
LocalUnconditional|GLFactorization|factorization data structure
RecursiveParameters|recursiveFrameSelection|chosen parameter construction
RecursiveParameters|exists_recursiveFrameSelection|parameter-existence proof
RecursiveParameters|exists_nextFrameChoice|private finite-choice existence proof
RecursiveParameters|toBlockParameters|parameter data projection
RecursiveProjection|exists_recursive_alternatingProjection_near_one|direct projection existence proof
RecursiveProjection|exists_recursive_alternatingProjection_tolerance|projection quantitative existence proof
RecursiveProjection|complement_idempotent|direct complementary projection proof
RecursiveProjection|alternatingProjection|diagonal projection definition
RecursiveProjection|alternatingBlockProjection|alternating finite projection definition
ReindexedFrameProjection|exists_recursive_complement_tolerance|complement norm proof
ReindexedFrameProjection|exists_finTensorProjection_complement_threshold|finite complement threshold proof
ReindexedFrameProjection|finTensorProjection_norm_le_exp|finite projection norm proof
ReindexedFrameProjection|blockFrameProjection_norm_le|recursive finite projection norm proof
TensorProjection|tensorFrameProjection_norm_le_exp|tensor projection norm proof
TensorProjection|tensorFrameProjection_clm_idempotent|tensor projection identity proof
LocalHilbertProjection|norm_complement_le_of_localHilbert|local Hilbert complement norm proof
LocalHilbert|exists_localHilbert_subspace_threshold|local Hilbert threshold proof
ActualProjectionDPR|actualProjection_range_chiDPR_eq_top|direct primal range obstruction proof
ActualProjectionDPR|actualProjection_complement_range_chiDPR_eq_top|direct primal complement obstruction proof
ActualProjectionDualDPR|actualProjection_range_dual_chiDPR_eq_top|direct dual range obstruction proof
ActualProjectionDualDPR|actualProjection_complement_range_dual_chiDPR_eq_top|direct dual complement obstruction proof
RecursiveDiagonalDPR|recursiveDiagonalRange_chiDPR_eq_top|recursive primal obstruction proof
RecursiveDiagonalDualDPR|recursiveDiagonalRange_dual_chiDPR_eq_top|recursive dual obstruction proof
FiniteBlockDPRLower|frame_block_le_chiDPR|finite block DPR lower bound proof
FiniteDualDPRLower|frame_product_le_chiDPR_dual|finite dual DPR lower bound proof
FiniteBlockObstruction|finite_basis_obstruction_with_frame_summand|finite basis contradiction proof
FiniteBlockObstruction|finite_basis_obstruction_with_frame_summand_of_scale|scale-specialized finite basis contradiction proof
FiniteProductObstruction|finite_basis_obstruction_of_frame_product|product finite basis contradiction proof
FiniteSelectedHilbertModel|exists_frame_selectedHilbertFactorization|selected Hilbert factorization existence proof
FiniteOverlapObstruction|finite_selected_trace_obstruction|trace overlap contradiction proof
FiniteOverlapObstruction|finite_selected_trace_scale_le|trace overlap upper scale proof
FiniteOverlapObstruction|finite_selected_projection_overlap_le|selected projection overlap proof
FiniteOverlapConclusion|finite_basis_overlap_scaled_bound|overlap estimate proof
ProjectionOverlapLower|frame_trace_forces_projection_overlap|trace-to-overlap proof
FrameCoefficientReindexedRange|frameCoefficientEvenRangeEquiv|even finite range isometry definition
FrameCoefficientReindexedRange|frameCoefficientOddComplementRangeEquiv|odd complementary finite range isometry definition
DiagonalFrameProduct|diagonalFrameProductEquiv|actual diagonal product isometry definition
RecursiveKernelHilbert|recursiveDiagonalRange_kernel_locallyHilbert|primal kernel geometry proof
LocalHilbertRecursiveKernelDual|recursiveDiagonalRange_kernel_dual_subspaces|dual kernel geometry proof
LocalHilbertRecursiveKernelDual|recursiveProfile_embedding_dual_subspaces|dual embedded profile geometry proof
RecursiveHeadHilbert|recursiveProfile_finiteHead_hasHilbertNormWithin|finite head geometry proof
RecursiveHeadHilbert|recursiveProfile_finiteHead_hilbertModel|finite head model existence proof
RecursiveTailHilbert|recursiveProfileTail_locallyHilbert|tail local geometry proof
RecursiveTailHilbert|recursiveProfileTail_approxParallelogram|tail parallelogram proof
ProjectionCorollaries|hasSeparatedRange_of_DPR_obstructions|direct range conclusions assembly proof
ProjectionCorollaries|chiGL_range_le_projection_norm_all|primal GL projection proof including zero range
GLRetraction|chiGL_range_le_projection_norm|primal GL projection proof
GLRetraction|chiGL_le_of_retraction|GL retraction inequality proof
GLRetraction|GLFactorization.throughRetraction|GL factorization construction
GLDualRetraction|chiGL_dual_range_le_projection_norm|dual GL projection proof
GLDualRetraction|chiGL_dual_le_of_retraction|dual GL retraction inequality proof
GLDualRetraction|dualPullback|dual retraction map definition
AmbientFiniteApproximation|ambient_chiGL_le_one|direct ambient GL proof
AmbientFiniteApproximation|ambientDual_chiGL_le_one|direct ambient dual GL proof
AmbientFiniteApproximation|ambient_hasFiniteUnconditionalApproximations|ambient finite approximation proof
AmbientFiniteApproximation|ambientDual_chiDPR_le_one|ambient dual DPR upper bound proof
DPRtoGL|chiGL_le_chiDPR|DPR-to-GL comparison proof
FiniteApproximation|chiDPR_le_constant_of_finite_approximations|finite approximation to DPR proof
LatticeApproximation|chiDPR_dual_lattice_le_one|dual lattice DPR bound proof
LatticeApproximation|hasFiniteUnconditionalApproximations_dual|dual lattice approximation proof
LatticeApproximation|hasFiniteUnconditionalApproximations_of_principalProjectionProperty|lattice spectral approximation proof
AmbientSeparable|ambientSeparableSpace|direct synthesized separability proof instance
AmbientUniformConvex|ambientUniformConvexSpace|direct synthesized uniform convexity proof instance
AmbientUniformConvex|block_hasCubicSumModulus|finite block modulus proof
LpTwoUniformConvex|lp_two_uniformConvexSpace_of_cubicModulus|sum uniform convexity proof
FiniteLpGeometry|finitePiLp_uniform_modulus|finite lp modulus proof
FiniteLpGeometry|finitePiLp_clarkson|finite lp Clarkson inequality proof
AmbientLattice|ambient_hasRealBanachLatticeOrder|direct ambient lattice proof
AmbientLattice|piLpLattice|finite lattice structure instance
AmbientLattice|lpLattice|sum lattice structure instance
AmbientLattice|lpHasSolidNorm|sum solid norm proof instance
'@
$result = foreach ($entry in ($requests -split '\r?\n')) {
    $parts = $entry.Split('|')
    $relativePath = 'ComplementedSubspace/' + $parts[0] + '.lean'
    $sourcePath = Join-Path $projectRoot $relativePath
    $symbol = $parts[1]
    $pattern = '^\s*(?:private\s+|noncomputable\s+|protected\s+)*(?:@\[[^\]]+\]\s*)?(?:theorem|lemma|def|abbrev|structure|class|instance)\s+' + [regex]::Escape($symbol) + '(?=$|\s|[({:\[])'
    $found = @(Select-String -LiteralPath $sourcePath -Pattern $pattern -CaseSensitive)
    if ($found.Count -ne 1) { throw ('Expected one source declaration for ' + $entry + ', found ' + $found.Count) }
    [ordered]@{
        file = $relativePath
        absolute_file = $sourcePath
        source_symbol = $symbol
        line = $found[0].LineNumber
        role = $parts[2]
        declaration_start = $found[0].Line.Trim()
        source_sha256 = (Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash
    }
}
$outputPath = Join-Path $PSScriptRoot 'dependency_source_map.json'
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $outputPath -Encoding utf8
Write-Output ('Mapped ' + $result.Count + ' declarations to checked source lines in ' + $outputPath)
