"""Read-only graph review; writes only a compact audit-result JSON beside itself."""
from collections import Counter
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
summary = json.loads((root / "kernel_dependency_summary.json").read_text(encoding="utf-8-sig"))
nodes = [json.loads(line) for line in (root / "dependency_nodes.jsonl").read_text(encoding="utf-8-sig").splitlines()]
direct = [json.loads(line) for line in (root / "dependency_direct.jsonl").read_text(encoding="utf-8-sig").splitlines()]
source_map = json.loads((root / "dependency_source_map.json").read_text(encoding="utf-8-sig"))
local = [node for node in nodes if node.get("project_owned")]
private_local = [node for node in local if node["name"].startswith("_private.")]
origins = sorted({node["origin_module"] for node in local})
source_matches = []
for entry in source_map:
    assert hashlib.sha256(Path(entry["absolute_file"]).read_bytes()).hexdigest().lower() == entry["source_sha256"].lower()
    module = entry["file"].removesuffix(".lean").replace("/", ".")
    symbol = entry["source_symbol"]
    matches = [node["name"] for node in local
               if node["origin_module"] == module and
               (node["name"] == symbol or node["name"].endswith("." + symbol))]
    source_matches.append({"module": module, "symbol": symbol, "role": entry["role"],
                           "kernel_names": matches})
edge_count = 0
edge_kinds = Counter()
with (root / "dependency_edges.jsonl").open(encoding="utf-8-sig") as stream:
    for line in stream:
        row = json.loads(line)
        edge_count += 1
        edge_kinds[row["edge_kind"]] += 1
result = {
    "review_scope": "Independent parsing of final raw node/direct/edge JSONL and source-map membership, without Lean execution",
    "node_count": len(nodes),
    "unique_node_count": len({node["name"] for node in nodes}),
    "project_node_count": len(local),
    "project_private_name_count": len(private_local),
    "project_origin_module_count": len(origins),
    "project_origin_module_counts_by_library": dict(Counter(name.split(".")[0] for name in origins)),
    "project_nodes_by_kind": dict(Counter(node["kind"] for node in local)),
    "project_nodes_by_module": dict(sorted(Counter(node["origin_module"] for node in local).items())),
    "project_private_names": [node["name"] for node in private_local],
    "raw_edge_count": edge_count,
    "raw_edge_counts_by_kind": dict(edge_kinds),
    "direct_edge_count": len(direct),
    "direct_unique_names": len({row["to"] for row in direct}),
    "direct_project_edge_count": sum(row["project_owned"] for row in direct),
    "direct_project_references": [row for row in direct if row["project_owned"]],
    "source_map_entries": len(source_matches),
    "source_map_entries_found": sum(bool(row["kernel_names"]) for row in source_matches),
    "source_map_entries_not_found": [row for row in source_matches if not row["kernel_names"]],
    "source_map_kernel_matches": source_matches,
    "raw_axiom_names": sorted(node["name"] for node in nodes if node.get("kind") == "axiom"),
    "raw_local_suspicious": [node for node in local if node["kind"] in {"axiom", "opaque"} or node["unsafe"] or node["partial"]],
}
assert result["node_count"] == result["unique_node_count"] == summary["checked_constants"] == summary["processed_nodes"]
assert result["project_node_count"] == summary["project_constants"]
assert result["raw_edge_count"] == summary["edges"]
assert set(origins) == set(summary["project_origin_modules"])
assert set(result["raw_axiom_names"]) == set(summary["reachable_axioms_direct_traversal"]) == set(summary["reachable_axioms_stock_collectAxioms"])
assert result["raw_local_suspicious"] == summary["reachable_project_axiom_opaque_unsafe_partial"] == []
assert summary["traversal_complete"] and summary["ownership_classification_complete"] and summary["axiom_cross_check_agrees"]
assert summary["missing_checked_constants"] == summary["missing_expected_bodies"] == summary["constants_without_import_origin"] == []
result["summary_consistency_checks"] = "PASS"
result["mapped_source_hash_checks"] = "PASS"
(root / "dependency_graph_review.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
small = {key: value for key, value in result.items() if key not in {
    "project_nodes_by_module", "project_private_names", "source_map_kernel_matches", "direct_project_references"}}
print(json.dumps(small, ensure_ascii=False, indent=2))
print("DIRECT PROJECT REFERENCES")
for row in result["direct_project_references"]:
    print(row["edge_kind"], row["kind"], row["to"], "[" + row["origin_module"] + "]")
