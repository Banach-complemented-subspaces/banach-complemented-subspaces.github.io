"""Read-only source/environment audit; writes only its own audit evidence files."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent.parent
RUNTIME = PROJECT.parent.parent / "tmp/lean_library_definition_audit_2026-09-05/lean-4.34.0-rc2-windows/bin"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
ARCHIVE = PROJECT.parent / "Complemented_Subspace_Lean_Verified.zip"
CONFIG_NAMES = {"lean-toolchain", "lakefile.toml", "lakefile.lean", "lake-manifest.json"}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def archive_report():
    before = sha256(ARCHIVE.read_bytes())
    rows = []
    source_names = set()
    all_names = set()
    with zipfile.ZipFile(ARCHIVE, "r") as archive:
        entries = [entry for entry in archive.infolist() if not entry.is_dir()]
        crc_bad_entry = archive.testzip()
        entry_names = [entry.filename for entry in entries]
        duplicate_entries = sorted({name for name in entry_names if entry_names.count(name) > 1})
        roots = sorted({entry.filename.split("/")[0] for entry in entries})
        if roots != ["Complemented_Subspace_Lean_Verified"]:
            raise RuntimeError(f"Unexpected archive roots: {roots}")
        for entry in entries:
            name = entry.filename.split("/", 1)[1]
            relative = Path(name)
            if relative.is_absolute() or ".." in relative.parts:
                raise RuntimeError(f"Unsafe archive path: {name}")
            current = PROJECT / relative
            archived = archive.read(entry)
            archived_hash = sha256(archived)
            is_source = relative.suffix == ".lean" or relative.name in CONFIG_NAMES
            all_names.add(name)
            if is_source:
                source_names.add(name)
            current_hash = sha256(current.read_bytes()) if current.is_file() else None
            rows.append({"relative_path": name, "source_or_config": is_source,
                         "archived_bytes": len(archived), "archive_sha256": archived_hash,
                         "workspace_sha256": current_hash,
                         "status": "MATCH" if archived_hash == current_hash else
                                   "MISSING" if current_hash is None else "DIFFERENT"})
        manifest_lines = archive.read("Complemented_Subspace_Lean_Verified/SOURCE-MANIFEST.sha256").decode("utf-8-sig").splitlines()
        internal_manifest_rows = []
        for line in manifest_lines:
            match = re.fullmatch(r"([0-9a-fA-F]{64})  (.+)", line)
            if not match:
                raise RuntimeError(f"Unrecognized SOURCE-MANIFEST line: {line!r}")
            expected, name = match.groups()
            actual = sha256(archive.read("Complemented_Subspace_Lean_Verified/" + name))
            internal_manifest_rows.append({"relative_path": name, "expected_sha256": expected.lower(),
                                           "actual_sha256": actual, "matches": expected.lower() == actual})
    extras = []
    for current_dir, directories, files in os.walk(PROJECT):
        directories[:] = [name for name in directories if name not in {".lake", ".cache", ".git"}]
        for name in files:
            path = Path(current_dir) / name
            relative = path.relative_to(PROJECT).as_posix()
            if (path.suffix == ".lean" or path.name in CONFIG_NAMES) and relative not in source_names:
                extras.append(relative)
    after = sha256(ARCHIVE.read_bytes())
    report = {"archive": str(ARCHIVE), "archive_bytes": ARCHIVE.stat().st_size,
              "archive_sha256_before": before, "archive_sha256_after": after,
              "archive_unchanged_during_comparison": before == after,
              "zip_crc_bad_entry": crc_bad_entry,
              "duplicate_archive_entries": duplicate_entries,
              "comparison_method": "SHA256 of complete decompressed ZIP entry bytes versus complete workspace file bytes; no normalization",
              "archive_file_count": len(rows), "source_or_config_count": len(source_names),
              "source_or_config_matches": sum(r["source_or_config"] and r["status"] == "MATCH" for r in rows),
              "source_or_config_discrepancies": [r for r in rows if r["source_or_config"] and r["status"] != "MATCH"],
              "internal_manifest_entry_count": len(internal_manifest_rows),
              "internal_manifest_matches": sum(r["matches"] for r in internal_manifest_rows),
              "internal_manifest_discrepancies": [r for r in internal_manifest_rows if not r["matches"]],
              "archive_paths_not_covered_by_internal_manifest": sorted(all_names - {r["relative_path"] for r in internal_manifest_rows}),
              "other_file_discrepancies": [r for r in rows if not r["source_or_config"] and r["status"] != "MATCH"],
              "workspace_extra_source_or_config_files": sorted(extras),
              "extra_scan_excluded_directories": [".lake", ".cache", ".git"],
              "files": rows}
    print(json.dumps(report, indent=2))
    return 0 if before == after and not report["source_or_config_discrepancies"] and not report["internal_manifest_discrepancies"] and not crc_bad_entry and not duplicate_entries else 1


def run(log, argv, cwd=PROJECT):
    argv = [str(arg) for arg in argv]
    log.write("\nCOMMAND (Windows command-line syntax): " + subprocess.list2cmdline(argv) + "\n")
    log.write("ARGUMENTS (JSON): " + json.dumps(argv) + "\n")
    log.write("WORKING DIRECTORY: " + str(cwd) + "\n")
    log.flush()
    result = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    stdout = result.stdout.decode("utf-8", errors="backslashreplace")
    stderr = result.stderr.decode("utf-8", errors="backslashreplace")
    log.write("STDOUT BEGIN\n" + stdout + ("" if stdout.endswith("\n") else "\n") + "STDOUT END\n")
    log.write("STDERR BEGIN\n" + stderr + ("" if stderr.endswith("\n") else "\n") + "STDERR END\n")
    log.write("EXIT CODE: " + str(result.returncode) + "\n")
    log.flush()
    return result.returncode, stdout, stderr


def git(log, directory, *args):
    return run(log, [GIT, "-C", directory, *args])


def open_log(name):
    log = (HERE / name).open("w", encoding="utf-8", newline="\n")
    log.write("INDEPENDENT ENVIRONMENT/SOURCE AUDIT\n")
    log.write("UTC started: " + datetime.datetime.now(datetime.timezone.utc).isoformat() + "\n")
    log.write("Collector: " + str(Path(__file__).resolve()) + "\n")
    log.write("Collector SHA256: " + sha256(Path(__file__).read_bytes()) + "\n")
    log.write("No Lean compilation or build is performed by this collector.\n")
    return log


def main():
    with open_log("environment.txt") as log:
        run(log, [GIT, "--version"])
        run(log, [sys.executable, "--version"])
        run(log, [sys.executable, "-c", "import platform,sys; print(platform.platform()); print('python_executable:',sys.executable)"])
        run(log, [RUNTIME / "lean.exe", "--version"])
        run(log, [RUNTIME / "lake.exe", "--version"])
        run(log, [sys.executable, "-c", "import hashlib,pathlib; root=pathlib.Path(r'" + str(RUNTIME) + "'); [(print(str(root/n),hashlib.sha256((root/n).read_bytes()).hexdigest())) for n in ['lean.exe','lake.exe']]"])
        for name in ["lean-toolchain", "lakefile.toml", "lake-manifest.json"]:
            run(log, [sys.executable, "-c", "import pathlib,sys; sys.stdout.buffer.write(pathlib.Path(sys.argv[1]).read_bytes())", PROJECT / name])
        run(log, [sys.executable, "-c", "import os,json; print(json.dumps({k:os.environ.get(k) for k in ['LEAN_PATH','LEAN_SRC_PATH','LEAN_SYSROOT','LAKE_HOME','ELAN_HOME']},indent=2))"])
        log.write("\nThe absolute portable runtime above was queried directly; this does not claim a globally installed Lean or Lake.\n")

    with open_log("git_status.txt") as log:
        git(log, PROJECT, "rev-parse", "--show-toplevel")
        head_code, head_output, _ = git(log, PROJECT, "rev-parse", "--verify", "HEAD")
        git(log, PROJECT, "symbolic-ref", "HEAD")
        git(log, PROJECT, "status", "--porcelain=v1", "--untracked-files=normal")
        git(log, PROJECT, "status", "--short", "--untracked-files=normal", "--", ".")
        git(log, PROJECT, "ls-files", "--", ".")
        if head_code:
            log.write("\nRESULT: Enclosing repository HEAD does not resolve to a commit. No project commit hash is available; workspace source has no committed comparison baseline here. The nonempty status above is untracked/dirty.\n")
        else:
            log.write("\nRESULT: Enclosing repository commit: " + head_output.strip() + "\n")

    manifest = json.loads((PROJECT / "lake-manifest.json").read_text(encoding="utf-8"))
    summaries = []
    with open_log("dependency_provenance.txt") as log:
        log.write("Dependency source provenance is inspected separately from reused dependency build caches. Git comparisons below compare source checkouts to their own recorded HEAD; no dependency cache was rebuilt or authenticated as part of this collector.\n")
        for package in manifest["packages"]:
            name = package["name"]
            directory = PROJECT / manifest["packagesDir"] / name
            log.write("\nDEPENDENCY: " + name + "\nMANIFEST URL: " + package["url"] + "\nMANIFEST REV: " + package["rev"] + "\n")
            top_code, top_output, _ = git(log, directory, "rev-parse", "--show-toplevel")
            head_code, head_output, _ = git(log, directory, "rev-parse", "--verify", "HEAD")
            git(log, directory, "remote", "get-url", "origin")
            status_code, status, _ = git(log, directory, "status", "--porcelain=v1", "--untracked-files=all")
            git(log, directory, "diff", "--no-ext-diff", "--name-status", "HEAD", "--")
            changed_code, changed, _ = git(log, directory, "diff", "--no-ext-diff", "--name-only", "HEAD", "--", "*.lean")
            new_code, new, _ = git(log, directory, "ls-files", "--others", "--exclude-standard", "--", "*.lean")
            git(log, directory, "diff", "--no-ext-diff", "HEAD", "--", "lakefile.lean", "lakefile.toml", "lean-toolchain", "lake-manifest.json")
            source_differences = [p for p in changed.splitlines() if Path(p).name != "lakefile.lean"]
            untracked_lean = [p for p in new.splitlines() if Path(p).name != "lakefile.lean"]
            own_repo = top_code == 0 and os.path.normcase(os.path.abspath(top_output.strip())) == os.path.normcase(str(directory.resolve()))
            item = {"name": name, "manifest_rev": package["rev"], "actual_head": head_output.strip() if head_code == 0 else None,
                    "head_matches_pin": head_code == 0 and head_output.strip() == package["rev"],
                    "own_git_repository": own_repo,
                    "status_nonempty": bool(status.strip()), "status_exit_code": status_code,
                    "changed_tracked_lean_except_lakefile": source_differences,
                    "untracked_lean_except_lakefile": untracked_lean,
                    "source_check_exit_codes": [changed_code, new_code]}
            summaries.append(item)
            log.write("\nDEPENDENCY SUMMARY: " + json.dumps(item, indent=2) + "\n")
        log.write("\nALL DEPENDENCY SUMMARIES:\n" + json.dumps(summaries, indent=2) + "\n")
        log.write("\nARCHIVE COMPARISON (complete per-file SHA256 evidence follows):\n")
        archive_code, archive_output, _ = run(log, [sys.executable, Path(__file__).resolve(), "--archive-report"])
        (HERE / "archive_comparison.json").write_text(archive_output, encoding="utf-8")
    (HERE / "dependency_summary.json").write_text(json.dumps(summaries, indent=2) + "\n", encoding="utf-8")
    archive = json.loads(archive_output)
    print(json.dumps({"dependency_summary": summaries,
                      "archive_sha256": archive["archive_sha256_before"],
                      "archive_source_config_count": archive["source_or_config_count"],
                      "archive_source_config_matches": archive["source_or_config_matches"],
                      "archive_source_config_discrepancies": archive["source_or_config_discrepancies"],
                      "archive_other_discrepancies": archive["other_file_discrepancies"],
                      "archive_comparison_exit_code": archive_code}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(archive_report() if sys.argv[1:] == ["--archive-report"] else main())
