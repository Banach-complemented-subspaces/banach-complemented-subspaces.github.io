param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$auditExtraDir = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$auditExtraProject = (Resolve-Path -LiteralPath (Join-Path $auditExtraDir '../..')).Path
$auditExtraRuntime = (Resolve-Path -LiteralPath (Join-Path $auditExtraProject '../../tmp/lean_library_definition_audit_2026-09-05/lean-4.34.0-rc2-windows/bin')).Path
$auditExtraLake = Join-Path $auditExtraRuntime 'lake.exe'
$auditExtraOldPath = $env:Path
$auditExtraOldThreads = $env:LEAN_NUM_THREADS
$auditExtraOldCache = $env:MATHLIB_CACHE_DIR
$auditExtraMutex = [Threading.Mutex]::new($false, 'Local\Codex_ComplementedSubspace_Lean_20260905')
$auditExtraHeld = $false
$auditExtraExit = 1
$auditExtraStatePath = Join-Path $auditExtraDir 'additional_build_status.json'
$auditExtraState = @{ status = 'initializing'; sourceUnchanged = $false }

function Save-AdditionalState {
    $auditExtraState | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $auditExtraStatePath -Encoding utf8
}

function Assert-OriginalSourcesUnchanged {
    $auditExtraBaseline = @(Get-Content -LiteralPath (Join-Path $auditExtraDir 'source_hashes_before.json') -Raw | ConvertFrom-Json)
    $auditExtraCurrentPaths = @(& rg --files --hidden --no-ignore -g '*.lean' -g '!.lake/**' -g '!.cache/**' -g '!verification/independent-audit-2026-09-05/**')
    if ($LASTEXITCODE -ne 0) { throw 'Could not enumerate original local Lean files.' }
    $auditExtraCurrentPaths += @('lakefile.toml', 'lake-manifest.json', 'lean-toolchain')
    $auditExtraCurrentPaths = @($auditExtraCurrentPaths | ForEach-Object { $_.Replace('\', '/') } | Sort-Object -Unique)
    $auditExtraBaselinePaths = @($auditExtraBaseline | ForEach-Object { $_.path.Replace('\', '/') } | Sort-Object -Unique)
    if (@(Compare-Object $auditExtraCurrentPaths $auditExtraBaselinePaths).Count -ne 0) { throw 'Original source inventory changed.' }
    foreach ($auditExtraEntry in $auditExtraBaseline) {
        $auditExtraFile = Join-Path $auditExtraProject $auditExtraEntry.path
        $auditExtraHash = (Get-FileHash -LiteralPath $auditExtraFile -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($auditExtraHash -ne $auditExtraEntry.sha256 -or (Get-Item -LiteralPath $auditExtraFile).Length -ne $auditExtraEntry.bytes) {
            throw "Original source changed: $($auditExtraEntry.path)"
        }
    }
    return $auditExtraBaseline.Count
}

if (Test-Path -LiteralPath $auditExtraStatePath) { throw 'Supplemental run evidence already exists; preserve it before any explicit retry.' }
try {
    $auditExtraCore = Get-Content -LiteralPath (Join-Path $auditExtraDir 'run_status.json') -Raw | ConvertFrom-Json
    if ($auditExtraCore.status -ne 'passed') { throw 'Core clean build and compiler audit have not passed; do not run concurrently.' }
    try { $auditExtraHeld = $auditExtraMutex.WaitOne() }
    catch [Threading.AbandonedMutexException] { $auditExtraHeld = $true }
    $env:Path = $auditExtraRuntime + ';' + $env:Path
    $env:LEAN_NUM_THREADS = '2'
    $env:MATHLIB_CACHE_DIR = Join-Path $auditExtraProject '.cache/mathlib'
    Push-Location -LiteralPath $auditExtraProject
    try {
        $auditExtraSourceCount = Assert-OriginalSourcesUnchanged
        $auditExtraScope = Get-Content -LiteralPath (Join-Path $auditExtraDir 'build_scope.json') -Raw | ConvertFrom-Json
        $auditExtraTargets = @($auditExtraScope.extra_olean_targets)
        if ($auditExtraTargets.Count -ne $auditExtraScope.omitted_library_module_count -or $auditExtraTargets.Count -eq 0) { throw 'Invalid supplemental target count.' }
        foreach ($auditExtraTarget in $auditExtraTargets) {
            if ($auditExtraTarget -notmatch '^\+ComplementedSubspace\.[A-Za-z0-9_.]+:olean$') { throw 'Invalid supplemental module target.' }
        }
        $auditExtraArguments = @('--no-cache', 'build') + $auditExtraTargets
        $auditExtraQuoted = @($auditExtraArguments | ForEach-Object { "'" + $_.Replace("'", "''") + "'" })
        $auditExtraCommand = "& '" + $auditExtraLake.Replace("'", "''") + "' " + ($auditExtraQuoted -join ' ')
        $auditExtraLog = Join-Path $auditExtraDir 'additional_modules_build.log'
        $auditExtraState = @{
            status = 'running'; command = $auditExtraCommand; arguments = $auditExtraArguments
            log = 'additional_modules_build.log'; startedUtc = [DateTime]::UtcNow.ToString('o')
            sourceUnchanged = $false; moduleCount = $auditExtraTargets.Count
            sourceValidationLog = 'additional_source_unchanged.txt'
        }
        Save-AdditionalState
        @("WORKING DIRECTORY: $auditExtraProject", "START UTC: $($auditExtraState.startedUtc)", "COMMAND: $auditExtraCommand", 'TERMINAL OUTPUT:') |
            Set-Content -LiteralPath $auditExtraLog -Encoding utf8
        Write-Output $auditExtraCommand
        & $auditExtraLake @auditExtraArguments 2>&1 | Tee-Object -FilePath $auditExtraLog -Append
        $auditExtraBuildExit = $LASTEXITCODE
        $auditExtraState.exitCode = $auditExtraBuildExit
        $auditExtraState.finishedUtc = [DateTime]::UtcNow.ToString('o')
        @("EXIT CODE: $auditExtraBuildExit", "END UTC: $($auditExtraState.finishedUtc)") | Tee-Object -FilePath $auditExtraLog -Append
        $auditExtraSourceCount = Assert-OriginalSourcesUnchanged
        $auditExtraState.sourceUnchanged = $true
        "PASS: all $auditExtraSourceCount original local Lean/configuration files still match the initial SHA256 snapshot; no mathematical source was altered." |
            Set-Content -LiteralPath (Join-Path $auditExtraDir 'additional_source_unchanged.txt') -Encoding utf8
        if ($auditExtraBuildExit -ne 0) { throw "Supplemental build failed with exit code $auditExtraBuildExit. Mathematical source has not been altered." }
        $auditExtraState.status = 'passed'
        Save-AdditionalState
        $auditExtraExit = 0
    } finally { Pop-Location }
} catch {
    $auditExtraState.status = 'failed'
    $auditExtraState.failure = $_.Exception.Message
    Save-AdditionalState
    "SUPPLEMENTAL AUDIT FAILURE: $($_.Exception.Message)" | Tee-Object -FilePath (Join-Path $auditExtraDir 'additional_build_failure.txt')
} finally {
    $env:Path = $auditExtraOldPath
    $env:LEAN_NUM_THREADS = $auditExtraOldThreads
    $env:MATHLIB_CACHE_DIR = $auditExtraOldCache
    if ($auditExtraHeld) { $auditExtraMutex.ReleaseMutex() }
    $auditExtraMutex.Dispose()
}
exit $auditExtraExit
