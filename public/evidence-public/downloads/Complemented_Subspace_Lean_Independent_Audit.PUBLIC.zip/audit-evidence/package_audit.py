"""Package a completed independent Lean audit. Never runs Lean or changes evidence.

Invoke ONLY after all compiler checks, the final scanner refresh, and final report:
  python package_audit.py --report Final_Audit_Report.md

The report must be inside this evidence directory and contain an explicit line
`Final result: PASS` (Markdown emphasis is accepted). This script deliberately
fails while the audit is pending, unsuccessful, stale, or missing its report.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import uuid
import zipfile

EVIDENCE = Path(__file__).resolve().parent
PROJECT = EVIDENCE.parent.parent
ARCHIVE = PROJECT.parent / "Complemented_Subspace_Lean_Independent_Audit.zip"
RESULT = EVIDENCE / "packaging_result.json"
SUMMARY = EVIDENCE / "packaging_summary.txt"
MANIFEST_NAME = "SHA256SUMS.txt"
EXPECTED_SOURCE_COUNT = 233
BLOCK = 1024 * 1024
REQUIRED_CORE_STEPS = {
    "clean", "build", "direct main source check", "theorem identity",
    "exact definitions", "axioms", "whole imported project axiom audit",
    "kernel dependency traversal",
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest_file(path):
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as source:
        while block := source.read(BLOCK):
            digest.update(block)
            size += len(block)
    return digest.hexdigest(), size


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def safe_relative(value):
    require(isinstance(value, str) and value, "Empty/non-string relative path.")
    require("\\" not in value and "\n" not in value and "\r" not in value and ":" not in value,
            f"Unsafe or noncanonical relative path: {value!r}")
    rel = PurePosixPath(value)
    require(not rel.is_absolute() and all(p not in {"", ".", ".."} for p in value.split("/")),
            f"Unsafe relative path: {value!r}")
    return rel


def contained_file(base, relative):
    rel = safe_relative(relative)
    path = base.joinpath(*rel.parts)
    require(path.is_file(), f"Required file is missing: {path}")
    require(path.resolve().is_relative_to(base.resolve()), f"File escapes intended root: {path}")
    current = path
    while current != base:
        require(not current.is_symlink() and not current.is_junction(), f"Reparse link is not accepted: {current}")
        current = current.parent
    return path


def source_snapshot(path):
    raw = load_json(path)
    require(isinstance(raw, list), f"Snapshot must be an array: {path.name}")
    snapshot = {}
    casefolded = set()
    for row in raw:
        name = row.get("path")
        safe_relative(name)
        require(name not in snapshot and name.casefold() not in casefolded, f"Duplicate snapshot path: {name}")
        sha = row.get("sha256")
        size = row.get("bytes")
        require(isinstance(sha, str) and re.fullmatch(r"[0-9a-f]{64}", sha), f"Invalid SHA256 for {name}")
        require(type(size) is int and size >= 0, f"Invalid file size for {name}")
        snapshot[name] = {"sha256": sha, "bytes": size}
        casefolded.add(name.casefold())
    return snapshot


def local_lean_paths():
    found = set()
    for current, directories, names in os.walk(PROJECT, followlinks=False):
        here = Path(current)
        for name in list(directories):
            path = here / name
            if here.name == ".lake" and name in {"packages", "build"}:
                directories.remove(name)
            else:
                require(not path.is_symlink() and not path.is_junction(), f"Unscanned source directory link: {path}")
        for name in names:
            if name.lower().endswith(".lean"):
                found.add((here / name).relative_to(PROJECT).as_posix())
    return found


def skip_evidence(relative):
    path = PurePosixPath(relative)
    if "__pycache__" in path.parts:
        return "Python bytecode cache"
    if path.name in {"SHA256SUMS", "SHA256SUMS.txt", "ARCHIVE_MANIFEST.json", "archive_manifest.json"}:
        return "Previous generated archive manifest; regenerated internally"
    if path.suffix.lower() in {".json", ".txt", ".log", ".sha256"} and path.name.lower().startswith(("packaging_", "package_audit_")):
        return "Packaging output excluded to avoid self-reference"
    if path.name in {"packaging.log", "package_audit.log", ARCHIVE.name} or path.name.startswith(ARCHIVE.name + ".partial-"):
        return "Packaging output excluded to avoid self-reference"
    return None


def evidence_files():
    files = {}
    excluded = []
    for current, directories, names in os.walk(EVIDENCE, followlinks=False):
        here = Path(current)
        for name in list(directories):
            path = here / name
            rel = path.relative_to(EVIDENCE).as_posix()
            if name == "__pycache__":
                directories.remove(name)
                excluded.append({"path": rel + "/", "reason": "Python bytecode cache"})
            else:
                require(not path.is_symlink() and not path.is_junction(), f"Evidence directory link is not accepted: {path}")
        for name in names:
            path = here / name
            rel = path.relative_to(EVIDENCE).as_posix()
            reason = skip_evidence(rel)
            if reason:
                excluded.append({"path": rel, "reason": reason})
            else:
                files[rel] = contained_file(EVIDENCE, rel)
    return files, sorted(excluded, key=lambda x: x["path"])


def validate_gates(report_path):
    status = load_json(EVIDENCE / "run_status.json")
    require(status.get("status") == "passed", "Core compiler audit has not passed (run_status.json).")
    commands = status.get("commands", [])
    require(isinstance(commands, list) and commands, "Core compiler command log is missing.")
    require(all(type(c.get("exitCode")) is int and c["exitCode"] == 0 for c in commands), "A core compiler command did not exit zero.")
    recorded_steps = {c.get("step") for c in commands}
    require(REQUIRED_CORE_STEPS <= recorded_steps, f"Missing core compiler steps: {sorted(REQUIRED_CORE_STEPS - recorded_steps)}")
    additional = load_json(EVIDENCE / "additional_build_status.json")
    require(additional.get("status") == "passed", "Additional module build has not passed.")
    require(type(additional.get("exitCode")) is int and additional["exitCode"] == 0,
            "Additional module build did not record exitCode: 0.")
    require(additional.get("sourceUnchanged") is True, "Additional module build did not confirm source immutability.")
    scope = load_json(EVIDENCE / "build_scope.json")
    require(additional.get("moduleCount") == scope.get("omitted_library_module_count") == 16,
            "Additional module build does not cover the expected 16 omitted library modules.")
    report_text = report_path.read_text(encoding="utf-8-sig")
    normalized_lines = [re.sub(r"[*_`#]", "", line).strip() for line in report_text.splitlines()]
    require(any(re.fullmatch(r"Final\s+result\s*:\s*PASS[.]?", line, flags=re.IGNORECASE) for line in normalized_lines),
            "Final report lacks the explicit line 'Final result: PASS'.")
    require(not any(re.fullmatch(r"Final\s+result\s*:\s*(?:FAIL|FAILED|PENDING|INCOMPLETE|BLOCKED)[.]?", line, flags=re.IGNORECASE) for line in normalized_lines),
            "Final report contains a conflicting final result.")
    before = source_snapshot(EVIDENCE / "source_hashes_before.json")
    after = source_snapshot(EVIDENCE / "source_hashes_after.json")
    require(len(before) == EXPECTED_SOURCE_COUNT, f"Expected {EXPECTED_SOURCE_COUNT} original source/config files; got {len(before)}.")
    require(before == after, "Before/after source snapshots differ.")
    require({"lakefile.toml", "lake-manifest.json", "lean-toolchain"} <= before.keys(), "Pinned configuration missing from snapshot.")
    all_current_lean = local_lean_paths()
    original_current_lean = {name for name in all_current_lean if not name.startswith("verification/independent-audit-2026-09-05/")}
    require(original_current_lean == {name for name in before if name.lower().endswith(".lean")},
            "Original local Lean source inventory changed after the compiler snapshots.")
    for name, record in before.items():
        sha, size = digest_file(contained_file(PROJECT, name))
        require(sha == record["sha256"] and size == record["bytes"], f"Current original source differs from snapshot: {name}")
    scan = load_json(EVIDENCE / "placeholder_scan.json")
    require(scan.get("self_test", "").startswith("PASS:"), "Placeholder scanner self-test has not passed.")
    require(scan.get("independent_rg_inventory_agrees") is True, "Independent scanner inventories do not agree.")
    require(scan.get("lexical_and_import_errors") == [], "Placeholder scanner has lexical/import errors.")
    require(scan.get("source_placeholder_or_trust_hazards") == [], "Placeholder scanner reports executable hazards.")
    require(scan.get("stability_check", {}).get("changed_or_removed_during_scan") == [], "Placeholder source snapshot was unstable.")
    scanned = scan.get("inventory", [])
    require(isinstance(scanned, list) and scanned, "Scanner inventory is missing.")
    scanned_paths = [item.get("file") for item in scanned]
    require(len(set(scanned_paths)) == len(scanned_paths), "Scanner inventory has duplicate paths.")
    require(set(scanned_paths) == all_current_lean, "Scanner inventory is stale; rerun placeholder_scan.py after final Lean audit edits.")
    for item in scanned:
        sha, size = digest_file(contained_file(PROJECT, item["file"]))
        require(sha == item["sha256"] and size == item["bytes"], f"Scanner snapshot is stale: {item['file']}; rerun placeholder_scan.py.")
    return before, status, additional


def readme(report_relative, source_count, evidence_count, excluded):
    toolchain = (PROJECT / "lean-toolchain").read_text(encoding="utf-8-sig").strip()
    manifest = load_json(PROJECT / "lake-manifest.json")
    dependencies = "\n".join(f"- {p['name']}: `{p['rev']}` from {p['url']}" for p in manifest["packages"])
    exclusions = "\n".join(f"- `{row['path']}`: {row['reason']}" for row in excluded) or "- No packaging outputs or bytecode caches were present."
    return f"""# Independent Lean audit evidence

Final result: PASS

Read `audit-evidence/{report_relative}` for the final findings and limits. This
archive contains {source_count} original Lean/configuration files under
`audited-source/` and {evidence_count} evidence files under `audit-evidence/`.
The source paths are preserved. Mathematical source bytes match both the before
and after audit snapshots. This is a mechanical Lean audit, with no claim of
faithfulness to a manuscript.

## Integrity

`SHA256SUMS.txt` lists every other ZIP member, including this README. Its own hash
is intentionally omitted because a manifest cannot contain its own final hash.
Packaging verified every member against that manifest and checked all ZIP CRCs.
The archive's size and SHA-256 are in the separately delivered
`packaging_result.json`; that file is excluded from the archive to avoid recursion.

## Reproduce

1. Extract to a fresh directory. Treat `audited-source/` as the project root.
   Preserve `audit-evidence/` untouched. Copy its audit scripts (`.lean`, `.ps1`,
   `.py`) and `build_scope.json` to a new
   `audited-source/verification/independent-audit-2026-09-05/` directory. Keep
   the supplied output/status files separately: the runners produce fresh
   evidence, and the supplemental runner requires no existing supplemental status.
2. Install the exact toolchain `{toolchain}`. The recorded compiler was Lean
   4.34.0-rc2, commit `6a10ac8c22beadecabdbb0919c2b50214762f91d`; compiler and Lake
   executable hashes and versions are in `environment.txt`.
3. Restore/check out each external dependency at the commit in the unchanged
   `lake-manifest.json`. The toolchain and external dependency trees/caches are
   not bundled. Matching dependency build caches may be restored, or dependencies
   may be built from these pinned sources. `dependency_provenance.txt` records the
   actual local dependency checkout state used in the recorded audit.
4. In the copied audit scripts, adjust machine-specific runtime/provenance paths
   to your installation. `run_independent_audit.ps1` and
   `run_additional_modules.ps1` need the Lean/Lake runtime path;
   `TraceDependencies.lean` has an explicit `outputDirectory` string;
   `placeholder_scan.py` locates the pinned Lean source distribution for option
   evidence; provenance/source-map helpers retain the original workspace and
   archive paths. Change these audit-only path settings, keeping the original
   mathematical sources and three pinned configuration files unchanged.
5. From the reconstructed project root, run the core and supplemental compiler
   runners sequentially, then refresh the source scan (Python 3.12+ and `rg` are
   needed). The copied audit directory is the output directory:

   ```powershell
   & './verification/independent-audit-2026-09-05/run_independent_audit.ps1'
   & './verification/independent-audit-2026-09-05/run_additional_modules.ps1'
   & '<python.exe>' './verification/independent-audit-2026-09-05/placeholder_scan.py'
   ```

   Inspect each command's exit code and the emitted status files/logs. The core
   runner rebuilds the project, checks the theorem and exact definitions, audits
   axioms, and traverses the declaration graph. The additional runner checks the
   present library modules outside the root import closure. For exact commands,
   flags and ordering, see those scripts and their recorded logs. Regenerate the
   provenance/source maps and final report to describe your own run before
   repackaging; a prior report is evidence of the recorded run only.

## Meaning of the recorded clean rebuild

The core run removed the root package's `.lake/build` outputs, including vendored
BanLat outputs, and checked that no root `.olean` remained before rebuilding.
The external packages under `.lake/packages` and their existing dependency build
caches were retained. `lake --no-cache` disabled Lake artifact-cache lookup for
the invoked commands. This audit did not rebuild all external dependencies from
scratch. `clean_state.txt`, `clean.log`, `build.log`, the supplemental build logs,
and both run-status files document the actual scope.

## Pinned external dependencies

{dependencies}

## Packaging exclusions

{exclusions}

The package builder is included as `audit-evidence/package_audit.py`. It requires
both compiler status files to pass, an explicit `Final result: PASS` in the final
report, matching before/after/current original sources, and a current passing
source scanner inventory. It creates no mathematical proof or assumption.
""".encode("utf-8")


def build_archive(report_path):
    before, status, additional = validate_gates(report_path)
    report_relative = report_path.relative_to(EVIDENCE).as_posix()
    evidence, excluded = evidence_files()
    require(report_relative in evidence, "Final report would not be included as evidence.")
    plan = {}
    for name, record in sorted(before.items()):
        plan["audited-source/" + name] = {"path": contained_file(PROJECT, name), **record}
    for name, path in sorted(evidence.items()):
        sha, size = digest_file(path)
        plan["audit-evidence/" + name] = {"path": path, "sha256": sha, "bytes": size}
    generated_readme = readme(report_relative, len(before), len(evidence), excluded)
    plan["README.md"] = {"data": generated_readme, "sha256": hashlib.sha256(generated_readme).hexdigest(), "bytes": len(generated_readme)}
    folded = [name.casefold() for name in plan]
    require(len(set(folded)) == len(folded), "Case-insensitive archive path collision.")
    manifest_text = "".join(f"{entry['sha256']}  {name}\n" for name, entry in sorted(plan.items()))
    manifest_bytes = manifest_text.encode("utf-8")
    require(ARCHIVE.parent == PROJECT.parent and ARCHIVE.parent.is_dir(), "Unexpected archive output directory.")
    pending = ARCHIVE.with_name(ARCHIVE.name + ".partial-" + uuid.uuid4().hex)
    require(not pending.exists(), "Unexpected temporary archive collision.")
    try:
        with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
            for name, record in sorted(plan.items()):
                if "data" in record:
                    archive.writestr(name, record["data"])
                else:
                    archive.write(record["path"], arcname=name)
            archive.writestr(MANIFEST_NAME, manifest_bytes)
        with zipfile.ZipFile(pending, "r") as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)), "ZIP contains duplicate entries.")
            require(set(names) == set(plan) | {MANIFEST_NAME}, "ZIP entry inventory mismatch.")
            require(archive.testzip() is None, "ZIP CRC validation failed.")
            require(archive.read(MANIFEST_NAME) == manifest_bytes, "Stored SHA256 manifest differs from generated manifest.")
            manifest_entries = {}
            for line in archive.read(MANIFEST_NAME).decode("utf-8").splitlines():
                sha, name = line.split("  ", 1)
                require(name not in manifest_entries and re.fullmatch(r"[0-9a-f]{64}", sha), "Invalid/duplicate manifest entry.")
                manifest_entries[name] = sha
            require(set(manifest_entries) == set(plan), "Manifest does not cover every non-manifest archive member.")
            for name, expected_sha in manifest_entries.items():
                digest = hashlib.sha256()
                size = 0
                with archive.open(name) as source:
                    while block := source.read(BLOCK):
                        digest.update(block)
                        size += len(block)
                require(digest.hexdigest() == expected_sha and size == plan[name]["bytes"], f"Archived member failed SHA256/size verification: {name}")
        # Ensure the packaged bytes still describe the final, unchanged live evidence.
        final_evidence, _ = evidence_files()
        require(set(final_evidence) == set(evidence), "Evidence files were added/removed during packaging.")
        for name, record in plan.items():
            if "path" in record:
                sha, size = digest_file(record["path"])
                require(sha == record["sha256"] and size == record["bytes"], f"Input changed during packaging: {name}")
        validate_gates(report_path)
        archive_sha, archive_size = digest_file(pending)
        os.replace(pending, ARCHIVE)
        result = {
            "status": "passed", "created_utc": datetime.now(timezone.utc).isoformat(),
            "archive": str(ARCHIVE), "archive_bytes": archive_size, "archive_sha256": archive_sha,
            "source_files": len(before), "evidence_files": len(evidence), "total_zip_members": len(plan) + 1,
            "sha256_manifest": MANIFEST_NAME, "manifest_covered_members": len(plan),
            "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
            "zip_crc_verified": True, "every_manifest_member_sha256_verified": True,
            "before_after_current_sources_identical": True, "scanner_snapshot_current": True,
            "inputs_unchanged_during_packaging": True,
            "core_audit_status": status["status"], "additional_build_status": additional["status"],
            "final_report": report_relative, "final_report_sha256": plan["audit-evidence/" + report_relative]["sha256"],
            "excluded_evidence": excluded,
            "manifest_self_hash_note": "SHA256SUMS.txt covers every ZIP member except itself; the separately reported archive SHA256 covers the complete ZIP.",
        }
        RESULT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        summary = (
            "PACKAGING PASS\n"
            f"Archive: {ARCHIVE}\nBytes: {archive_size}\nSHA256: {archive_sha}\n"
            f"Original source/config files: {len(before)}\nEvidence files: {len(evidence)}\n"
            f"ZIP members: {len(plan)+1}\nCRC and all {len(plan)} manifest-covered SHA256 entries verified.\n"
            "Before/after/current originals and final scanner hashes agree; both compiler status files passed.\n"
            f"Final report: {report_relative}\nResult metadata: {RESULT}\n"
        )
        SUMMARY.write_text(summary, encoding="utf-8")
        print(summary, end="")
    except BaseException:
        # Only this invocation's own derived temporary ZIP is removed.
        if pending.exists():
            require(pending.parent.resolve() == ARCHIVE.parent.resolve() and pending.name.startswith(ARCHIVE.name + ".partial-"), "Unsafe temporary path.")
            pending.unlink()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", required=True, help="Final UTF-8 Markdown/text report inside this evidence directory.")
    args = parser.parse_args()
    report_path = Path(args.report)
    if not report_path.is_absolute():
        report_path = EVIDENCE / report_path
    report_path = report_path.resolve()
    require(report_path.is_relative_to(EVIDENCE) and report_path.is_file(), "Final report must exist inside the audit evidence directory.")
    build_archive(report_path)


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        main()
    except Exception as error:
        print(f"PACKAGING FAILED: {error}", file=sys.stderr)
        raise SystemExit(1)
