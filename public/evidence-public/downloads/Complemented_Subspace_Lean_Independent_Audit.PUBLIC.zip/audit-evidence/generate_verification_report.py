"""Generate a guarded mechanical-verification report from existing evidence only.

No compiler, subprocess, network operation, or mathematical-source write occurs.
Exit 0 = PASS; 1 = FAIL; 2 = INCOMPLETE. Unknown/malformed evidence cannot pass.
The only outputs are verification_report.md and report_guard_results.json here.
"""
from __future__ import annotations

import datetime
import hashlib
import json
from collections import Counter
from pathlib import Path
import re
import sys
import tomllib

EVIDENCE = Path(__file__).resolve().parent
PROJECT = EVIDENCE.parent.parent
TARGET = "ComplementedSubspace.realMainTheorem"
STATEMENT = "ComplementedSubspace.RealMainTheoremStatement"
AUDIT_RELATIVE = "verification/independent-audit-2026-09-05"
LAKE = PROJECT.parent.parent / "tmp/lean_library_definition_audit_2026-09-05/lean-4.34.0-rc2-windows/bin/lake.exe"
ALLOWED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
REQUIRED_STEPS = [
    ("clean", "clean.log", ["--no-cache", "clean", "complemented_subspace_trial"]),
    ("build", "build.log", ["--no-cache", "build", "+ComplementedSubspace:olean"]),
    ("direct main source check", "main_source_check.log", ["--no-cache", "env", "lean", "-j1", "-M8192", "ComplementedSubspace/RealMainTheorem.lean"]),
    ("theorem identity", "theorem_check.txt", ["--no-cache", "env", "lean", "-j1", "-M8192", AUDIT_RELATIVE + "/MainIdentity.lean"]),
    ("exact definitions", "definitions.txt", ["--no-cache", "env", "lean", "-j1", "-M8192", AUDIT_RELATIVE + "/PrintDefinitions.lean"]),
    ("axioms", "axioms.txt", ["--no-cache", "env", "lean", "-j1", "-M8192", AUDIT_RELATIVE + "/PrintAxioms.lean"]),
    ("whole imported project axiom audit", "whole_project_axioms.txt", ["--no-cache", "env", "lean", "-j1", "-M8192", "WholeProjectAudit.lean"]),
    ("kernel dependency traversal", "dependency_trace_run.txt", ["--no-cache", "env", "lean", "-j1", "-M8192", AUDIT_RELATIVE + "/TraceDependencies.lean"]),
]
DEFINITIONS = ["RealMainTheoremStatement", "HasSeparatedRange", "HasRealBanachLatticeOrder",
               "BlockParameters", "Ambient", "Block", "chiGL", "lambdaGL", "GLFactorization",
               "chiDPR", "lambdaDPR", "unconditionalConstant", "unconditionalBasisConstant", "basisMultiplier"]


def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def link(path, label=None, line=None):
    path = Path(path).resolve()
    suffix = f":{line}" if line is not None else ""
    return f"[{label or path.name}](<{path.as_posix()}{suffix}>)"


def code(text, language="text"):
    longest = max((len(x) for x in re.findall(r"`+", str(text))), default=0)
    fence = "`" * max(3, longest + 1)
    return f"{fence}{language}\n{str(text).rstrip()}\n{fence}\n"


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def lake_command(arguments):
    return "& '" + str(LAKE).replace("'", "''") + "' " + " ".join("'" + arg.replace("'", "''") + "'" for arg in arguments)


def built_modules(log):
    return set(re.findall(r"^.*\[\d+/\d+\]\s+Built\s+([A-Za-z0-9_.]+)(?:\s|\(|$)", log, re.M))


def timestamp_key(value):
    """UTC second plus exact decimal fraction, ignoring only trailing zeroes."""
    if not isinstance(value, str):
        return None
    match = re.fullmatch(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})", value)
    if match is None:
        return None
    try:
        base = datetime.datetime.fromisoformat(match[1] + match[3].replace("Z", "+00:00"))
    except ValueError:
        return None
    return base.astimezone(datetime.timezone.utc).isoformat(timespec="seconds"), (match[2] or "").rstrip("0")


def same_timestamp(left, right):
    left_key, right_key = timestamp_key(left), timestamp_key(right)
    return left_key is not None and left_key == right_key


class Audit:
    def __init__(self):
        self.issues = []
        self.checks = []
        self.texts = {}
        self.data = {}
        self.checked_current_sources = 0

    def issue(self, severity, reason):
        entry = {"severity": severity, "reason": reason}
        if entry not in self.issues:
            self.issues.append(entry)

    def require(self, condition, reason, detail=None):
        self.checks.append({"condition": reason, "passed": bool(condition), "detail": detail})
        if not condition:
            self.issue("FAIL", reason + (f"; observed {detail}" if detail is not None else ""))
        return bool(condition)

    def read(self, name, required=True):
        if name in self.texts:
            return self.texts[name]
        path = EVIDENCE / name
        if not path.is_file():
            if required:
                self.issue("INCOMPLETE", f"Required evidence file is missing: {name}")
            return None
        try:
            value = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError) as error:
            self.issue("FAIL", f"Cannot read {name}: {error}")
            return None
        self.texts[name] = value
        return value

    def read_json(self, name, expected_type=dict):
        text = self.read(name)
        if text is None:
            return None
        try:
            value = json.loads(text)
        except json.JSONDecodeError as error:
            self.issue("FAIL", f"Invalid JSON in {name}: {error}")
            return None
        if not isinstance(value, expected_type):
            self.issue("FAIL", f"Wrong JSON root type in {name}: expected {expected_type.__name__}")
            return None
        self.data[name] = value
        return value

    def section(self, label, function):
        try:
            function()
        except Exception as error:
            self.issue("FAIL", f"Guard exception in {label}: {type(error).__name__}: {error}")

    def load(self):
        for name in ["run_status.json", "placeholder_scan.json", "archive_comparison.json", "kernel_dependency_summary.json", "build_scope.json", "additional_build_status.json", "initial_failed_run_status.json", "initial_placeholder_scan.json", "second_failed_run_status.json", "before_io_placeholder_scan.json"]:
            self.read_json(name)
        for name in ["dependency_summary.json", "source_hashes_before.json", "source_hashes_after.json", "dependency_source_map.json"]:
            self.read_json(name, list)
        for name in ["environment.txt", "git_status.txt", "dependency_provenance.txt", "clean_state.txt",
                     "source_unchanged.txt", "placeholder_audit.txt", "local-source-inventory.txt",
                     "definition_source_files.txt", "dependency_summary.md", "dependency_trace.txt",
                     "MainIdentity.lean", "PrintAxioms.lean", "PrintDefinitions.lean", "TraceDependencies.lean",
                     "additional_modules_build.log", "additional_source_unchanged.txt",
                     "initial_failed_theorem_check.txt", "MainIdentity.before_formatter_fix.txt", "PrintDefinitions.before_formatter_fix.txt",
                     "initial_failed_dependency_trace.txt", "TraceDependencies.before_io_fix.txt"]:
            self.read(name)
        for _, logfile, _ in REQUIRED_STEPS:
            self.read(logfile)

    def compiler(self):
        run = self.data.get("run_status.json")
        if run is None:
            return
        if run.get("status") == "failed":
            self.issue("FAIL", f"Compiler pipeline reports failed at step {run.get('step')!r}")
        elif run.get("status") != "passed":
            self.issue("INCOMPLETE", f"Compiler pipeline status is {run.get('status')!r}, current step {run.get('step')!r}; required status is 'passed'")
        commands = run.get("commands")
        if not isinstance(commands, list):
            self.issue("FAIL", "run_status.json.commands is missing or is not an array")
            return
        recorded_steps = [item.get("step") for item in commands]
        self.require(len(recorded_steps) == len(set(recorded_steps)), "Compiler steps must not have duplicate records", recorded_steps)
        if run.get("status") == "passed":
            self.require(recorded_steps == [x[0] for x in REQUIRED_STEPS], "Passed pipeline must record all eight required steps in order", recorded_steps)
        by_step = {item.get("step"): item for item in commands}
        for step, logfile, expected_args in REQUIRED_STEPS:
            item = by_step.get(step)
            if item is None:
                self.issue("INCOMPLETE", f"Required compiler step has no completed command record: {step}")
                continue
            self.require(type(item.get("exitCode")) is int and item["exitCode"] == 0,
                         f"Compiler step '{step}' must exit 0", item.get("exitCode"))
            self.require(item.get("arguments") == expected_args, f"Compiler step '{step}' arguments must match the required check", item.get("arguments"))
            self.require(item.get("command") == lake_command(expected_args), f"Compiler step '{step}' must execute the exact audited portable Lake command", item.get("command"))
            self.require(item.get("log") == logfile, f"Compiler step '{step}' must reference {logfile}", item.get("log"))
            self.require(bool(item.get("startedUtc")) and bool(item.get("finishedUtc")), f"Compiler step '{step}' must have start/end timestamps")
            log = self.texts.get(logfile)
            if log is None:
                continue
            self.require(f"COMMAND: {item.get('command')}\n" in log, f"{logfile} command must agree with run_status.json")
            self.require(f"WORKING DIRECTORY: {PROJECT}\n" in log, f"{logfile} must run in the audited project")
            starts = re.findall(r"^START UTC:\s*(\S+)\s*$", log, re.M)
            ends = re.findall(r"^END UTC:\s*(\S+)\s*$", log, re.M)
            self.require(len(starts) == len(ends) == 1 and same_timestamp(starts[0], item.get("startedUtc")) and same_timestamp(ends[0], item.get("finishedUtc")),
                         f"{logfile} start/end UTC instants must match its command record (trailing fractional zeroes may differ)")
            exits = re.findall(r"^EXIT CODE:\s*(-?\d+)\s*$", log, re.M)
            self.require(exits == ["0"], f"{logfile} must contain one completed exit-0 footer", exits)
        clean = self.texts.get("clean_state.txt", "")
        olean_counts = re.findall(r"Root build \.olean files after clean:\s*(\d+)", clean)
        self.require(olean_counts == ["0"], "Fresh clean must leave zero root-project .olean files", olean_counts)
        identity = self.texts.get("theorem_check.txt")
        if identity is not None:
            marker = f"KERNEL DECLARATION CHECK: theorem; exact stored type {STATEMENT}; no parameters."
            self.require(marker in identity, "Stored theorem kind/type/no-parameters assertion must appear in the successful identity log")
            self.require(TARGET in identity and STATEMENT in identity, "Successful #check output must name the exact target and statement")
        definitions = self.texts.get("definitions.txt")
        if definitions is not None:
            missing = [name for name in DEFINITIONS if "ComplementedSubspace." + name not in definitions]
            self.require(not missing, "All thirteen requested definitions plus the supporting Block abbreviation must appear in actual compiler output", missing)
        whole = self.texts.get("whole_project_axioms.txt")
        if whole is not None:
            self.require(re.search(r"Audited \d+ declarations in ComplementedSubspace\. All transitive axioms are in the allowlist: propext, Classical.choice, Quot.sound\.", whole) is not None,
                         "Whole imported-project axiom audit must report its completed declaration inspection")

    def source(self):
        before = self.data.get("source_hashes_before.json")
        after = self.data.get("source_hashes_after.json")
        scan = self.data.get("placeholder_scan.json")
        if before is not None:
            self.before_map = {row["path"].replace("\\", "/"): row for row in before}
            self.require(len(self.before_map) == len(before), "Original source snapshot must have unique paths")
            self.original_lean = {name: row for name, row in self.before_map.items() if name.endswith(".lean")}
            self.require(len(self.original_lean) == 230, "Original-source scan scope must include all 230 pre-existing Lean files", len(self.original_lean))
        if before is not None and after is not None:
            after_map = {row["path"].replace("\\", "/"): row for row in after}
            self.require(self.before_map == after_map, "Before/after SHA256, byte lengths, and original path inventory must agree exactly")
            changed = []
            for name, row in after_map.items():
                path = PROJECT / name
                if not path.is_file() or digest(path) != row["sha256"].lower() or path.stat().st_size != row["bytes"]:
                    changed.append(name)
            self.checked_current_sources = len(after_map)
            self.require(not changed, "Current original sources/configuration must still match the final snapshot", changed)
            marker = f"PASS: all {len(before)} original local Lean/configuration files are unchanged by SHA256."
            self.require(marker in self.texts.get("source_unchanged.txt", ""), "Source-immutability completion marker must match the snapshot count")
        if scan is None:
            return
        counts = scan.get("code_token_counts", {})
        for word in ["sorry", "admit", "sorryAx", "axiom"]:
            self.require(type(counts.get(word)) is int and counts[word] == 0, f"Executable-source token count '{word}' must be zero", counts.get(word))
        self.require(scan.get("lexical_and_import_errors") == [], "Source scanner must have zero lexical/import errors", scan.get("lexical_and_import_errors"))
        self.require(scan.get("source_placeholder_or_trust_hazards") == [], "Source scanner must have zero placeholder/trust-bypass candidates", scan.get("source_placeholder_or_trust_hazards"))
        self.require(scan.get("independent_rg_inventory_agrees") is True, "Independent rg and Python local-source inventories must agree")
        self.require(scan.get("inventory_rg_only") == [] and scan.get("inventory_python_only") == [], "Independent inventories must have no unmatched files")
        self.require(scan.get("unfollowed_directory_symlinks") == [], "Scanner must not silently skip directory symlinks")
        self.require(scan.get("stability_check", {}).get("changed_or_removed_during_scan") == [], "Source scanner must observe stable source hashes")
        self.require(str(scan.get("self_test", "")).startswith("PASS:"), "Source-lexer self-test must pass")
        inventory = scan.get("inventory", [])
        self.require(scan.get("files") == len(inventory), "Scanner file count must equal its complete inventory")
        inventory_by_file = {row["file"]: row for row in inventory}
        if before is not None:
            missing = [name for name in self.original_lean if name not in inventory_by_file]
            changed = [name for name, row in self.original_lean.items() if name in inventory_by_file and row["sha256"].lower() != inventory_by_file[name]["sha256"].lower()]
            self.require(not missing and not changed, "Scanner must cover every original Lean source at its snapshotted hash", {"missing": missing, "different": changed})
        stale = [row["file"] for row in inventory if not (PROJECT / row["file"]).is_file() or digest(PROJECT / row["file"]) != row["sha256"].lower()]
        self.require(not stale, "All scanned files, including audit helpers, must still match the scanner inventory", stale)
        modules = {row["module"]: row for row in inventory}
        todo, visited = ["ComplementedSubspace"], set()
        while todo:
            module = todo.pop()
            if module in visited:
                continue
            if module not in modules:
                self.issue("FAIL", f"Configured root/local import missing from source inventory: {module}")
                continue
            visited.add(module)
            for dependency in modules[module]["imports"]:
                if dependency in modules:
                    todo.append(dependency)
                elif dependency == "ComplementedSubspace" or dependency.startswith(("ComplementedSubspace.", "BanLat.")):
                    self.issue("FAIL", f"Local import {dependency} used by {module} is absent from the source inventory")
        self.root_closure = sorted(visited)
        self.root_modules_in_build_log = sorted(set(self.root_closure) & built_modules(self.texts.get("build.log", "")))
        self.require(len(visited) == 177, "Configured root's complete local syntactic import closure must contain 177 modules", len(visited))
        completed_build = any(x.get("step") == "build" and x.get("exitCode") == 0 for x in self.data.get("run_status.json", {}).get("commands", []))
        if completed_build:
            missing_log_modules = sorted(set(self.root_closure) - set(self.root_modules_in_build_log))
            self.require(not missing_log_modules, "Fresh build.log must report Built for every root-closure local module", missing_log_modules)
            absent = [name for name in self.root_closure if not (PROJECT / ".lake/build/lib/lean" / (name.replace(".", "/") + ".olean")).is_file()]
            self.require(not absent, "Successful fresh build must have an .olean for every configured-root local module", absent)
        self.unsafe_contexts = [row for row in scan.get("occurrences", []) if row.get("kind") == "code" and row.get("token") == "allowUnsafeReducibility"]
        self.require(counts.get("allowUnsafeReducibility") == 3 and len(self.unsafe_contexts) == 3, "Exactly three local allowUnsafeReducibility settings must be recorded")
        implementation = scan.get("allowUnsafeReducibility_implementation_evidence", {})
        implementation_file = Path(implementation.get("file", ""))
        self.require(implementation_file.is_file() and digest(implementation_file) == implementation.get("sha256"), "Captured pinned Lean reducibility implementation must match its current source hash")

    def formatter_correction(self):
        """Record the observed helper failure permanently, including on later PASS."""
        initial = self.data.get("initial_failed_run_status.json")
        run = self.data.get("run_status.json", {})
        self.formatter_correction_checks = []
        if initial is not None:
            self.require(initial.get("status") == "failed" and initial.get("step") == "theorem identity",
                         "Preserved initial run must record failure at the theorem identity helper")
            old_commands = initial.get("commands", [])
            self.require([row.get("step") for row in old_commands] == [row[0] for row in REQUIRED_STEPS[:4]]
                         and [row.get("exitCode") for row in old_commands] == [0, 0, 0, 1],
                         "Initial failed run must preserve successful clean/build/direct-source checks and exit-1 identity attempt")
            retained = run.get("commands", [])[:3]
            timestamps = {"startedUtc", "finishedUtc"}
            same_prefix = len(retained) == len(old_commands[:3]) == 3 and all(
                {key: value for key, value in current.items() if key not in timestamps} == {key: value for key, value in old.items() if key not in timestamps}
                and all(same_timestamp(current.get(key), old.get(key)) for key in timestamps)
                for current, old in zip(retained, old_commands[:3]))
            self.require(same_prefix,
                         "Resumed pipeline must preserve the first three successful commands/results exactly and their timestamp instants unchanged")
            if len(old_commands) == 4:
                failed = old_commands[3]
                self.require(failed.get("arguments") == REQUIRED_STEPS[3][2] and failed.get("command") == lake_command(REQUIRED_STEPS[3][2]),
                             "Preserved failed helper must have executed the exact recorded identity-check command")
                log = self.texts.get("initial_failed_theorem_check.txt")
                if log is not None:
                    self.require(f"COMMAND: {failed.get('command')}\n" in log
                                 and f"START UTC: {failed.get('startedUtc')}\n" in log
                                 and f"END UTC: {failed.get('finishedUtc')}\n" in log,
                                 "Preserved failed helper log must match its original command and timestamps")
                    self.require(re.findall(r"^EXIT CODE:\s*(-?\d+)\s*$", log, re.M) == ["1"],
                                 "Preserved failed helper log must explicitly retain exit 1")
                    diagnostics = re.findall(r"^.*\berror:.*$", log, re.M)
                    expected = AUDIT_RELATIVE + "/MainIdentity.lean:5:0: error: Unknown option `pp.width`"
                    self.require(diagnostics == [expected], "Preserved helper failure must have exactly the unsupported pp.width diagnostic", diagnostics)
                    self.initial_formatter_diagnostic = diagnostics
                    checks = re.findall(r"^ComplementedSubspace\.realMainTheorem : ComplementedSubspace\.RealMainTheoremStatement$", log, re.M)
                    marker = f"KERNEL DECLARATION CHECK: theorem; exact stored type {STATEMENT}; no parameters."
                    self.require(len(checks) == 2 and marker in log
                                 and "'ComplementedSubspace.realMainTheorem' depends on axioms: [propext, Classical.choice, Quot.sound]" in log,
                                 "Preserved failed helper output must show both checks, standard axioms, and stored-type assertion without treating its exit-1 run as success")
        if run.get("status") == "passed":
            self.require(run.get("resumedFrom") == "initial_failed_run_status.json", "Successful corrected pipeline must link its preserved initial failure using resumedFrom")
        elif run.get("resumedFrom") != "initial_failed_run_status.json":
            self.issue("INCOMPLETE", "Corrected pipeline has not yet recorded resumedFrom: initial_failed_run_status.json")
        initial_scan = self.data.get("initial_placeholder_scan.json", {})
        initial_inventory = {row["file"]: row for row in initial_scan.get("inventory", [])}
        for current_name, preserved_name in [("MainIdentity.lean", "MainIdentity.before_formatter_fix.txt"),
                                             ("PrintDefinitions.lean", "PrintDefinitions.before_formatter_fix.txt")]:
            old_path, current_path = EVIDENCE / preserved_name, EVIDENCE / current_name
            if not old_path.is_file() or not current_path.is_file():
                continue
            old_bytes, current_bytes = old_path.read_bytes(), current_path.read_bytes()
            old_lines = old_bytes.splitlines(keepends=True)
            removed = [index for index, line in enumerate(old_lines) if line.rstrip(b"\r\n") == b"set_option pp.width 110"]
            expected_bytes = b"".join(line for index, line in enumerate(old_lines) if index not in removed)
            exact = removed == [4] and expected_bytes == current_bytes and b"pp.width" not in current_bytes
            self.require(exact, f"{current_name} must differ byte-for-byte from its preserved original only by removing line 5: set_option pp.width 110")
            initial_row = initial_inventory.get(AUDIT_RELATIVE + "/" + current_name)
            self.require(initial_row is not None and hashlib.sha256(old_bytes).hexdigest() == initial_row.get("sha256"),
                         f"Preserved {current_name} must match the initial scanner's original SHA256")
            self.formatter_correction_checks.append({"file": current_name, "preserved_file": preserved_name,
                                                     "original_sha256": hashlib.sha256(old_bytes).hexdigest(),
                                                     "current_sha256": hashlib.sha256(current_bytes).hexdigest(),
                                                     "exact_single_display_option_removal": exact})

    def provenance(self):
        environment = self.texts.get("environment.txt", "")
        blocks = re.findall(r"COMMAND \(Windows command-line syntax\): (.*?)\nARGUMENTS \(JSON\): (.*?)\nWORKING DIRECTORY: (.*?)\nSTDOUT BEGIN\n(.*?)STDOUT END\nSTDERR BEGIN\n(.*?)STDERR END\nEXIT CODE: (-?\d+)", environment, re.S)
        self.environment_versions = []
        for command, arguments, cwd, stdout, stderr, exit_code in blocks:
            argv = json.loads(arguments)
            if len(argv) == 2 and argv[-1] == "--version" and Path(argv[0]).name in {"lean.exe", "lake.exe"}:
                self.environment_versions.append({"command": command, "stdout": stdout.strip(), "stderr": stderr.strip(), "exit_code": int(exit_code), "cwd": cwd})
        self.require(len(self.environment_versions) == 2, "Environment evidence must include exact Lean and Lake version commands")
        for row in self.environment_versions:
            self.require(row["exit_code"] == 0 and "4.34.0-rc2" in row["stdout"], "Lean/Lake version command must succeed and agree with the pinned toolchain", row)
        toolchain = (PROJECT / "lean-toolchain").read_text(encoding="utf-8-sig").strip()
        self.require(toolchain == "leanprover/lean4:v4.34.0-rc2", "Current lean-toolchain must be the audited pinned runtime", toolchain)
        manifest = json.loads((PROJECT / "lake-manifest.json").read_text(encoding="utf-8-sig"))
        config = tomllib.loads((PROJECT / "lakefile.toml").read_text(encoding="utf-8-sig"))
        self.require(config.get("defaultTargets") == ["ComplementedSubspace"], "Configured default target must be ComplementedSubspace")
        pins = {item["name"]: item["rev"] for item in manifest["packages"]}
        requirement = next(item for item in config["require"] if item["name"] == "mathlib")
        self.require(requirement["rev"] == pins.get("mathlib") == "4cbb42e75a050e830b7cf0f2ae748d7644f59cf7", "lakefile, manifest, and audited Mathlib pin must agree")
        dependencies = self.data.get("dependency_summary.json")
        if dependencies is not None:
            self.require({x["name"] for x in dependencies} == set(pins), "Dependency provenance must cover every manifest package exactly")
            for item in dependencies:
                self.require(item.get("own_git_repository") is True and item.get("head_matches_pin") is True and item.get("actual_head") == item.get("manifest_rev") == pins.get(item["name"]), f"Dependency {item['name']} HEAD and own-repository identity must match its manifest pin")
                self.require(item.get("status_nonempty") is False and item.get("status_exit_code") == 0,
                             f"Dependency {item['name']} status must be clean with exit 0")
                self.require(item.get("changed_tracked_lean_except_lakefile") == [] and item.get("untracked_lean_except_lakefile") == [] and item.get("source_check_exit_codes") == [0, 0], f"Dependency {item['name']} must have no mathematical source differences")
        archive = self.data.get("archive_comparison.json")
        if archive is not None:
            path = Path(archive["archive"])
            self.require(path.is_file() and digest(path) == archive.get("archive_sha256_before") == archive.get("archive_sha256_after"), "Delivered archive must still match both recorded SHA256 measurements")
            self.require(archive.get("archive_unchanged_during_comparison") is True and archive.get("zip_crc_bad_entry") is None and archive.get("duplicate_archive_entries") == [], "Delivered ZIP must be unchanged, CRC-valid, and free of duplicate entries")
            source_rows = [x for x in archive.get("files", []) if x.get("source_or_config") is True]
            self.require(len(source_rows) == archive.get("source_or_config_count") == archive.get("source_or_config_matches") == 183 and archive.get("source_or_config_discrepancies") == [], "All 183 archived Lean/configuration files must match workspace source bytes")
            stale = [x["relative_path"] for x in source_rows if not (PROJECT / x["relative_path"]).is_file() or digest(PROJECT / x["relative_path"]) != x["archive_sha256"] or x.get("status") != "MATCH"]
            self.require(not stale, "Archived source/configuration comparisons must remain current", stale)
            self.require(archive.get("internal_manifest_entry_count") == archive.get("internal_manifest_matches") == 261 and archive.get("internal_manifest_discrepancies") == [], "All 261 internal archive manifest hashes must verify")
        git = self.texts.get("git_status.txt", "")
        self.require("rev-parse --verify HEAD" in git and "EXIT CODE: 128" in git and "refs/heads/master" in git and "?? " in git, "Git evidence must transparently record unborn HEAD and untracked project state")
        mapping = self.data.get("dependency_source_map.json")
        if mapping is not None:
            target_rows = [row for row in mapping if row.get("source_symbol") == "realMainTheorem"]
            self.require(len(target_rows) == 1 and target_rows[0].get("file") == "ComplementedSubspace/RealMainTheorem.lean" and target_rows[0].get("line") == 15,
                         "Exact target source mapping must identify RealMainTheorem.lean:15")
            target_source = (PROJECT / "ComplementedSubspace/RealMainTheorem.lean").read_text(encoding="utf-8-sig").splitlines()
            self.require(len(target_source) >= 15 and target_source[14] == "theorem realMainTheorem : RealMainTheoremStatement := by",
                         "Actual target source line 15 must be the recorded theorem declaration")
            stale = [row["file"] for row in mapping if not (PROJECT / row["file"]).is_file() or digest(PROJECT / row["file"]) != row["source_sha256"].lower()]
            self.require(not stale, "Human dependency source map must match current source hashes", sorted(set(stale)))

    def dependency_helper_correction(self):
        """Preserve the audit-only IO-monad failure and require the exact repair."""
        initial = self.data.get("second_failed_run_status.json")
        run = self.data.get("run_status.json", {})
        old_path = EVIDENCE / "TraceDependencies.before_io_fix.txt"
        current_path = EVIDENCE / "TraceDependencies.lean"
        old_text = self.texts.get("TraceDependencies.before_io_fix.txt")
        self.dependency_io_correction = {}
        if old_path.is_file() and current_path.is_file():
            old_bytes, current_bytes = old_path.read_bytes(), current_path.read_bytes()
            before, after = b"liftIO <|", b"liftM (m := IO) (n := MetaM) <|"
            exact = old_bytes.count(before) == 10 and old_bytes.replace(before, after) == current_bytes
            self.require(exact, "Dependency auditor must differ from preserved helper bytes only by the ten explicit IO-to-MetaM lift replacements")
            forbidden = [token.decode() for token in [b"#eval!", b"skipKernelTC", b"trustLevel"] if token in current_bytes]
            self.require(not forbidden and before not in current_bytes and current_bytes.count(after) == 10,
                         "Corrected dependency auditor must use all ten explicit lifts without an evaluation/trust bypass", forbidden)
            inventory = {row["file"]: row for row in self.data.get("before_io_placeholder_scan.json", {}).get("inventory", [])}
            row = inventory.get(AUDIT_RELATIVE + "/TraceDependencies.lean")
            self.require(row is not None and hashlib.sha256(old_bytes).hexdigest() == row.get("sha256"),
                         "Preserved dependency helper must match the pre-IO-fix scanner's SHA256")
            self.dependency_io_correction = {"file": "TraceDependencies.lean", "preserved_file": "TraceDependencies.before_io_fix.txt",
                                             "original_sha256": hashlib.sha256(old_bytes).hexdigest(), "current_sha256": hashlib.sha256(current_bytes).hexdigest(),
                                             "replacement_count": old_bytes.count(before), "exact_ten_io_lift_replacements": exact}
        if initial is not None:
            self.require(initial.get("status") == "failed" and initial.get("step") == "kernel dependency traversal"
                         and initial.get("resumedFrom") == "initial_failed_run_status.json",
                         "Preserved second run must record dependency-helper failure after the display-option correction")
            old_commands = initial.get("commands", [])
            self.require([row.get("step") for row in old_commands] == [row[0] for row in REQUIRED_STEPS]
                         and [row.get("exitCode") for row in old_commands] == [0] * 7 + [1],
                         "Preserved dependency failure must have seven successful core steps followed by exit-1 walker")
            retained = run.get("commands", [])[:7]
            timestamps = {"startedUtc", "finishedUtc"}
            same_prefix = len(retained) == len(old_commands[:7]) == 7 and all(
                {key: value for key, value in current.items() if key not in timestamps} == {key: value for key, value in old.items() if key not in timestamps}
                and all(same_timestamp(current.get(key), old.get(key)) for key in timestamps)
                for current, old in zip(retained, old_commands[:7]))
            self.require(same_prefix, "Walker retry must retain the seven successful commands/results exactly and their UTC timestamp instants unchanged")
            log = self.texts.get("initial_failed_dependency_trace.txt")
            if len(old_commands) == 8 and log is not None and old_text is not None:
                failed = old_commands[7]
                self.require(failed.get("arguments") == REQUIRED_STEPS[7][2] and failed.get("command") == lake_command(REQUIRED_STEPS[7][2]),
                             "Failed walker must have used the exact audited dependency-traversal command")
                self.require(f"COMMAND: {failed.get('command')}\n" in log
                             and f"WORKING DIRECTORY: {PROJECT}\n" in log,
                             "Preserved failed walker log must match its command and project directory")
                starts = re.findall(r"^START UTC:\s*(\S+)\s*$", log, re.M)
                ends = re.findall(r"^END UTC:\s*(\S+)\s*$", log, re.M)
                self.require(len(starts) == len(ends) == 1 and same_timestamp(starts[0], failed.get("startedUtc")) and same_timestamp(ends[0], failed.get("finishedUtc")),
                             "Preserved failed walker log must match the recorded UTC instants")
                self.require(re.findall(r"^EXIT CODE:\s*(-?\d+)\s*$", log, re.M) == ["1"],
                             "Preserved failed dependency helper must retain exit code 1")
                old_lines = old_text.splitlines()
                positions = [(number, line.index("liftIO <|")) for number, line in enumerate(old_lines, 1) if "liftIO <|" in line]
                expected_errors = [f"{AUDIT_RELATIVE}/TraceDependencies.lean:{number}:{column}: error: Type mismatch" for number, column in positions]
                run_cmd_lines = [number for number, line in enumerate(old_lines, 1) if line == "run_cmd liftTermElabM do"]
                self.require(len(positions) == 10 and len(run_cmd_lines) == 1,
                             "Preserved helper must contain the ten failing IO lifts and one unchanged run_cmd inspection entry")
                if len(run_cmd_lines) == 1:
                    expected_errors.append(f"{AUDIT_RELATIVE}/TraceDependencies.lean:{run_cmd_lines[0]}:0: error: Aborting evaluation since the expression depends on the 'sorry' axiom, which can lead to runtime instability and crashes.")
                diagnostics = re.findall(r"^.*\berror:.*$", log, re.M)
                self.require(diagnostics == expected_errors and len(diagnostics) == 11,
                             "Preserved walker failure must contain exactly ten IO-monad mismatches and the recovery-placeholder evaluation abort", diagnostics)
                self.require(log.count("\n  CommandElabM") == 10 and log.count("but is expected to have type\n  MetaM") == 10,
                             "All ten preserved walker type errors must specifically compare CommandElabM against MetaM")
                self.initial_dependency_diagnostics = diagnostics
        if run.get("status") == "passed":
            self.require(run.get("dependencyResumedFrom") == "second_failed_run_status.json", "Successful walker retry must link its preserved second failure using dependencyResumedFrom")
        elif run.get("dependencyResumedFrom") != "second_failed_run_status.json":
            self.issue("INCOMPLETE", "Dependency walker retry has not yet recorded dependencyResumedFrom: second_failed_run_status.json")

    def additional_build(self):
        scope = self.data.get("build_scope.json")
        additional = self.data.get("additional_build_status.json")
        if scope is not None:
            self.require(scope.get("root_module") == "ComplementedSubspace" and scope.get("root_import_closure_count") == 177
                         and set(scope.get("root_import_closure", [])) == set(getattr(self, "root_closure", [])),
                         "Supplemental build scope must agree with the independently derived 177-module root closure")
            extras = scope.get("omitted_library_modules", [])
            extra_names = {row["module"] for row in extras}
            expected_targets = ["+" + row["module"] + ":olean" for row in extras]
            self.require(len(extras) == len(extra_names) == scope.get("omitted_library_module_count") == 16
                         and scope.get("extra_olean_targets") == expected_targets,
                         "Supplemental scope must name exactly the sixteen omitted library modules and their exact targets")
            inventory = self.data.get("placeholder_scan.json", {}).get("inventory", [])
            library_names = {row["module"] for row in inventory if row["module"] == "ComplementedSubspace" or row["module"].startswith(("ComplementedSubspace.", "BanLat."))}
            self.require(len(library_names) == scope.get("all_library_module_count") == 193
                         and set(getattr(self, "root_closure", [])) | extra_names == library_names
                         and not (set(getattr(self, "root_closure", [])) & extra_names),
                         "Root build plus supplemental targets must cover all 193 present library modules exactly")
            stale = [row["file"] for row in extras if not (PROJECT / row["file"]).is_file() or digest(PROJECT / row["file"]) != row["sha256"].lower()]
            self.require(not stale, "Supplemental target sources must match their build-scope SHA256 hashes", stale)
        if additional is None:
            return
        if additional.get("status") == "failed":
            self.issue("FAIL", "Supplemental full-library build reports failed")
        elif additional.get("status") != "passed":
            self.issue("INCOMPLETE", f"Supplemental full-library build is {additional.get('status')!r}; required status is 'passed'")
            return
        self.require(type(additional.get("exitCode")) is int and additional["exitCode"] == 0, "Supplemental build must exit 0", additional.get("exitCode"))
        self.require(additional.get("sourceUnchanged") is True, "Supplemental build must confirm original sources/configuration unchanged")
        self.require(additional.get("moduleCount") == 16, "Supplemental build must cover all sixteen omitted library modules")
        self.require(additional.get("log") == "additional_modules_build.log" and additional.get("sourceValidationLog") == "additional_source_unchanged.txt", "Supplemental status must reference its exact raw build/source-validation logs")
        self.require(bool(additional.get("startedUtc")) and bool(additional.get("finishedUtc")), "Supplemental build must have completed start/end timestamps")
        if scope is not None:
            expected_arguments = ["--no-cache", "build", *scope["extra_olean_targets"]]
            self.require(additional.get("arguments") == expected_arguments, "Supplemental build arguments must exactly match every build_scope.json target", additional.get("arguments"))
            self.require(additional.get("command") == lake_command(expected_arguments), "Supplemental build must execute the exact audited portable Lake command")
            missing = [row["module"] for row in scope["omitted_library_modules"] if not (PROJECT / ".lake/build/lib/lean" / (row["module"].replace(".", "/") + ".olean")).is_file()]
            self.require(not missing, "Supplemental build must produce every additional local module .olean", missing)
            self.additional_modules_in_build_log = sorted({row["module"] for row in scope["omitted_library_modules"]} & built_modules(self.texts.get("additional_modules_build.log", "")))
            missing_log_modules = sorted({row["module"] for row in scope["omitted_library_modules"]} - set(self.additional_modules_in_build_log))
            self.require(not missing_log_modules, "Supplemental log must report Built for all sixteen additional library modules", missing_log_modules)
        log = self.texts.get("additional_modules_build.log")
        if log is not None:
            self.require(f"COMMAND: {additional.get('command')}\n" in log, "Supplemental raw log command must agree with additional_build_status.json")
            self.require(f"WORKING DIRECTORY: {PROJECT}\n" in log, "Supplemental build must run in the audited project")
            exits = re.findall(r"^EXIT CODE:\s*(-?\d+)\s*$", log, re.M)
            self.require(exits == ["0"], "Supplemental raw log must contain one completed exit-0 footer", exits)
        validation = self.texts.get("additional_source_unchanged.txt")
        if validation is not None:
            self.require(validation.strip().startswith("PASS:"), "Supplemental source-validation log must explicitly record PASS")

    def kernel(self):
        summary = self.data.get("kernel_dependency_summary.json")
        if summary is None:
            return
        self.require(summary.get("target") == TARGET and summary.get("target_kind") == "theorem" and summary.get("target_level_parameters") == [], "Kernel traversal target must be the exact closed theorem")
        for key in ["traversal_complete", "ownership_classification_complete", "axiom_cross_check_agrees"]:
            self.require(summary.get(key) is True, f"Kernel summary {key} must be true", summary.get(key))
        for key in ["missing_checked_constants", "missing_expected_bodies", "constants_without_import_origin", "reachable_project_axiom_opaque_unsafe_partial"]:
            self.require(summary.get(key) == [], f"Kernel summary {key} must be empty", summary.get(key))
        self.require(summary.get("queued_nodes") == summary.get("processed_nodes") == summary.get("checked_constants") and isinstance(summary.get("checked_constants"), int) and summary["checked_constants"] > 0, "Kernel traversal must process every queued constant")
        for key in ["reachable_axioms_direct_traversal", "reachable_axioms_stock_collectAxioms"]:
            self.require(set(summary.get(key, [])) == ALLOWED_AXIOMS, f"Kernel {key} must equal the exact three standard axioms", summary.get(key))
        axiom_log = self.texts.get("axioms.txt")
        if axiom_log is not None:
            matches = re.findall(r"['`]?ComplementedSubspace\.realMainTheorem['`]? depends on axioms:\s*\[([^\]]*)\]", axiom_log, re.S)
            axiom_sets = [{x.strip() for x in match.split(",") if x.strip()} for match in matches]
            self.require(len(axiom_sets) == 1 and axiom_sets[0] == ALLOWED_AXIOMS, "Actual #print axioms output must agree with the complete kernel traversal", [sorted(x) for x in axiom_sets])
        nodes_path = EVIDENCE / "dependency_nodes.jsonl"
        edges_path = EVIDENCE / "dependency_edges.jsonl"
        direct_path = EVIDENCE / "dependency_direct.jsonl"
        for path in [nodes_path, edges_path, direct_path]:
            if not path.is_file():
                self.issue("INCOMPLETE", f"Raw kernel graph evidence is missing: {path.name}")
        if not all(path.is_file() for path in [nodes_path, edges_path, direct_path]):
            return
        names, modules, axioms, suspicious = set(), set(), set(), []
        node_metadata = {}
        node_anomalies = []
        valid_kinds = {"axiom", "definition", "theorem", "opaque", "quotient_primitive", "inductive", "constructor", "recursor"}
        node_count = project_count = 0
        with nodes_path.open(encoding="utf-8-sig") as handle:
            for number, line in enumerate(handle, 1):
                row = json.loads(line)
                node_count += 1
                name = row["name"]
                if name in names:
                    self.issue("FAIL", f"Duplicate kernel node on line {number}: {name}")
                names.add(name)
                origin = row.get("origin_module")
                owned = isinstance(origin, str) and (origin in {"ComplementedSubspace", "BanLat"} or origin.startswith(("ComplementedSubspace.", "BanLat.")))
                expected_body = row.get("kind") in {"definition", "theorem", "opaque"}
                valid_flags = all(type(row.get(key)) is bool for key in ["project_owned", "unsafe", "partial", "body_expected", "body_available"])
                if (row.get("status") != "checked_constant_present" or not isinstance(origin, str) or not origin
                    or row.get("kind") not in valid_kinds or not valid_flags or row.get("project_owned") is not owned
                    or row.get("body_expected") is not expected_body or (expected_body and row.get("body_available") is not True)):
                    node_anomalies.append(name)
                node_metadata[name] = (origin, owned, row.get("kind"))
                if row.get("kind") == "axiom":
                    axioms.add(name)
                if owned:
                    project_count += 1
                    modules.add(row["origin_module"])
                    if row.get("kind") in {"axiom", "opaque"} or row.get("unsafe") is True or row.get("partial") is True:
                        suspicious.append(name)
        self.require(not node_anomalies, "Raw node kind/ownership/body requirements and boolean flags must be internally valid", node_anomalies[:10])
        self.require(TARGET in node_metadata and node_metadata[TARGET] == ("ComplementedSubspace.RealMainTheorem", True, "theorem"), "Raw graph target must be the expected project theorem node")
        self.require(node_count == summary.get("checked_constants") and project_count == summary.get("project_constants"), "Raw kernel node counts must agree with the summary", {"nodes": node_count, "project": project_count})
        self.require(modules == set(summary.get("project_origin_modules", [])) and axioms == ALLOWED_AXIOMS and not suspicious, "Raw node origins/axioms/suspicious flags must agree with the clean kernel summary", suspicious)
        edge_count = 0
        bad_edges = []
        node_indexes = {name: index for index, name in enumerate(names)}
        adjacency = [[] for _ in names]
        target_edges = Counter()
        with edges_path.open(encoding="utf-8-sig") as handle:
            for line in handle:
                row = json.loads(line)
                edge_count += 1
                if row.get("from") not in names or row.get("to") not in names or row.get("edge_kind") not in {"type", "value", "inductive_constructor"}:
                    if len(bad_edges) < 10:
                        bad_edges.append(row)
                else:
                    adjacency[node_indexes[row["from"]]].append(node_indexes[row["to"]])
                    if row["from"] == TARGET:
                        target_edges[(row["from"], row["edge_kind"], row["to"])] += 1
        self.require(edge_count == summary.get("edges") and not bad_edges, "Raw labelled graph must contain every counted edge with checked endpoints", {"edges": edge_count, "bad_examples": bad_edges})
        reached = set()
        work = [node_indexes[TARGET]] if TARGET in node_indexes else []
        while work:
            current = work.pop()
            if current in reached:
                continue
            reached.add(current)
            work.extend(adjacency[current])
        self.require(len(reached) == len(names), "Every raw kernel node must be reachable from the actual target", {"reached": len(reached), "recorded": len(names)})
        with direct_path.open(encoding="utf-8-sig") as handle:
            self.direct = [json.loads(line) for line in handle]
        self.require(bool(self.direct) and all(row.get("from") == TARGET and row.get("to") in names for row in self.direct), "Raw direct-reference graph must originate at the audited target")
        direct_edges = Counter((row.get("from"), row.get("edge_kind"), row.get("to")) for row in self.direct)
        self.require(direct_edges == target_edges, "Direct-reference records must equal the typed target-edge multiset in the full graph")
        inconsistent_direct = [row.get("to") for row in self.direct if (row.get("origin_module"), row.get("project_owned"), row.get("kind")) != node_metadata.get(row.get("to")) or type(row.get("project_owned")) is not bool]
        self.require(not inconsistent_direct, "Direct-reference origin/ownership/kind metadata must equal the destination-node metadata", inconsistent_direct)

    def status(self):
        if any(item["severity"] == "FAIL" for item in self.issues):
            return "FAIL"
        return "INCOMPLETE" if self.issues else "PASS"


def terminal_output(text):
    if not text:
        return "Pending: compiler output is not available."
    body = text.split("TERMINAL OUTPUT:\n", 1)[-1]
    return re.split(r"\nEXIT CODE:", body, maxsplit=1)[0].strip()


def render(audit):
    status = audit.status()
    data = audit.data
    run = data.get("run_status.json", {})
    scan = data.get("placeholder_scan.json", {})
    archive = data.get("archive_comparison.json", {})
    kernel = data.get("kernel_dependency_summary.json", {})
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    certificate = "PASS" if status == "PASS" else "FAIL / INCOMPLETE"
    lines = ["# Independent Lean verification report", "", f"**LEAN VERIFICATION CERTIFICATE: {certificate}**", "", f"**Result: {status}**", "", f"Generated UTC: {now}.", "",
             f"Target: `{TARGET} : {STATEMENT}`, in {link(PROJECT / 'ComplementedSubspace/RealMainTheorem.lean', 'ComplementedSubspace/RealMainTheorem.lean:15', 15)}.", "",
             "Scope: mechanical verification of the actual stored Lean declaration, its compiled dependencies, the local source scan, and delivery provenance. This report makes no manuscript or natural-language faithfulness assessment.", ""]
    if status == "PASS":
        lines += ["**Final result: PASS**", "", "All required compiler steps, source/provenance checks, and complete kernel-graph checks succeeded in the evidence read by this generator. The certificate is relative to the recorded Lean runtime, external dependency artifacts, and the three logical axioms listed below.", ""]
    else:
        lines += ["No passing verification certificate is issued. The following failed or pending conditions must be resolved:", ""]
        lines += [f"- **{item['severity']}**: {item['reason']}" for item in audit.issues]
        lines.append("")
    lines += [f"The compiler pipeline currently records `{run.get('status', 'missing')}` at `{run.get('step', 'unknown')}`. Guard details: {link(EVIDENCE / 'report_guard_results.json')}.", "",
              "## Audit-helper failures and corrections", "",
              "### Unsupported display option", "",
              "The initial audit attempt failed in the identity display helper after the fresh root build and direct theorem-source check had succeeded. The preserved failed command exited **1** with this diagnostic:", "",
              code("\n".join(getattr(audit, "initial_formatter_diagnostic", [])) or "Pending: preserved initial diagnostic has not been validated."),
              f"The exact original failure remains in {link(EVIDENCE / 'initial_failed_theorem_check.txt')} and {link(EVIDENCE / 'initial_failed_run_status.json')}. Both `#check` lines, the theorem print, the three-axiom output, and the stored-type assertion were printed during that failed attempt; they do not satisfy the required successful identity check because the process exited 1.", "",
              "The correction removes the unsupported pretty-printing command `set_option pp.width 110` from line 5 of each of the two audit-only helpers, `MainIdentity.lean` and `PrintDefinitions.lean`. The generator compares the preserved and current helper bytes and requires that single removed line to be their entire difference; it also requires the preserved originals to match the initial scanner hashes. The original mathematical source and pinned configuration are checked separately against the unchanged initial SHA256 snapshot.", "",
              "| Audit helper | Preserved original | Exact single display-option removal |", "|---|---|---|"]
    for item in getattr(audit, "formatter_correction_checks", []):
        lines.append(f"| {link(EVIDENCE / item['file'])} | {link(EVIDENCE / item['preserved_file'])} | `{item['exact_single_display_option_removal']}` |")
    initial = data.get("initial_failed_run_status.json", {})
    initial_commands = initial.get("commands", [])
    if len(initial_commands) >= 3:
        lines += ["", f"The retained fresh build finished at {initial_commands[1].get('finishedUtc')} with exit {initial_commands[1].get('exitCode')}; the direct mathematical-source check finished at {initial_commands[2].get('finishedUtc')} with exit {initial_commands[2].get('exitCode')}. Their successful commands/results and original raw logs are retained. Timestamp instants are unchanged; PowerShell's JSON round-trip may shorten trailing fractional zeroes in the retained record timestamps."]
    lines += ["", f"The correction-resume runner is {link(EVIDENCE / 'resume_after_formatter_fix.ps1')}. The final run status must record `resumedFrom: initial_failed_run_status.json`, preserve the successful first three commands, and contain successful reruns of all remaining five checks. Current resume marker: `{run.get('resumedFrom', 'pending')}`. This history remains in the report even when the final certificate passes.", "",
              "### IO lifting in the dependency audit helper", "",
              "A second audit attempt reached seven successful core steps, then failed while elaborating `TraceDependencies.lean`. Ten unqualified `liftIO` calls resolved to `CommandElabM` inside an inspector declared in `MetaM`. The preserved failed helper exited **1** with the following ten type errors and one resulting evaluation refusal:", "",
              code("\n".join(getattr(audit, "initial_dependency_diagnostics", [])) or "Pending: preserved dependency-helper diagnostics have not been validated."),
              f"Complete diagnostics and state: {link(EVIDENCE / 'initial_failed_dependency_trace.txt')}, {link(EVIDENCE / 'second_failed_run_status.json')}. Original helper: {link(EVIDENCE / 'TraceDependencies.before_io_fix.txt')}; its prior scanner hash is preserved in {link(EVIDENCE / 'before_io_placeholder_scan.json')}.", "",
              "The `sorry` message concerns compiler recovery placeholders created when the audit helper failed to elaborate; Lean then refused to evaluate that failed helper. The main theorem had already compiled, and its separate successful axiom checks reported only `propext`, `Classical.choice`, and `Quot.sound`. The failed helper run supplies no passing dependency-graph evidence. The complete graph and final successful traversal remain mandatory gates.", "",
              "The correction changes exactly these ten IO-lift calls, leaving the traversal logic and `run_cmd` entry unchanged:", "",
              code("-- Preserved audit helper\nliftIO <| ...\n-- Corrected audit helper\nliftM (m := IO) (n := MetaM) <| ...", "lean"),
              f"Exact byte-replacement check: `{getattr(audit, 'dependency_io_correction', {}).get('exact_ten_io_lift_replacements', 'pending')}`; replacement count: `{getattr(audit, 'dependency_io_correction', {}).get('replacement_count', 'pending')}`. No `#eval!`, kernel-check disable option, or trust override is permitted by the correction guard. Original mathematical files remain subject to the unchanged-source checks below.", "",
              f"The retry uses {link(EVIDENCE / 'resume_after_formatter_fix.ps1')} with `-ResumeDependencyWalker`, retaining the first seven successful command results and rerunning the walker. A successful final state must include `dependencyResumedFrom: second_failed_run_status.json`; current marker: `{run.get('dependencyResumedFrom', 'pending')}`. Both audit-helper failures and their narrow corrections remain documented even if the final certificate passes.", "",
              "## Environment and source provenance", ""]
    for row in getattr(audit, "environment_versions", []):
        lines += ["Recorded native Windows command line (invoked directly by the collector):", "", code(row["command"], "text"), code(row["stdout"]), f"Exit code: `{row['exit_code']}`; working directory: `{row['cwd']}`.", ""]
    lines += [f"Exact configuration contents, binary hashes, stdout/stderr, commands, and exit codes: {link(EVIDENCE / 'environment.txt')}. The toolchain file records `leanprover/lean4:v4.34.0-rc2`.", "",
              "The enclosing IA-Stuff-Math Git repository has an unborn `refs/heads/master`: `git rev-parse --verify HEAD` returns exit 128, and its status contains untracked files. There is no project commit hash to report. The audit identifies the project source by SHA256 snapshots and the delivery archive. Full commands and actual Git output are preserved in " + link(EVIDENCE / "git_status.txt") + ".", "",
              "| Dependency | Manifest revision | Recorded actual HEAD | Clean status |",
              "|---|---|---|---|"]
    for item in data.get("dependency_summary.json", []):
        lines.append(f"| `{item['name']}` | `{item['manifest_rev']}` | `{item.get('actual_head')}` | `{item.get('status_nonempty') is False and item.get('status_exit_code') == 0}` |")
    lines += ["", "Every dependency checkout's own repository identity, HEAD, origin URL, status, tracked source diff, and untracked Lean-source list is recorded in " + link(EVIDENCE / "dependency_provenance.txt") + ". The fresh project build retains external `.lake/packages` caches; this audit does not claim to rebuild the whole Lean standard library or Mathlib from source.", "",
              f"Delivery: {link(Path(archive['archive'])) if archive.get('archive') else 'archive evidence pending'}. Recorded size: `{archive.get('archive_bytes', 'pending')}` bytes; SHA256:", "", code(archive.get("archive_sha256_before", "pending")),
              f"Archive comparison records {archive.get('source_or_config_matches', 'pending')}/{archive.get('source_or_config_count', 'pending')} matching Lean/configuration files, and {archive.get('internal_manifest_matches', 'pending')}/{archive.get('internal_manifest_entry_count', 'pending')} verified internal source-manifest entries. ZIP CRC and duplicate-entry results are in {link(EVIDENCE / 'archive_comparison.json')}. `SOURCE-MANIFEST.sha256` is generated inside the archive and has no workspace original; local extra audit/scratch/draft files are separately listed in that evidence.", "",
              "## Fresh build and exact theorem checks", "",
              code(audit.texts.get("clean_state.txt", "Pending: clean-state evidence is absent.")),
              f"Configured-root local import closure: **{len(getattr(audit, 'root_closure', [])) or 'pending'} modules**, derived from the scanner's recorded import inventory. Original Lean source files in the before/after snapshot: **{len(getattr(audit, 'original_lean', {})) or 'pending'}**. Total scanner inventory, including this audit's Lean helpers: **{scan.get('files', 'pending')}** files. The source scan includes unused drafts; those drafts are not asserted to have been compiled. The theorem module's own local syntactic import closure has {len(scan.get('local_import_closure', [])) or 'pending'} modules; the kernel proof-dependency graph below is a separate, declaration-level traversal.", "",
              f"The raw build log currently contains `Built` records for {len(getattr(audit, 'root_modules_in_build_log', []))}/177 local root-closure modules. PASS requires all 177 records and the resulting `.olean` files. The build uses the configured root `ComplementedSubspace` and its full local dependency closure, including vendored BanLat. Root build products are removed first; post-clean `.olean` count is taken from the actual evidence above. External dependency caches are retained. Compiler commands and outcomes:", ""]
    commands = {item.get("step"): item for item in run.get("commands", [])}
    for step, logfile, _ in REQUIRED_STEPS:
        item = commands.get(step)
        lines += [f"**{step}** — {link(EVIDENCE / logfile)}", ""]
        if item:
            lines += [code(item["command"], "powershell"), f"Exit code: `{item.get('exitCode')}`; UTC {item.get('startedUtc')} to {item.get('finishedUtc')}.", ""]
        else:
            lines += ["Pending: no completed command record.", ""]
    additional = data.get("additional_build_status.json", {})
    scope = data.get("build_scope.json", {})
    library_inventory = scan.get("inventory", [])
    library_groups = {"root": sum(row.get("module") == "ComplementedSubspace" for row in library_inventory),
                      "ComplementedSubspace": sum(row.get("module", "").startswith("ComplementedSubspace.") for row in library_inventory),
                      "BanLat": sum(row.get("module", "").startswith("BanLat.") for row in library_inventory)}
    lines += ["**Supplemental build of all remaining library modules** — " + link(EVIDENCE / "additional_modules_build.log"), "",
              f"The present library tree comprises {scope.get('all_library_module_count', 'pending')} modules: root {library_groups['root']}, ComplementedSubspace {library_groups['ComplementedSubspace']}, and BanLat {library_groups['BanLat']}. The configured-root build scope has 177 modules; the supplemental command explicitly targets the remaining {scope.get('omitted_library_module_count', 'pending')} modules, including library audit files and the otherwise unused library lemmas. Exact module/target coverage is recorded in {link(EVIDENCE / 'build_scope.json')}. Root-level scratch files and experimental drafts remain in the source scan and are not claimed as compiled library modules.", ""]
    if additional.get("command"):
        lines += [code(additional["command"], "powershell"),
                  f"Supplemental status: `{additional.get('status')}`; exit code: `{additional.get('exitCode', 'pending')}`; source unchanged: `{additional.get('sourceUnchanged', 'pending')}`; UTC {additional.get('startedUtc')} to {additional.get('finishedUtc', 'pending')}.", ""]
    else:
        lines += ["Pending: no supplemental-build command evidence exists.", ""]
    lines += [f"Supplemental status/source evidence: {link(EVIDENCE / 'additional_build_status.json')}, {link(EVIDENCE / 'additional_source_unchanged.txt')}. Verified supplemental `Built` coverage is {len(getattr(audit, 'additional_modules_in_build_log', []))}/16 modules. PASS requires successful compilation of the entire 193-module present library tree and unchanged original sources.", ""]
    lines += ["The independent identity helper executes both `#check` forms, assigns the existing theorem to the requested proposition in an `example`, and inspects `env.checked.get` for `.thmInfo`. Its stored-type check uses exact expression equality with the statement constant and requires no universe parameters. The exact assertion text is:", "",
              code(f"KERNEL DECLARATION CHECK: theorem; exact stored type {STATEMENT}; no parameters."),
              f"The guard requires this text in a successful compiler log; it is not inferred from the helper's source alone. Actual `#check`, theorem print, and assertion output: {link(EVIDENCE / 'theorem_check.txt')}; audit helper: {link(EVIDENCE / 'MainIdentity.lean')}.", "",
              "Actual identity-check terminal output:", "", code(terminal_output(audit.texts.get("theorem_check.txt"))),
              "Source immutability result:", "", code(audit.texts.get("source_unchanged.txt", "Pending: final source comparison has not completed.")),
              f"The generator also compares the original current files to {link(EVIDENCE / 'source_hashes_after.json')} and compares all original scanned Lean hashes to {link(EVIDENCE / 'source_hashes_before.json')}. It checked {audit.checked_current_sources} current original source/configuration files at report generation.", "",
              "## Placeholder scan and local reducibility settings", "",
              f"Method: {scan.get('method', 'pending')}", "", "| Executable token | Count |", "|---|---|"]
    for token in ["sorry", "admit", "sorryAx", "axiom", "unsafe", "partial", "opaque", "native_decide", "implemented_by", "extern", "allowUnsafeReducibility"]:
        lines.append(f"| `{token}` | {scan.get('code_token_counts', {}).get(token, 'pending')} |")
    lines += ["", f"Lexical/import errors: `{compact(scan.get('lexical_and_import_errors', 'pending'))}`. Placeholder/trust-bypass candidates: `{compact(scan.get('source_placeholder_or_trust_hazards', 'pending'))}`. Raw inventory, source/comment distinctions, all settings, metaprogramming contexts, and exact scanner/search commands with exit codes: {link(EVIDENCE / 'placeholder_audit.txt')}, {link(EVIDENCE / 'placeholder_scan.json')}, {link(EVIDENCE / 'local-source-inventory.txt')}.", "",
              "The source scanner records three local `allowUnsafeReducibility` occurrences and their immediately following attribute commands:", ""]
    for item in getattr(audit, "unsafe_contexts", []):
        path = PROJECT / item["file"]
        source = path.read_text(encoding="utf-8-sig").splitlines()
        first = item["line"]
        excerpt = "\n".join(f"{number}: {source[number - 1]}" for number in range(first, min(first + 2, len(source) + 1)))
        lines += [link(path, f"{item['file']}:{first}", first), "", code(excerpt, "lean")]
    implementation = scan.get("allowUnsafeReducibility_implementation_evidence", {})
    implementation_link = link(Path(implementation["file"]), "pinned Lean ReducibilityAttrs.lean:122", 122) if implementation.get("file") else "implementation evidence pending"
    lines += [f"The captured implementation in {implementation_link} makes this option bypass reducibility-attribute validation before updating an elaborator reducibility extension. It affects elaboration, simplifier/typeclass indexing, and local unfolding control; it does not disable kernel proof checking or itself introduce an axiom. The exact pinned implementation excerpt and hash are in `allowUnsafeReducibility_implementation_evidence` in {link(EVIDENCE / 'placeholder_scan.json')}. The kernel traversal separately inspects every reachable project declaration for axiom, opaque, unsafe, and partial flags.", "",
              "The scanner's `constants` token occurrence is the environment-field access `env.constants.toList` in `WholeProjectAudit.lean`; it is not a mathematical constant declaration. Source-inspection audit `run_cmd` blocks are recorded separately and do not supply the target with a proof premise. The token scan is supporting source evidence, with the compiler and checked-environment traversal providing separate checks.", "",
              "## Exact axioms and compiled dependency graph", "",
              "Actual terminal output of `#print axioms ComplementedSubspace.realMainTheorem`:", "", code(terminal_output(audit.texts.get("axioms.txt"))),
              "`propext` is propositional extensionality: logically equivalent propositions can be equal. `Classical.choice` supplies classical choice from a nonempty type. `Quot.sound` identifies quotient classes when their representatives satisfy the quotient relation. These are the standard Lean axioms against which the certificate is checked; no additional reachable axiom is accepted by this report's guard.", "",
              "| Kernel graph measurement | Recorded value |", "|---|---|"]
    for key in ["traversal_complete", "ownership_classification_complete", "axiom_cross_check_agrees", "queued_nodes", "processed_nodes", "checked_constants", "project_constants", "edges"]:
        lines.append(f"| `{key}` | `{kernel.get(key, 'pending')}` |")
    lines += [f"| Project defining modules actually reached | `{len(kernel.get('project_origin_modules', [])) if kernel else 'pending'}` |",
              f"| Project axiom/opaque/unsafe/partial declarations | `{compact(kernel.get('reachable_project_axiom_opaque_unsafe_partial', 'pending'))}` |", "",
              "The traversal starts at the actual checked theorem and follows declaration types and available values, including theorem proofs and opaque bodies via `allowOpaque := true`, plus inductive-constructor edges. It cross-checks its axiom set against stock `collectAxioms`. Project ownership uses the defining imported module, so private generated names are included. Missing constants, missing bodies, missing origins, incomplete traversal, and unexpected project declaration kinds prevent PASS.", "",
              f"The generator also reads the raw graph to check node/edge counts, endpoint coverage, project origins, axiom flags, and immediate-reference records. Graph evidence: {link(EVIDENCE / 'kernel_dependency_summary.json')}, {link(EVIDENCE / 'dependency_nodes.jsonl')}, {link(EVIDENCE / 'dependency_edges.jsonl')}, {link(EVIDENCE / 'dependency_direct.jsonl')}, {link(EVIDENCE / 'dependency_trace.txt')}.", ""]
    direct = sorted({(row.get("to"), row.get("origin_module")) for row in getattr(audit, "direct", []) if row.get("project_owned") is True})
    if direct:
        lines += ["Immediate project-owned references in the actual kernel graph:", "", "| Declaration | Defining module |", "|---|---|"]
        lines += [f"| `{name}` | `{module}` |" for name, module in direct]
        lines.append("")
    lines += [f"The concise source dependency map in {link(EVIDENCE / 'dependency_summary.md')} traces recursive projection/parameter construction, primal and dual DPR obstructions, local Hilbert estimates, GL retraction/approximation bounds, and ambient geometry. It distinguishes definitions, proved helper claims, and intermediate hypotheses discharged by later proofs. Mechanically located source declarations and hashes: {link(EVIDENCE / 'dependency_source_map.json')}. This prose map supplements the complete graph; it is not substituted for the graph's completion check.", "",
              "## Exact definitions and source capture", "",
              "The independent print helper prints the thirteen requested definitions and structures plus the supporting `Block` abbreviation from the compiled theorem environment:", "", ", ".join(f"`ComplementedSubspace.{name}`" for name in DEFINITIONS) + ".", "",
              f"Full untruncated compiler output is preserved in {link(EVIDENCE / 'definitions.txt')} and reproduced in the appendix below. The pipeline's actual filename is `definitions.txt`. Exact original source capture with line numbers is in {link(EVIDENCE / 'definition_source_files.txt')}; the separate print helper is {link(EVIDENCE / 'PrintDefinitions.lean')}. These are the formal objects audited, with no natural-language interpretation verdict attached.", "",
              "## Raw evidence inventory", "", "All files present in this evidence directory when the report was generated are listed below. The generated report and guard-result JSON are outputs of this inventory operation and are omitted to avoid circular hashes. Paths are absolute and clickable; hashes identify the evidence snapshot.", "",
              "| File | Bytes | SHA256 |", "|---|---:|---|"]
    for path in sorted(EVIDENCE.rglob("*")):
        if path.is_file() and path.name not in {"verification_report.md", "report_guard_results.json"} and "__pycache__" not in path.parts:
            lines.append(f"| {link(path, path.relative_to(EVIDENCE).as_posix())} | {path.stat().st_size} | `{digest(path)}` |")
    lines += ["", "## Appendix: full exact-definition compiler output", "", code(audit.texts.get("definitions.txt", "Pending: exact-definition compiler output does not exist yet."))]
    return "\n".join(lines).rstrip() + "\n"


def main():
    audit = Audit()
    audit.section("load evidence", audit.load)
    for label, function in [("compiler", audit.compiler), ("source", audit.source), ("formatter correction", audit.formatter_correction), ("dependency helper correction", audit.dependency_helper_correction), ("provenance", audit.provenance), ("additional build", audit.additional_build), ("kernel", audit.kernel)]:
        audit.section(label, function)
    try:
        report = render(audit)
    except Exception as error:
        audit.issue("FAIL", f"Report rendering guard exception: {type(error).__name__}: {error}")
        report = "# Independent Lean verification report\n\n**LEAN VERIFICATION CERTIFICATE: FAIL / INCOMPLETE**\n\n**Result: FAIL**\n\nNo certificate is issued.\n\n" + "\n".join(f"- {x['severity']}: {x['reason']}" for x in audit.issues) + "\n"
    status = audit.status()
    result = {"generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "status": status, "target": TARGET,
              "generator": str(Path(__file__).resolve()), "generator_sha256": digest(Path(__file__)),
              "issues": audit.issues, "conditions": audit.checks,
              "original_source_count": len(getattr(audit, "original_lean", {})),
              "configured_root_local_modules": getattr(audit, "root_closure", []),
              "root_modules_reported_built": getattr(audit, "root_modules_in_build_log", []),
              "additional_modules_reported_built": getattr(audit, "additional_modules_in_build_log", []),
              "audit_formatter_correction": getattr(audit, "formatter_correction_checks", []),
              "audit_dependency_io_correction": getattr(audit, "dependency_io_correction", {}),
              "compiler_calls_performed_by_generator": 0}
    (EVIDENCE / "report_guard_results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (EVIDENCE / "verification_report.md").write_text(report, encoding="utf-8")
    print(json.dumps({"status": status, "issues": audit.issues, "report": str(EVIDENCE / "verification_report.md")}, ensure_ascii=True, indent=2))
    return {"PASS": 0, "FAIL": 1, "INCOMPLETE": 2}[status]


if __name__ == "__main__":
    raise SystemExit(main())
