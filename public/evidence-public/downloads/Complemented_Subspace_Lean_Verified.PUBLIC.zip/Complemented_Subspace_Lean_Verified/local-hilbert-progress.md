# Local Hilbert approximation implementation

> Component progress log from 5 September 2026. Checkpoints below are historical; current statement conventions are documented in [README.md](README.md), and final verification status is recorded in [the fresh-build log](verification/fresh-root-build.log).

Started 5 September 2026 at approximately 17:39 UTC, as part of the sustained
implementation requested by the user.

## Changes from the manuscript

The manuscript's quantitative approximate Jordan-von Neumann theorem is replaced
by a qualitative compactness argument. The construction only needs an
existential threshold for each fixed dimension and distortion, so no numerical
rate is discarded from the final theorem.

The earlier implementation plan proposed a Hahn-Banach induction to normalize
coordinates. The current implementation instead maximizes the absolute value
of a determinant on a finite product of closed balls. Replacing one column by
another vector in the ball bounds each coordinate functional. Rescaling gives
the stronger comparison `||a||∞ ≤ q(a) ≤ d ||a||∞`. This elementary proof is
the usual finite-dimensional argument for an Auerbach basis; it does not assume
an Auerbach-basis theorem or an ellipsoid theorem from another source.

Normalized norms are represented as functions on a fixed reference vector
space. Their defining axioms and uniform upper/lower bounds are closed in the
pointwise topology. Tychonoff compactness then gives compactness of the family.
The shared Lipschitz bound gives joint continuity of evaluation, which is used
to obtain uniform comparison on the compact reference unit sphere.

## Exact status

The following four files now compile successfully:

* `LocalHilbertCoordinates.lean`: determinant-maximizing basis and the uniform
  normalized-coordinate equivalence.
* `LocalHilbertCompactness.lean`: compact norm family, joint evaluation
  continuity, openness of the sphere-comparison neighborhood, and the fixed
  coordinate-family threshold.
* `LocalHilbert.lean`: actual renormed inner-product space via
  `InnerProductSpace.ofNorm`; transfer back to the original carrier; the full
  dimension-uniform theorem and its ambient-subspace form.
* `LocalHilbertProjection.lean`: equivalent-Hilbert-norm complement bound,
  restriction to `span{x,Px}`, and a dimension-independent ambient
  parallelogram threshold for complementary projections.

The full dimension-uniform local Hilbert theorem and its actual Hilbert-space
wrapper compiled at approximately 18:39 UTC. The projection-complement transfer
and the `span{x,Px}` argument then compiled as well. The selected transitive
axiom audit passed for all six central declarations:
`exists_bounded_basis`, `exists_normalized_coordinates`,
`normalizedNorm_local_hilbert`, `exists_localHilbert_threshold`,
`exists_localHilbert_subspace_threshold`, and
`exists_parallelogram_complement_threshold`. Their only transitive axioms are
`propext`, `Classical.choice`, and `Quot.sound`.

The local geometry gate is therefore complete. This does not prove the main
existence theorem: the finite selection obstruction, construction, and the
remaining global/dual/lattice bridges have their own obligations.

The verified final interface is `exists_localHilbert_threshold`: for each
natural `k` and real `D > 1`, one `nu > 1` works for **every** real normed space
of dimension at most `k`. It returns a positive-definite seminorm `q` satisfying
the exact parallelogram law and `q(x) <= ||x|| <= D*q(x)`. The type synonym
`HilbertNormModel.Space` makes this norm an actual complete inner-product space
in finite dimension. Thus the result is stronger than mere norm-equivalence
for an individually chosen finite-dimensional space.

`LocalHilbertAudit.lean` reproducibly prints the transitive axioms of these
interfaces. The stored norm on `HilbertNormModel.Space` is distinct from the
original norm. The verified identity equivalence has norm at most one and its
inverse has norm at most `D`.

## Dual geometry: verified

`LocalHilbertDual.lean` proves `ApproxParallelogram.dual`: the same constant
passes to the continuous real dual, including the trivial-space case. Applying
it twice gives the bidual result. The proof uses direct squared evaluation
inequalities and the unit-ball operator-norm characterization; it needs neither
near norm-attainment nor a general two-term-sum duality or reflexivity theorem.
Its selected transitive axiom audit also reports exactly `propext`,
`Classical.choice`, and `Quot.sound`. The dual task finished around 18:54 UTC.

Complex Hilbert renorming is a later task. The real finite-frame scalar gap and
explicit cubic/reciprocal-square parameter sequence have also been implemented
and audited; see `finite-parameter-progress.md`.

## Hilbert factorization through small ranges: verified

`LocalHilbertFactorization.lean` compiles. Given a finite-dimensional domain E
of dimension at most q, maps A:E->W and B:W->F, and D-Hilbert approximation on
every finite-dimensional subspace of W of dimension at most q, it constructs
an actual Hilbert space H and factors B A as V U. The bounds are
`||U|| <= ||A||` and `||V|| <= D ||B||`; their product is therefore at most
`D ||A|| ||B||`. The codomain F may be arbitrary, with F=E giving the trace
application in the manuscript's infinite-sum argument.

The model H is specifically `p.Space` for a `HilbertNormModel` on the range of
A. It has actual real inner product and, because the range is finite-dimensional,
completeness. The proof restricts A to its range, uses the identity equivalence
to the new Hilbert norm, and restricts B in the other direction. It does not
assume a general gamma_2 factorization theorem. The mathematical step is the
same elementary range argument as the manuscript, expressed using the
previously constructed Hilbert model.

The updated `LocalHilbertAudit.lean` checks both factorization interfaces;
their only transitive axioms are the same three standard Lean axioms.

## Finite covariance replacement: verified

`FiniteHilbertAverage.lean` compiles. If two finite families of real coordinate
vectors have equal coordinate covariances, every linear map into an actual
real inner-product space has the same averaged squared norm on both families.
The proof expands the image in the finite coordinate basis, expands its norm
squared as an inner product, and interchanges finite sums. No dimension or
completeness restriction is placed on the target Hilbert space.

This supplies the trace proof's replacement of a signed-swap orbit by
independent coefficient signs; the application-specific equality of those
covariances remains in the finite-frame symmetry module.

## Actual head/tail lp2 geometry and dual norm transport: verified

`LocalHilbertSum.lean` compiled on 5 September 2026 at approximately 19:52 UTC.
`localHilbert_prodL2` proves that if the head has a Hilbert norm within D, the
tail is locally 2-Hilbert in dimensions at most q, and D>=2, then every
q-dimensional subspace of the actual `WithLp 2 (head x tail)` has a Hilbert norm
within D. The proof combines two actual Hilbert models in their Hilbert lp2
product. There is no extra factor two or dimension-dependent loss.

The more general helper `hasHilbertNormWithin_of_norm_sq_sum` needs only linear
maps to the two pieces and the exact identity
`||x||^2 = ||A x||^2 + ||B x||^2`. The actual product theorem applies it to the
head projection and to the finite-dimensional range of the tail projection.

The same module proves `HasHilbertNormWithin.dual` and `.bidual`: the full
Hilbert distortion D passes unchanged to the strong real dual and bidual.
The Hilbert model's dual satisfies the exact parallelogram law by the already
verified direct dual-stability theorem; `InnerProductSpace.ofNorm` then supplies
its actual inner product. Pullback of functionals along the norm comparison
equivalence, followed by scalar normalization, gives the desired two-sided
norm bound. This avoids requiring reflexivity, completeness of the original
space, or a separate Riesz-representation theorem.

`exists_localHilbert_prodL2_threshold` supplies the ambient approximate-
parallelogram threshold version. To identify the actual dual of an lp2 product
with the lp2 product of its duals still requires a separate two-term dual norm
decomposition; that identification is not claimed by this module.

## Actual dual head/tail decomposition: verified

`LocalHilbertSumDual.lean` now closes that two-term dual norm gate. The maps
`prodL2DualFst` and `prodL2DualSnd` restrict an actual product functional to
the coordinate inclusions. `prodL2Dual_norm_sq` proves its squared norm is
exactly the sum of the squared norms of those restrictions. The proof tests
scaled vectors and uses operator norms, avoiding norm attainment and
reflexivity. `localHilbert_prodL2_dual` then gives the same distortion D for
every sufficiently small subspace of the actual product dual, provided the
tail dual is locally 2-Hilbert.

The same file now also proves actual linear isometry equivalences for the
dual and bidual products (`prodL2DualEquiv` and `prodL2BidualEquiv`). Pullback
by a linear isometry equivalence preserves the dual norm. Combining these
gives `localHilbert_prodL2_bidual` with the same distortion D and no
reflexivity assumption. The nested dual statements use the generic predicate
`LocallyHilbertWithin`, whose definition retains the explicit finite
dimension hypothesis. This avoids a Lean instance diamond without changing
the mathematical statement.

## Renorming before a dual-subspace-dual operation

`LocalHilbertQuotient.lean` has compiled the generic bridge: if an actual
linear equivalence from W to W0 has norm at most one, inverse norm at most D,
and W0 has a sufficiently small global parallelogram constant, then the dual
of every arbitrary subspace V of W* is locally eta*D-Hilbert in dimensions
at most q. V itself need not have dimension at most q. The proof transports
V to a subspace of W0*, restricts its actual norm, takes another dual using
the exact preservation of the parallelogram constant, applies the local
threshold, and transports the norm comparison back. This is the quotient
step needed by the dual obstruction. It does not infer quotient stability
merely from a local Hilbert hypothesis on W*.

`LocalHilbertHeadRenorm.lean` now supplies the actual global renorming used
by that bridge. Its target is `WithLp 2 (HilbertHead x tail)`, with the tail
norm unchanged. The forward equivalence has norm at most one, its inverse
has norm at most D, and the target has the tail's parallelogram constant.
`headTail_dual_subspace_dual_localHilbert` accepts an already chosen local
threshold and yields the required property on every dual subspace, with
distortion `D*eta`. This is compatible with the existing recursive parameters;
it does not need a new threshold choice or a new parameter sequence.

For a kernel supplied only by an isometric embedding into a head/tail product,
the appropriate target is its image under this global renorming. The image
inherits the global parallelogram inequality. No surjectivity onto the entire
head/tail product, Hahn-Banach extension, or reflexivity is needed.

## Actual recursive range kernels: verified

`LocalHilbertRecursiveKernelDual.lean` now applies that image construction to
the exact evaluation kernel of an actual diagonal projection range. Its
`recursiveDiagonalRange_kernel_dual_subspaces` theorem says that, for every
subspace V of the kernel's continuous real dual, every finite-dimensional
subspace of V* of dimension at most `3 * 2^(s.block j).order` has a Hilbert
norm within `2 * s.headBound j`. V itself has no dimension restriction.
The same module covers arbitrary inherited block profiles and any isometric
embedding into their finite head and remaining tail.

The finite head is renormed with the full ambient distortion already stored
in the recursive selection. The tail uses the very same chosen local
parallelogram threshold as that selection. Thus this step introduces neither
a new parameter sequence nor a hidden assumption about quotient stability.
`DualSubspaceDualHilbertWithin` abbreviates the exact nested dual property;
it fixes the inherited norm instances before Lean elaborates the dual types.

All these modules compiled and emitted their artifacts. The expanded
`LocalHilbertQuotientAudit.lean` also passed: all eleven selected declarations,
including the actual recursive diagonal-kernel result, have only `propext`,
`Classical.choice`, and `Quot.sound` among their transitive axioms.

## Complex exclusion through realification: verified bridge

The follow-up `ComplexRealDPR.lean` now constructs an actual real
unconditional Schauder basis from any complex one, splitting each basis
vector into itself and its multiple by i. A direct finite convex-cube
bound proves unconditional summability of the split coordinates. Thus a
complex unconditional basis implies finite DPR for the same norm over R.
The file also exposes Mathlib's exact isometry between the real continuous
dual and the complex continuous dual regarded as real. Both primal and
dual complex-basis exclusion wrappers accept an actual whole-space real
isomorphism to a space with infinite real DPR. No complemented-subspace
inheritance principle is used.

The module compiled at 21:28 UTC and all seven selected transitive axiom
checks passed with only the standard three axioms. The planned alternate
complex construction and its exact proof changes are documented in
`complex-realification-shortcut.md`; the finite realification comparison
and global projection assembly are owned by the other workers.

## Final complex corollary: verified

`ComplexCorollary.lean` now proves `ComplexCorollaryStatement` without any
remaining assumptions. The actual pure complex predecessor projection is
transported, as a whole real space, to the verified real coefficient profile.
`ComplexCorollaryAssembly.lean` packages the actual Banach model, sequential
1-unconditional ambient basis, strict projection norm, closed range
completeness, and both basis exclusions. The final theorem supplies its
whole-space equivalence premise with the constructed map.

The theorem compiled and emitted its artifact. Its final transitive axiom
audit completed at 21:40 UTC, with only `propext`, `Classical.choice`, and
`Quot.sound`; see `verification/complex-corollary-axioms.log`.
