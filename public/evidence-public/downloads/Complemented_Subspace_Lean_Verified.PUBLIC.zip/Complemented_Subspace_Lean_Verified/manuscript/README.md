# Mathematical reference

The 15 LaTeX source files in this directory are verbatim copies of the supplied
revised manuscript, included for comparison with the Lean definitions and proofs.
They have not been rewritten to follow the Lean proof.

The formalisation covers the real main theorem, the real and complex main
unconditional-basis corollaries, and the separable nonprimarity corollary.
Including the manuscript does not assert that every later result in it has been
formalised. In particular, the later statements concerning shrinking or
boundedly complete Schauder bases, approximation properties and stabilisation
are outside these verified endpoints.

The project README records the exact Lean statements, the uniformly convex
renormability convention for superreflexivity, and changes in proof strategy.
