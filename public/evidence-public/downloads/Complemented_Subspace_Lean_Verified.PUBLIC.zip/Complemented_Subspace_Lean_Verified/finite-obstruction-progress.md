# Finite analytic workstream

> Component progress log from 5 September 2026. Checkpoints below are historical; current statement conventions are documented in [README.md](README.md), and final verification status is recorded in [the fresh-build log](verification/fresh-root-build.log).

Implementation began 5 September 2026, about 17:40 UTC. This file records the
finite analytic part of the new sustained implementation, for integration into
the main README.

## Verified

- `ComplementedSubspace/FiniteSigns.lean` builds. It defines the uniform average
  as the actual finite sum divided by the sample cardinality and a recursive
  cube of independent Boolean signs. For every real coefficient array of any
  finite length it proves the covariance identity, exact second moment, and
  exact fourth moment `3*(sum a_i^2)^2 - 2*sum a_i^4`. Thus the fourth-moment
  upper bound has the required constant 3. A subsequent direct compiler pass
  also checks the exact mixed fourth moment, scalar linearity, the actual
  coordinate sign vector, and deterministic Euclidean length one for its
  normalization (for positive dimension).
- `ComplementedSubspace/ProductFrameIndex.lean` builds. Its sample space is
  recursively `Unit`, then `Fin 4 × FrameIndex n`, and its cardinality is
  exactly `4^n`.
- `ComplementedSubspace/ProductFrame.lean` passed the direct compiler at about
  18:37 UTC. It defines the actual product frame and proves covariance,
  constant squared length `2^n`, the scalar evaluation second moment, and
  injectivity of coefficient evaluation.
- `ProductFrameMoments.lean` now compiles: its actual finite fourth-order
  kernel equals `2^n` times the verified tensor channel. The concrete paired
  frame fourth moment follows from this identity.
- `FiniteOverlapMoments.lean` and `FiniteOverlapLp.lean` compile. They prove
  the actual overlap sample's second moment is at most `(norm B * norm V)^2`,
  its fourth moment is at most `card * (norm B * norm V)^4 * (5/8)^n`, and the
  interpolated p-moment for every exponent between 2 and 4.
- `FiniteSignsComplex.lean`, `FiniteSignsInterpolation.lean`, and
  `ProductFrameLp.lean` compile. Real and complex finite sign moments have
  the constant 3; finite Holder interpolation and actual lower/upper powered
  Hilbert comparisons are proved.
- `ProductFrameTranspose.lean` compiles: the tensor channel is invariant
  under transposing its input, has symmetric output, and kills `A-A.transpose`.
- `ProductFrameSymmetry.lean` and `ProductFrameTrace.lean` compile. The finite
  signed-swap group acts by actual linear isometric automorphisms of the
  normalized `FrameCoefficient` space; its mixed orbit covariance and exact
  conjugation average `(trace T / 2^n) * identity` are proved.
- `ProductFrameTraceBound.lean` compiles: for arbitrary actual real Hilbert
  factorization `E --A--> H --B--> E`, it proves
  `abs(trace(B*A)) <= (2^n * beta_p / g(n,p)) * norm A * norm B`.
  The witness, finite isometries, covariance replacement, and norm estimates
  are all discharged by proved concrete definitions.
- `ProductFrameSignContraction.lean` compiles and proves the normalized-sign
  coefficient-norm second moment is at most `beta_p^2` after *any* coefficient
  Hilbert contraction. This supplies the uniformly bounded second moment
  that is essential when the exponent tends to two.
- `FiniteOverlapGoodSecond.lean` and `FiniteOverlapBasisColumns.lean` compile.
  They randomize an actual unconditional basis, use an actual lower Hilbert
  embedding and actual first/Hilbert component maps, and derive the good
  second moment `C^2*(beta_p^2+1)` for their concrete analysis/synthesis frame
  matrices. No upper Hilbert-comparison factor appears in this bound.
- `FiniteOverlapRandomization.lean` compiles: the actual double finite mean
  of the randomized coefficient component is bounded by `beta_p` times the
  p-moment root of the concrete overlap energy.
- `FiniteOverlapUpper.lean` compiles: it combines the actual coefficient and
  Hilbert components into the total mean norm bound for projected product
  rows, using the exact involutivity of finite sign multipliers.
- `FiniteOverlapMatrixNorms.lean` compiles: the concrete synthesis and analysis
  frame matrices both have Hilbert operator norm at most `C*H`, derived from
  the actual normalized unconditional basis and Hilbert comparison map.
- `FiniteOverlapBound.lean` compiles: its `finite_basis_overlap_bound` combines
  those matrix estimates with the good second moment and the concrete fourth
  moment. Its assumptions concern actual spaces, operators, basis constants,
  and coordinate identities; no moment or overlap estimate is assumed.
- `FiniteOverlapConclusion.lean` compiles: after the verified scalar
  simplification it proves `g(n,p') * average(norm(P(row))) <= 64*C^3/L`
  whenever the selected dimension is at most `3*2^n` and `2 <= p <= 3`.
- `FiniteOverlapObstruction.lean` compiles: for an actual finite subspace
  `F` of `FrameCoefficient n p` plus a Hilbert space, an actual basis with
  constant at most `C`, and an input map of norm at most `K` whose return
  through the actual first coordinate has trace at least `2^n/2`, it proves
  `L <= 256*K^2*beta_p^2*C^3`. The dimension assumption is `dim F <= 3*2^n`.
  It constructs the orthogonal projection, normalized basis, coordinate
  matrices, all their norm bounds, and both overlap estimates.
- `FiniteDualBasis.lean` compiles: the actual continuous dual has a basis
  with no larger unconditional constant. Every multiplier is exactly the
  adjoint of the original multiplier.
- `FiniteBidual.lean` compiles: actual evaluation gives a linear isometric
  equivalence of each finite-dimensional real normed space with its strong
  bidual. The short norm argument follows mathlib's DoubleDual proof, using
  cached Hahn–Banach and finite dimension, without importing its additional
  weak-star topology results.
- `FiniteBlockObstruction.lean` compiles: it combines actual coordinate
  selection and Hilbert replacement with the finite overlap contradiction.
  The input is an actual finite basis in a normed space with a distinguished
  frame summand and a quantitative local Hilbert tail bound. No assumed
  trace, overlap, or selection lemma remains in this finite-basis endpoint.
- `FiniteBlockDPRLower.lean` compiles: restricting the actual splitting to
  every finite superspace containing the frame block yields a lower bound
  on the original `chiDPR` definition. This step quantifies over all actual
  finite bases of the containing superspace.
- `InfiniteFrameObstruction.lean` and `RecursiveDiagonalDPR.lean` compile.
  An unbounded family of actual distinguished frame summands forces
  `chiDPR = infinity`; the recursive diagonal-range construction is verified
  to satisfy that criterion whenever its frame coordinates occur on an
  unbounded set of indices. In particular the even and odd index sets meet
  this requirement.
- `ComplexFrameCoefficient.lean` and `ComplexFrameRealification.lean` compile.
  They define the actual normalized complex product-frame coefficient norm
  and an actual real continuous linear equivalence to the real frame of
  order one higher. Its operator norm is at most 2, and its inverse norm is
  at most 1, uniformly in the tensor order and every exponent at least 2.

These new results use no `sorry` or new axioms. The finite-workstream audit of
38 principal declarations through the actual selected-subspace obstruction,
continuous dual basis, finite bidual isometry, and recursive actual-range
infinite DPR conclusion passed at about 21:16 UTC:
every transitive dependency uses only `propext`,
`Classical.choice`, and `Quot.sound`. The full project integration remains
a separate obligation.

## Proof correspondence

The manuscript uses normalized coefficient Gaussians to exploit covariance
and scalar moments. The implementation replaces them with a finite, uniformly
weighted cube of real signs. The covariance is unchanged; the exact Gaussian
moment is replaced with the fourth-moment bound and finite interpolation.
This is an actual change of auxiliary random vectors, not a restatement of
the same Gaussian proof. Finite interpolation is now proved; the final
operator trace and total mean overlap estimates are now proved.

The finite witness construction uses products of the four explicit
real frame vectors, replacing the circle and discretization steps. The sample
indices above support the concrete product frame and the projection agent's
tensor projection in the same coordinates.

## In progress

The audit includes the actual obstruction, the two dual modules, and the
verified infinite DPR integration chain. The final
main-theorem assembly combines that chain with the actual projection and
ambient geometry workstreams. In the verified finite theorem the retained
trace gives `1 <= 4*K^2*beta_p^2*theta`; it does not by itself give
`theta >= 1/2`. The constants `K` and `C` remain separate until the final
selected-basis bound `C = D*K` is substituted.

The real finite contradiction and the recursive actual-range infinite DPR
conclusion are now proved. The complex analogue and the complete main-theorem
assembly remain separate integration obligations.

## The finite trace simplification (now proved in Lean)

Let `x` be a coefficient Hilbert unit vector with frame norm `g`, and let `U`
range uniformly over the finite tensor sign/swap symmetries. These are
isometries for the finite frame norm. Their conjugation average is
`E_U U⁻¹ T U = (tr T / q) I`, and the orbit of `x` is isotropic with covariance
`I/q`. For any factorization `T = B A` through a Hilbert space,

```
|tr T| g / q
  = ||E_U U⁻¹ B A U x||E
  ≤ ||B|| E_U ||A U x||₂
  ≤ ||B|| sqrt(E_U ||A U x||₂²)
  = ||B|| sqrt(E_Z ||A Z||₂²)
  ≤ ||B|| ||A|| beta_p.
```

Here `Z` is the normalized coefficient sign vector and
`beta_p = 3^((p-2)/(2p))`. Equality of the two middle second moments uses only
covariance and the Hilbert norm on the target of `A`; it does not require the
orbit coordinates to be independent. Thus the trace estimate follows with
constant `beta_p/g` directly for each factorization. This avoids both the
general Hilbert-factorization norm and the manuscript's Banach–Mazur
optimality argument for an invariant Hilbert norm. The norm invariance,
averaged-conjugation identities, and covariance replacement of the concrete
finite frame are proved in `ProductFrameSymmetry`, `ProductFrameTrace`, and
`ProductFrameTraceBound`; they are not additional assumptions.

## Complex proof by whole-space realification (verified block comparison)

The complex existential corollary can use the complex-linear extension of
the real four-row projection. Its coefficient space at order `n`, regarded
as a real normed space, is uniformly isomorphic to the real coefficient
space at order `n+1`. The explicit real linear map sends a coefficient
`a + i*b` to the two real coefficient arrays `a,b`. For each sampled complex
number `z`, the additional real factor produces

```
sqrt(2)*Re(z), sqrt(2)*Im(z), Re(z)+Im(z), Re(z)-Im(z).
```

Their mean square is exactly `|z|^2`. Finite Jensen for `p >= 2` gives the
lower p-moment comparison, and the pointwise bound by `2*|z|` gives the
upper comparison. Finite Fubini then proves that the actual coefficient
norms satisfy `norm_complex <= norm_real <= 2*norm_complex`. These are
Lean-checked norm comparisons, including the normalization by `4^n`.

Consequently, choosing complex tensor orders one less than the already
verified real recursive orders lets the entire underlying-real diagonal
range be compared with a pure real frame range. A uniform equivalence on
each block lifts to the outer l2 sum. The complex obstruction can then use
restriction of finite complex bases to real bases and real DPR invariance
under whole-space isomorphisms. This route does not require inheritance of
DPR under arbitrary complemented subspaces. Those scalar-restriction and
whole-profile integration steps are owned by the other workstreams.

This is a deliberate change from the manuscript's complex moment proof.
The earlier possible complex fourth-moment routes below are retained as
mathematical notes; they are not needed for the selected formal proof.

## Earlier complex moment alternatives (not used in the current route)

The same four *real* frame directions may be used inside complex `ell_p`.
They retain complex Hilbert covariance `I`, and real frame-supported witness
vectors have the same `alpha_r` moments. Consequently the real positive gap
`log(32/25)/8` can be used for the complex existential corollary too; the
six-point complex frame is not required by that conclusion.

The recursive real map `tensorMoment n` has symmetric output and is invariant
under transposing its input. Both properties follow from `circleLift` by
induction, starting with the one-dimensional zero-fold space. Therefore it
annihilates every antisymmetric real matrix. Extend it complex-linearly. If
`b = x + i y`, then

```
D_n(bb*) = D_n(xxᵀ) + D_n(yyᵀ),
```

because the imaginary part `yxᵀ - xyᵀ` is antisymmetric. The Hilbert–Schmidt
triangle inequality and the already verified real rank-one bound give

```
||D_n(bb*)||HS
  ≤ (5/8)^(n/2) (||x||₂² + ||y||₂²)
  = (5/8)^(n/2) ||b||₂².
```

Thus there is no need for a separate complex Kraus/multiplicativity induction.
This derivation still requires formal complex matrix/HS wrappers and the
genuine complex unconditionality and ambient geometry statements. The complex
scalar projection-energy bound is now proved by the projection workstream.
The remaining complex obligations are not claimed as solved. Real signs in a moment calculation also do
not change the requirement that complex basis multipliers allow every scalar
of modulus at most one.

A still simpler option for the **paired** complex moment is to expand each
absolute square into its real and imaginary squares. Replicate columns on
indices `(i, sigma, tau)` with two choices for each component, taking
`B'_(i,sigma,tau) = (B_i)_sigma` and
`V'_(i,sigma,tau) = (V_i)_tau`. The complex sampled overlap energy is exactly
the real overlap energy of these matrices. They have `4k` columns. Each of
their four source blocks has operator norm at most the original complex
operator norm; the triangle inequality and four-term Cauchy–Schwarz give
`||B'|| <= 2||B||` and `||V'|| <= 2||V||`. The verified real estimate therefore
supplies the bound with a prefactor `1024`:

```
E[S^4] <= 1024*k*(||B||*||V||)^4*(5/8)^n.
```

This prefactor is independent of `n` and the ambient dimension. Its contribution
after interpolation is `1024^((p-2)/(2p))`, which tends to one as `p` decreases
to two, and the positive exponential gap is unchanged. This avoids developing
a sharp complex Hilbert–Schmidt synthesis theorem. The expansion and the
complex-to-real block operator norm bounds still need Lean proofs.
