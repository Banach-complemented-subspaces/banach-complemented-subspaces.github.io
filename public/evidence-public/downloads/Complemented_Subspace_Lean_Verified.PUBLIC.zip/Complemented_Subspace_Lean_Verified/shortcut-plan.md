# A targeted route to the main conclusions

> Historical working note from 5 September 2026. Status labels and proposed routes below record that stage of the implementation. See [README.md](README.md) for the current statements and proof route, and [the fresh-build log](verification/fresh-root-build.log) for final verification status.

5 September 2026. This assessment concerns the real main theorem, the main corollary over both real and complex scalars, and the stated nonprimarity consequence. It does not include every later refinement or every general theorem cited in the manuscript. The LaTeX is unchanged. A different construction is legitimate here because the conclusions are existential.

## Assessment

Ad hoc proofs can substantially reduce the formalization. Four new parts now compile: the arbitrary real tensor moment estimate, the four-point frame identities and projection, the Hilbert projection-complement estimate, and the analytic energy inequality for the finite-frame projection argument. The tensor implementation took about 19 minutes; the Hilbert complement proof took about ten minutes. The energy proof was completed in about 7½ minutes after its missing dependencies became available. These are measurements of particular subtasks, not an extrapolated completion rate for the whole theorem.

Twelve hours of active wall-clock work with parallel proof development is a plausible stretch target. There is not yet enough evidence for high confidence in finishing **all** the stated conclusions in that time. The critical unmeasured work is the local Hilbert approximation, finite selection/overlap assembly, and the lattice obstruction for the universal nonisomorphism conclusion. Calling a theorem conditional on any of those missing ingredients complete would not meet the target.

## Change the finite construction

The scalar inequalities, their derivative and Lipschitz interpretation, and the finite projection energy estimate now compile in `ProjectionPerturbation.lean`. In particular, for bounded real coordinate vectors satisfying the Pythagorean identity, the theorem gives `sum |a_i|^p ≤ sum |x_i|^p + (9/4)*card*(p-2)^2`. The normalization and operator-norm wrapper that turn this into the displayed bound for a specific projection remain to be implemented. The new theorem states its coordinate and Pythagorean hypotheses explicitly.

Use the four real frame directions, or the six complex frame directions, already appearing in the manuscript's moment argument. Their second and fourth moments are exactly the required ones. Form finite products of these frames and put the coefficient space directly inside the corresponding finite `ell_p` space.

This avoids continuous circles/spheres, sampling and quadrature. A first-derivative argument gives the fixed-dimensional projection estimate

\[
\|Q\|_{p\to p}\le1+\tfrac94m^{3/2}(p-2)^2
\quad(2\le p\le3),
\]

where m is four or six. Tensorizing yields projections with norms tending to one. The quadratic dependence on p-2 matters: a merely continuous or linear-error estimate would not justify the required parameter choice.

Replace all Gaussian coefficient vectors by normalized finite sign vectors. The needed covariance and second/fourth-moment estimates follow from finite expansion and Cauchy-Schwarz. Interpolation in this proof is just scalar finite Hölder; no general interpolation theorem is needed.

Finite frames are not rotationally invariant, so separate the witness norm g from a uniform upper Hilbert comparison H. The valid choices are

\[
g=\alpha_p^n,\qquad H=2^{n(1/2-1/p)}.
\]

With the revised overlap scale in `finite-analytic-shortcuts.md`, the positive exponent gaps are `log(32/25)/8` over the reals and `log(729/500)/12` over the complex field. Thus the replacement preserves the decisive separation, rather than merely reproducing the fourth moments. Choose `n=k^3`, `p=2+k^(-2)`; only an existential subsequence is needed later.

## Smaller dependencies for each conclusion

| Original machinery | Sufficient tailored replacement | Current status |
|---|---|---|
| King's multiplicativity theorem | Real polarization and explicit block induction; complex finite Kraus Gram identity and block induction | Full real arbitrary-n estimate compiled; complex argument checked mathematically |
| Circle/sphere integration, Gamma formulas, sampling | Four/six-point frames, finite sums, elementary scalar derivatives | Real frame identities, projector and analytic energy estimate compiled; complete alternative parameter/overlap calculation checked mathematically |
| Gaussian theory | Finite coefficient signs, covariance and fourth-moment expansion | Mathematically checked, not yet implemented throughout |
| General Hilbert factorization norm and Banach-Mazur theory | State the trace bound directly for each pair of maps factoring through a finite Hilbert space | Proposed reduction; symmetrization and selection still need proofs |
| Passer's quantitative theorem | Compactness of normalized norms in each fixed dimension, then exact parallelogram law | Mathematically checked; main unmeasured geometry task |
| Stern's sharp projection estimate | Apply local Hilbert approximation to span{x,Px}, then the elementary Hilbert complement bound | Hilbert bound compiled; transfer and local approximation still required |
| General GL duality | Coordinate approximations and the adjoint retraction for the explicit ambient space | Mathematical route checked; dual approximation remains |
| General local reflexivity in the lattice corollary | Use order completeness of dual lattices and the available primal/dual obstruction; see the detailed scope audit | Band-projection infrastructure found; simultaneous spectral approximation still required |
| General superreflexivity equivalences | Explicitly use equivalent uniformly convex renormability as the definition | Legitimate standard definition choice; actual ambient uniform convexity still must be proved |

One finite-rank correction lemma should be reused for the ambient GL bound, the implication from an unconditional Schauder basis to finite DPR constant, and turning lattice approximations into exact finite superspaces. It must preserve the original norm quantitatively. This is a better target than separate general theories for each application.

## What cannot be skipped

The real theorem still needs both complementary projections, all four primal/dual GL-DPR statements, the prescribed ambient space and its uniform convexity. The main corollary needs an actual scalar unconditional Schauder basis on the ambient space and absence of any such basis on the two target spaces. The nonlattice assertion quantifies over **all** Banach lattices up to bounded linear isomorphism; excluding a lattice order for the inherited norm is insufficient.

An arbitrary real Banach lattice's dual is order complete. This provides a narrower route to the nonlattice contradiction than proving local reflexivity for arbitrary Banach spaces. BanLat supplies dual lattice order completeness, band projections and Boolean refinements. A finite simultaneous spectral approximation and its exact-superspace perturbation remain new proof work. For the dual nonlattice conclusion, the preferred route repeats the DPR obstruction directly in the bidual using isometric duality of two-term sums, finite-dimensional bidual isometries, and the Hadamard bound. No global reflexivity theorem is needed for that route. See `corollary-scope-assessment.md` for the precise logic.

The complex main corollary does not assert numerical GL/DPR constants. A direct obstruction to complex unconditional bases can therefore avoid rebuilding the entire GL constant API over complex scalars. Its basis multipliers still must allow all complex scalars of modulus at most one; real sign averages in the moment calculation do not remove that requirement.

The full local-Hilbert bridge is dimension-uniform in the ambient block sizes. Applying ordinary equivalence of norms separately in each large block would destroy the argument. Likewise, proving uniform convexity of each finite block separately does not prove uniform convexity of their infinite sum; a common modulus must be supplied.

## A twelve-hour attempt should have falsifiable checkpoints

One follow-up compiler test initially encountered a concrete environment block: 110 calculus cache files were missing, sandbox downloads failed, and the escalation request was aborted. The user subsequently reauthorized the download; the retry succeeded and the derivative, Lipschitz and energy proofs now compile. The early draft under `experiments/unverified/` is superseded by the verified active module and excluded from the source archive. `get-mathlib-cache.ps1` records the working download setup. This delay is a reason to distinguish mathematical proof time from environment and approval time when assessing a wall-clock deadline.

The following is a proposed allocation, **not a measured duration forecast or a commitment to start a twelve-hour run**. Independent workstreams would run concurrently, with a shared pinned environment and exact lemma interfaces.

- **First three hours:** finish finite-frame/tensor/projection lemmas and finite moment tools; in parallel, obtain a compiling local-Hilbert bridge and a compiling simultaneous approximation lemma for order-complete lattices. These last two are the deadline-confidence gates. If either remains only an informal plan, confidence in a full twelve-hour finish is not warranted.
- **By six hours:** assemble the actual finite trace/overlap/selection obstruction, together with uniform convexity and the dual transfer needed later. At this point the mathematical hypotheses consumed by the infinite-sum proof should be proved, not left as placeholders.
- **By nine hours:** obtain the real existential main theorem and close the remaining real/complex corollary bridges, including the universal nonlattice contradiction.
- **Final three hours:** integrate the complete package, check exact statement semantics and norm conventions, run the whole-project transitive axiom audit, and fix actual failures. This reserve is part of the twelve-hour ceiling.

If these checkpoints slip, report the failed gate rather than silently weaken the conclusion. More helpers cannot guarantee a deadline when several later lemmas depend on one unproved bridge. Selective BanLat reuse also has an unmeasured version-porting cost: its audited version uses Lean 4.32.1 while this project uses 4.34.0-rc2.

## Supporting files

Final combined verification: **14 mathematical modules build successfully**, and the whole-project audit passes for **374 declarations** in the `ComplementedSubspace` namespace. Their transitive axioms are restricted to `propext`, `Classical.choice`, and `Quot.sound`. This count includes definitions, instances and generated declarations, not only theorems. The main existence theorem remains unproved. Reproducible logs are `verification/shortcut-build.log` and `verification/shortcut-axioms.log`.

- `ComplementedSubspace/TensorMoment.lean`: proved real tensor estimate and paired-column bound.
- `ComplementedSubspace/FiniteFrame.lean`: actual four-point vectors, covariance, fourth-moment map and symmetric idempotent projection.
- `ComplementedSubspace/HilbertComplement.lean`: proved Hilbert projection-complement norm bound.
- `ComplementedSubspace/ProjectionPerturbation.lean`: proved scalar, derivative, Lipschitz and finite energy inequalities for the quadratic projection argument; the operator-norm wrapper is not asserted.
- `finite-analytic-shortcuts.md`: full alternative finite construction and constants.
- `geometry-shortcut-assessment.md`: precise qualitative geometry replacements.
- `corollary-scope-assessment.md`: exact end-goal audit and the nonlattice/complex obligations.

Only the Lean declarations that pass the compiler and axiom audit are counted as formalized. Mathematical derivations in these notes are recorded separately.
