# Order-complete lattice workstream

The proved approximation is simultaneous finite disjoint approximation in the **original norm**:
for a finite family `x_i` and a positive tolerance, construct a finite positive
pairwise disjoint family whose linear span approximates every `x_i`.
The shared normed finite-rank correction turns this approximation into an exact
superspace suitable for DPR.

The proof uses a common positive majorant `u = sum_i |x_i|`, principal
band projections at finitely many scalar thresholds, and finite partitions of
the identity. Threshold bisection is an alternative to representation theory;
all errors are order bounded by a small multiple of `u`, so the lattice's solid
norm gives the required error in its original norm.

`ComplementedSubspace/LatticeSpectral.lean` contains the complete proof:

1. A principal band of `v⁺` projects `v` to `v⁺`, while its complement gives
   `-v⁻`. Applying this to `x - t • u` gives a scalar threshold cut.
2. A finite partition is a finite family of disjoint projection bands whose
   projections sum to the identity. Each cell can be split independently by a
   threshold, preserving this identity.
3. Repeated midpoint splits give dyadic scalar order intervals. Summing their
   lower endpoints produces `y` with `0 ≤ x-y ≤ 2^(-n) • u`.
4. The solid norm converts that bound to arbitrarily small original-norm
   error. Positive and negative parts treat signed vectors.
5. Common refinements preserve both old cell spans. Induction on a finite
   family therefore preserves every previously obtained approximant and error.

`LatticeBasis.lean` removes zero cells, takes the basis of the remaining span,
and proves contraction for every real scalar multiplier of absolute value at
most one. `LatticeApproximation.lean` passes the result to the shared finite-rank
correction interface and applies it to dual lattices.

`LatticeSpectral.lean` compiled successfully on 5 September 2026 at 18:26:39 UTC.
This includes the complete simultaneous finite disjoint approximation
theorem, not just the threshold or partition interface. `LatticeBasis.lean`
compiled at 18:38:57 UTC: it supplies the basis of the exact cell span and the
bound one for all admissible scalar multipliers. `LatticeApproximation.lean`
compiled at 18:42:09 UTC, including `chiDPR_dual_lattice_le_one`: the dual of
every real Banach lattice has DPR constant at most one. This completes the
spectral-approximation-to-DPR gate about 65 minutes after the run began.

The five principal approximation/basis/DPR declarations passed their transitive
axiom audit: only `propext`, `Classical.choice`, and `Quot.sound` occur.
The log is `verification/lattice-axioms.log`.

`DPRIsomorphism.lean` also compiles. It proves DPR finiteness invariant under a
bounded linear isomorphism by transporting finite superspaces and bases, with
an explicit finite distortion bound. It requires no completeness assumption
and makes no assertion that DPR passes to arbitrary complemented subspaces.

The dependency closure of BanLat's principal projection property and dual
lattice theorem has been selectively vendored. Its source, license, version,
and port changes are documented in `BanLat/PORTING.md`.

All 21 vendored modules, including the dual/Riesz--Kantorovich closure, compiled
under Lean 4.34.0-rc2 on 5 September 2026. The upstream mathematical proofs needed
no changes; `Basic.lean` needed explicit imports after replacing its broad tactic
import.

This route assumes the principal projection property, supplied for order-complete
lattices by BanLat. It does not assert false disjoint approximation in arbitrary
Banach lattices such as `C[0,1]`. Universal nonlattice conclusions instead apply
the approximation theorem to dual lattices, which are order complete.

`LatticeNonisomorphism.lean` now compiles. It proves that infinite DPR constant
on the dual rules out an isomorphism of the primal with any real Banach lattice.
Applying the same theorem to the dual gives both universal nonlattice conclusions
from explicit primal-dual and bidual DPR obstructions. It does not manufacture
those obstructions: they remain inputs from the finite-block construction.
The isomorphism transport and these two nonisomorphism declarations pass the
standard three-axiom audit (`verification/lattice-isomorphism-axioms.log`).

The next shortcut uses the actual coordinate lattice structure of the ambient
Hilbert sum. Its primal finite-dimensional approximation follows from density
of finite disjoint scalar spans. Its dual approximation follows immediately
from the general dual-lattice theorem. Consequently the GL upper bound on the
ambient dual does not require an explicit duality theorem for an infinite sum.
The separate bidual DPR obstruction still requires the finite block duality
arguments developed by the other workers. These new ambient bounds are proved in `AmbientFiniteApproximation.lean`.

> Component progress log from 5 September 2026. Checkpoints below are historical; current statement conventions are documented in [README.md](README.md), and final verification status is recorded in [the fresh-build log](verification/fresh-root-build.log).

`AmbientFiniteApproximation.lean` and `GLDualRetraction.lean` now compile. The
ambient primal and dual both have DPR and GL constants at most one. The dual
of any projection range has GL constant at most the projection norm whenever
the ambient dual has GL constant at most one, including the zero projection.
All seven principal new declarations passed the transitive standard three-axiom
audit; see `verification/ambient-lattice-bounds-axioms.log`.

`FiniteCubeBound.lean` and `SchauderDPR.lean` now compile. For every real
unconditional Schauder basis, Mathlib bounds the finite projection norms by
`nnnormProjBound`. Convexity of the finite sign cube bounds all scalar
multipliers by twice this bound. The finite spans therefore satisfy the shared
approximation property with `max 1 (2 * nnnormProjBound)`, giving this quantitative
upper bound on DPR. Infinite DPR consequently rules out every real unconditional
Schauder basis, with no change of norm or appeal to a general renorming theorem.
All five principal declarations passed the standard three-axiom audit in
`verification/schauder-dpr-axioms.log`.

`ProjectionCorollaries.lean` compiles and its three principal declarations pass
`verification/projection-corollaries-axioms.log`. It supplies completeness of an
idempotent projection range, the exact `HasSeparatedRange` conjunction from the
two DPR obstructions and ambient GL bounds, and all four real corollary negations
from the primal, dual, and bidual DPR obstructions. Each obstruction remains an
explicit input; no result from the unfinished block construction is assumed.


`ComplexAmbient.lean` and `ComplexAmbientSchauder.lean` now compile. They reuse
the scalar-generic finite-Lp Clarkson estimates and the common-modulus outer
L2 proof to instantiate uniform convexity for the actual complex ambient norm.
The space is complete and separable. Its scalar coordinate basis is reindexed
by the naturals and proved one-unconditional for every complex multiplier of
modulus at most one, including arbitrary complex phases. Coordinate norm
comparison is used directly, so no lattice order on the complex scalars and
no realification transfer are introduced. `DenseContractionsScalar.lean` is
the field-generic version of the already proved dense-contraction convergence
lemma. The complex obstruction remains separate; these ambient properties do
not assert the complex existential corollary by themselves.
The five complex ambient declarations also passed the standard three-axiom
audit, recorded in `verification/complex-ambient-axioms.log`.

`ComplexProjectionEnergy.lean` and `ComplexFrameProjection.lean` compile. The
same real four-point projection acts complex-linearly on the actual finite
complex Lp space, is idempotent, and has norm at most `1 + 18 * (p - 2)^2`
for `2 ≤ p ≤ 3`. The scalar energy difference is evaluated at complex coordinate
norms, using the reverse triangle inequality. The complex Pythagorean identity
is the sum of the existing real and imaginary identities. This avoids any
integration-based theorem on complexification of Lp operators and preserves
the constant 18. The complex tensor slice argument is compiled in `ComplexTensorProjection.lean`.


The tensor powers are actual complex matrices obtained by complexifying the
real tensor powers. They are idempotent and their PiLp operator norms are at
most `exp (18 * n * (p - 2)^2)`. Nonzero idempotence gives the lower bound one;
therefore the norms tend to one whenever `n * (p - 2)^2` tends to zero. All seven
principal complex energy/projection/tensor declarations passed the standard
three-axiom audit in `verification/complex-projection-axioms.log`.


`SelectedHilbertReplacement.lean` compiles. It replaces only the selected tail
space by its actual HilbertNormModel, retaining the first summand's original
Banach norm. The concrete map into `WithLp 2 (E × H)` is contractive, injective,
and has inverse distortion at most D. Its inherited image has the same dimension,
and a K-unconditional basis transports with constant at most D*K. The lifted
selected map has norm at most K, the first-coordinate projection has norm at
most one, and their composition is exactly the original compressed endomorphism,
so its trace is retained without any additional loss.

The six principal Hilbert replacement declarations passed the standard three-axiom
audit in `verification/selected-hilbert-replacement-axioms.log`.
`FiniteSelectedHilbertModel.lean` now consumes the proved frame coordinate
selection theorem directly. It produces an actual subspace of `E ⊕₂ H` of
dimension at most `3 * dim E`, a basis of constant at most `D*K`, and maps
of norms at most K and one whose compressed trace is at least `dim E / 2`.
The local Hilbert hypothesis is required only through dimension `3 * dim E`.
Both exported theorems passed `verification/finite-selected-hilbert-model-axioms.log`.
The factorization records explicitly that its return map is the actual first
coordinate, as needed for the later overlap estimate.

`NormalizedHilbertSynthesis.lean` compiles. Each basis vector is divided by
the norm of its image under the specified Hilbert equivalence. Every coordinate
multiplier, and hence the unconditional basis constant, remains exactly the
same. Finite sign averaging gives an actual Euclidean synthesis equivalence
whose operator norm and inverse norm are both at most K times the Hilbert
comparison scale. All five principal exports passed the standard three-axiom
audit in `verification/normalized-hilbert-synthesis-axioms.log`.

`SelectedCoefficientHilbert.lean` compiles and its five geometry declarations
pass `verification/selected-coefficient-hilbert-axioms.log`. The identity on
frame coefficients and the identity on the Hilbert tail define the actual
product equivalence. Its restriction to any selected subspace preserves the
first-coordinate formula and dimension, contracts the norm, and has inverse
comparison scale `realFrameHilbertScale n p`. The general normalized-synthesis
interface remains separate, avoiding a redundant large expanded existential
whose Lean elaboration repeatedly exhausted its heartbeat budget.

`SelectedProjectionSetup.lean` compiles. Finite dimensionality is transported
explicitly to the named Hilbert image, giving its genuine orthogonal projection.
The map from coefficient Euclidean space projects `(x,0)` orthogonally and
returns through the selected equivalence. Its Hilbert image and tail component
are contractions. The first-coordinate compression is an actual matrix of
Euclidean operator norm at most one. The source proves the exact norm-square
decomposition, coordinate-square bound and coefficient pairing identity needed
by both overlap estimates. All eight principal declarations passed
`verification/selected-projection-setup-axioms.log` with the standard three axioms.

`SelectedFrameBasis.lean` retains and verifies the actual selected-basis
normalization, exact unconditional constant, and coordinate Euclidean norm
bound. Its three exports passed `verification/selected-frame-basis-axioms.log`.
The redundant concrete matrix wrapper was archived as a text draft after
inference timeouts; the finite-obstruction worker connected the same normalized
basis to the general matrix estimates inside the actual overlap theorem.

`FiniteHeadHilbert.lean` and `RecursiveHeadHilbert.lean` compile. A full scalar
block uses its Euclidean norm multiplied by `N^(1/p - 1/2)`, giving exact
distortion `N^(1/2 - 1/p)`. Arbitrary inherited subspaces keep this bound, and
finite dependent lp2 sums preserve a common factor without additional loss.
The recursive wrapper therefore gives the actual finite profile head
`lp (fun i : Fin j => S i.val) 2` a Hilbert norm within `headBound j`; its
continuous dual has the same bound. The model is explicit through the shared
HilbertNormModel interface. A coordinate injection supplies finite dimensionality
of finite lp2 heads, so the model spaces also receive completeness instances.
All nine exports passed `verification/finite-head-hilbert-axioms.log` with only
the standard three axioms.

`RecursiveTailHilbert.lean` and `RecursiveKernelHilbert.lean` compile. The
recursive exponent tolerance gives a common approximate parallelogram estimate
on every later inherited block subspace. Passing this estimate through the
dependent lp2 tail gives Hilbert distortion at most two on subspaces of dimension
at most `3 * 2 ^ (s.block j).order`. The actual coordinate kernel embeds
isometrically into the finite head and later tail, with the exact sum of squared
norms. Combining these estimates gives distortion exactly `s.headBound j`,
without a further factor, both for profile evaluation kernels and for kernels
inside the actual diagonal projection range. All five principal exports passed
`verification/recursive-kernel-hilbert-axioms.log` with the standard three axioms.

`LocalHilbertEmbeddedRenorm.lean` compiles. An isometric embedding of `W` into
`E`, followed by a global renorming equivalence from `E` to `F`, restricts to an
actual equivalence from `W` onto the image of its range in `F`. Both operator
norm bounds and the approximate parallelogram estimate pass to this image.
The verified dual-subspace renorming theorem then applies to the actual `W`,
with distortion product `D * eta`. This avoids requiring the coordinate-kernel
embedding to cover the entire head/tail product. Its four principal exports
passed `verification/local-hilbert-embedded-renorm-axioms.log`, using only the
standard three axioms.

`FiniteProductObstruction.lean` and `FiniteDualDPRLower.lean` compile. The
finite frame obstruction applies through an actual isometric product
decomposition. Given the specified local geometry of duals of arbitrary
subspaces of the tail dual, `16 * K <= D`, and the recursive overlap separation,
the actual continuous dual of the whole product has DPR constant at least `K`.
The proof takes the genuine continuous dual of a finite superspace and uses
the finite bidual isometry on the distinguished summand; the dual basis keeps
the original unconditional bound. Inherited norm instances on the mapped tail
subspace are fixed before taking its dual, to avoid an elaboration ambiguity.
Both exports passed `verification/finite-dual-dpr-lower-axioms.log`, using only
the standard three axioms.

`LpUniformEquiv.lean` compiles. Mathlib's existing `lp.mapCLM` supplies the
forward and inverse maps from a uniformly bounded family of coordinate
equivalences. Their inverse identities hold coordinatewise, giving a genuine
continuous linear equivalence of dependent lp spaces with exactly the same
uniform operator bounds. The construction works over any nontrivially normed
field and for every outer exponent at least one, including the real outer lp2
sums needed for the complex realification comparison. All six exports passed
`verification/lp-uniform-equiv-axioms.log` with the standard three axioms.

`LpSubmoduleScalar.lean`, `ComplexReindexedFrameProjection.lean`, and
`ComplexRecursiveProjection.lean` compile. Generic isometric conjugation
transports the complex tensor matrix to the ambient finite coordinate indexing,
preserving its norm and giving the actual range equivalence. The complex
construction uses tensor order `n_j - 1`, while retaining the recursively
selected exponents. Its quadratic error is bounded by that of order `n_j`, so
the pure diagonal projection is idempotent with norm between one and
`exp (18 * eta)`. Choosing `eta = log B / 36` makes this norm less than any
specified `B > 1`. A scalar-generic range-profile isometry identifies its actual
range with the dependent lp2 sum of its complex block ranges. This construction
selects the frame range in every coordinate; the real alternating projection
is untouched. All ten principal exports passed
`verification/complex-recursive-projection-axioms.log` with the standard three
axioms.
