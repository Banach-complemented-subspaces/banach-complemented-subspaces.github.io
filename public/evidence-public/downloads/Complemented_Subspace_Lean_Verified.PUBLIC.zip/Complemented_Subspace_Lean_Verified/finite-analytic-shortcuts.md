# Finite analytic shortcuts for the Lean construction

> Historical working note from 5 September 2026. Status labels and proposed routes below record that stage of the implementation. See [README.md](README.md) for the current statements and proof route, and [the fresh-build log](verification/fresh-root-build.log) for final verification status.

Assessment of the manuscript's tensor, overlap, parameter and sampling arguments. The complete alternative construction below is a mathematical derivation, not a completed Lean theorem. Selected real-frame identities and the analytic energy estimate have since been compiled in `FiniteFrame.lean` and `ProjectionPerturbation.lean`; see `shortcut-plan.md` for exact verified scope. The existing manuscript need not be changed. The alternative below constructs different witnesses to the same existential conclusions.

## A fixed finite frame can replace the circle and sphere

Use the projective vectors already appearing in the manuscript's fourth-moment proof:

- Real case: `e1`, `e2`, `(e1+e2)/sqrt(2)`, `(e1-e2)/sqrt(2)`, uniformly on four points.
- Complex case: add `(e1+i e2)/sqrt(2)` and `(e1-i e2)/sqrt(2)`, uniformly on six points.

Write `m=4` or `m=6`, call the sampled unit vector `u`, and set `w=sqrt(2) u`. Direct finite matrix calculations give precisely the original covariance and fourth-moment formulas:

\[
\mathbb E[ww^*]=I,\qquad
\mathbb E[uu^*Auu^*]=\mathcal D(A)/2.
\]

Thus the matrix tensor estimate already under investigation applies unchanged. Define `E(n,p)` as the coefficient space with norm obtained from the finite probability average of `|<b,W>|^p`, where `W` is the product of `n` copies of `w`. Its ambient space is already a finite-dimensional `ell_p` space of dimension `m^n`. There is no discretization step or conditional expectation approximation.

For every **frame-supported** unit vector `v`, the scalar moments are the same:

\[
\alpha_r^r=
\begin{cases}
(2^{r/2}+2)/4&\text{over }\mathbb R,\\
(2^{r/2}+4)/6&\text{over }\mathbb C.
\end{cases}
\]

The first coordinate has one inner product of modulus `1`, one zero, and `m-2` of modulus `1/sqrt(2)`; the same holds at every frame point. Consequently, for every product of frame vectors `x`,

\[
\|x\|_E=\alpha_p^n=:g,
\qquad \|\langle\cdot,x\rangle\|_{E^*}\le\alpha_{p'}^n.
\]

It is essential **not** to assert the original rotation-invariant upper Hilbert bound using this same `alpha_p`. Finite frame moments vary in other directions.

## An elementary quadratic projection estimate

Here is a replacement for the continuous one-factor projection estimate and its first-order cancellation. If `Q` is any Euclidean orthogonal projection on `K^m`, `2 <= p <= 3`, and `epsilon=p-2`, then

\[
\|Q\|_{\ell_p^m\to\ell_p^m}
\le 1+\frac94m^{3/2}\epsilon^2.
\]

For `m=4` this is `1+18 epsilon^2`; for `m=6`, the simpler upper bound `1+36 epsilon^2` suffices. This applies to the finite frame's exact orthogonal projection, whose matrix is `Q(r,s)=(2/m)<u_s,u_r>`.

Proof: put `h_p(t)=t^p-t^2` on `[0,1]`. Convexity gives

\[
t^{1+\epsilon}\ge(1+\epsilon)t-\epsilon,
\]

so `0 <= t-t^(1+epsilon) <= epsilon`. Therefore

\[
|h'_p(t)|=|(2+\epsilon)t^{1+\epsilon}-2t|\le3\epsilon.
\]

There is no second derivative or logarithmic singularity to handle at zero. Normalize `|x|_2=1`, set `a=Qx`, `b=x-a`, and use orthogonality. Every coordinate modulus of `x` and `a` is at most one. The mean value estimate, reverse triangle inequality (also over the complex field), and Cauchy-Schwarz yield

\[
\begin{aligned}
\sum_i|a_i|^p-\sum_i|x_i|^p
&=-|b|_2^2+\sum_i\bigl(h_p(|a_i|)-h_p(|x_i|)\bigr)\\
&\le-|b|_2^2+3\epsilon\sqrt m|b|_2
\le\tfrac94m\epsilon^2.
\end{aligned}
\]

Power-mean comparison gives `sum |x_i|^p >= m^(1-p/2) >= m^(-1/2)`. Divide by this lower bound and take the `p`-th root; `(1+t)^(1/p) <= 1+t` finishes the proof. Homogeneity removes the normalization; the zero vector is immediate.

Finite Fubini shows that the tensor projection has norm at most `(1+C epsilon^2)^n`. This tends to one if `n epsilon^2 -> 0`.

## Replace rotation invariance by a crude upper norm bound

Isotropy and the constant length `|W|_2=sqrt(q)`, `q=2^n`, give

\[
|b|_2\le\|b\|_E\le H|b|_2,
\qquad H=q^{1/2-1/p}.
\]

The upper estimate follows directly from `|f_b|^p <= ||f_b||_infty^(p-2) |f_b|^2`; no operator interpolation theorem is needed.

In the overlap proof, replace the old `G` by `H` in the synthesis bounds and fourth-moment upper estimate. The problematic factor is only

\[
H^{4(p-2)/p},\qquad
\log H^{4(p-2)/p}=\frac{2n(p-2)^2\log2}{p^2}\longrightarrow0.
\]

The old product witness constant is retained separately as `g=alpha_p^n`. It is used for the trace estimate, where only a large witness norm is needed.

## All Gaussian uses can be replaced by finite sign averages

Take normalized coefficient signs `Z=q^(-1/2) sum_i epsilon_i e_i` instead. They have covariance `I/q` and deterministic squared Euclidean norm one, over either field. Every expectation used as a Hilbert-Schmidt or trace identity in the manuscript therefore remains valid.

For scalar complex or real coefficients `a_i`, finite expansion gives

\[
\mathbb E|\sum_i\epsilon_i a_i|^2=\sum_i|a_i|^2,
\qquad
\mathbb E|\sum_i\epsilon_i a_i|^4\le3(\sum_i|a_i|^2)^2.
\]

Finite Holder interpolation gives the `p`-moment bound with `beta_p=3^((p-2)/(2p))`. For every coefficient Hilbert contraction `A`, finite Fubini and `|A^*W|_2<=sqrt(q)` consequently give

\[
\mathbb E\|AZ\|_E^p\le\beta_p^p,
\qquad \mathbb E\|AZ\|_E^2\le\beta_p^2.
\]

Thus replace `gamma_p` by `beta_p` everywhere that the Gaussian bound is used, including the trace argument, overlap second moment, and selection Hilbert-Schmidt estimate. No Gaussian exact `p`-moment identity is needed. Independence between the frame product and coefficient signs remains a finite product construction.

The only interpolation needed in the overlap argument is the scalar inequality

\[
\mathbb E S^p\le(\mathbb E S^2)^{(4-p)/2}
                         (\mathbb E S^4)^{(p-2)/2}.
\]

Apply Holder to `S^(4-p)` and `S^(2p-4)` with conjugate exponents `2/(4-p)` and `2/(p-2)`; endpoints are identities. This avoids Riesz-Thorin entirely.

## The positive exponential gap survives

Define the revised overlap scale

\[
L=\alpha_{p'}^{-n}\tau^{-n(p-2)/(2p)}H^{-4(p-2)/p},
\qquad \tau=5/4\text{ or }10/9.
\]

The derivatives of `log alpha_r` at `r=2` are `log(2)/8` and `log(2)/12`. The leading coefficients in `log L / (n epsilon)` are therefore

\[
\kappa_{\mathbb R}=\frac18\log(32/25)>0,
\qquad
\kappa_{\mathbb C}=\frac1{12}\log(729/500)>0.
\]

Positivity reduces to rational inequalities. There are no Gamma derivatives or numerical transcendental certificates.

An especially simple parameter family is `n=k^3`, `p=2+k^(-2)` for positive integers `k`. Then `n epsilon=k -> infinity` and `n epsilon^2=1/k -> 0`; there are no fractional powers of natural indices. A first-derivative lower bound for the explicit function near `p=2` suffices to prove `L -> infinity`; a complete Taylor expansion is unnecessary.

Holder gives `alpha_p alpha_p' >= alpha_2^2 = 1`, so

\[
L\le\alpha_{p'}^{-n}\le g\le H.
\]

This is exactly what the later selection estimates need: use trace constant at most `2/g`, then bound it with `g>=L`. The earlier-summand distortion in the recursion must use `H`, and the two-range version must also retain the full ambient distortion `(m^n)^(1/2-1/p)`. At each stage those are finite constants depending only on previous choices. Choosing the next `L` sufficiently large still satisfies the recursive separation. No effective recursive bound is required.

## Local Mathlib support confirmed

The installed pinned Mathlib source contains:

- `Real.one_add_mul_self_le_rpow_one_add`, in `Analysis/Convex/SpecificFunctions/Basic.lean`, for the tangent inequality.
- `hasDerivAt_abs_rpow` and `hasDerivAt_norm_rpow`, in `Analysis/InnerProductSpace/NormPow.lean`, valid at zero when `p>1`.
- `Convex.norm_image_sub_le_of_norm_deriv_le`, in `Analysis/Calculus/MeanValue.lean`, for the Lipschitz step.
- `Real.inner_le_Lp_mul_Lq_of_nonneg` and `Real.rpow_sum_le_const_mul_sum_rpow_of_nonneg`, in `Analysis/MeanInequalities.lean`, for finite Holder and norm comparisons.
- `Real.rpow_arith_mean_le_arith_mean_rpow`, in `Analysis/MeanInequalitiesPow.lean`, for weighted finite power means.
- `Finset.sum_mul_sq_le_sq_mul_sq`, in `Algebra/Order/BigOperators/Ring/Finset.lean`, for finite Cauchy-Schwarz.
- `PiLp.norm_eq_sum`, in `Analysis/Normed/Lp/PiLp.lean`, plus existing normed-space and finite-dimensional infrastructure.

These are actual source declarations, not claims that the proposed assembled lemmas already exist. Finite sums also remove integrability, almost-everywhere equality, measure normalization, and product-measure bookkeeping from this portion of the construction.

## Scope and timing assessment

This route can remove the continuous circles/spheres, Gaussian distribution development, special-function moments, sampling/quadrature, conditional expectations, and general interpolation machinery from the Lean dependency graph. It preserves the positive overlap gap and exact existential targets while changing the witness spaces.

It does **not** remove the finite selection proof, the local Hilbert approximation for subspaces and quotients, infinite-sum and dual arguments, or the universal Banach-lattice obstruction needed to conclude nonisomorphism to every Banach lattice. Nor does the fixed-dimension projection estimate establish `||I-Q^tensor n|| -> 1`: applying it in dimension `m^n` would destroy the parameter scales. The real theorem's two complementary ranges still need the dimension-free projection-complement estimate or a separate replacement.

The arbitrary tensor estimate and the trace factorization estimate also still need Lean proofs. Nothing in this note warrants asserting a fully compiled theorem within 12 hours. The new finite route makes such a target more plausible, but confidence requires short compiler trials of the finite-frame projection lemma and the local Hilbert/duality bridge, followed by integration measurements. The projection lemma is a particularly useful next benchmark because its mathematical proof is complete, has no singular calculus gap, and uses verified existing Mathlib APIs.
