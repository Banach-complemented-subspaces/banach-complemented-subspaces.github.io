# Projection implementation progress

> Component progress log from 5 September 2026. Checkpoints below are historical; current statement conventions are documented in [README.md](README.md), and final verification status is recorded in [the fresh-build log](verification/fresh-root-build.log).

The route uses the exact four-point real frame from `FiniteFrame.lean` and the
counting-measure `PiLp` norm. Rescaling all coordinates by the common probability
normalization leaves an operator norm unchanged; the code itself consistently
uses the counting convention.

The previously checked analytic input is
`ComplementedSubspace.finite_projection_energy_bound` in `ProjectionPerturbation.lean`: for Euclidean-normalized
coordinates satisfying Pythagoras, the additive `p`-energy error is at most
`(9/4) * card * (p-2)^2`.

New work in `FrameProjectionNorm.lean` turns this into the relative energy bound
`1 + 18*(p-2)^2` in four coordinates. The power-mean inequality gives input energy
at least `1/2` for a Euclidean unit vector when `2 <= p <= 3`; scalar homogeneity
removes normalization. The matrix is then viewed as an actual continuous linear
map between `PiLp` spaces. The corresponding norm bound follows by monotonicity
of positive real powers.

`TensorProjection.lean` uses finite coordinate slices and two finite sums to
multiply energy bounds under a Kronecker product. The recursively indexed matrix
uses `FrameIndex 0 = Unit` and `FrameIndex (n+1) = Fin 4 × FrameIndex n`. Its target
operator norm estimate is `(1+18*(p-2)^2)^n`, with symmetry and idempotence proved
directly from the one-factor identities.

## Compiler status

Both `FrameProjectionNorm.lean` and `TensorProjection.lean` passed the installed
Lean 4.34.0-rc2 compiler and emitted their `.olean` files during the sustained run.
The direct compiler helper was used after an initial Lake diagnostic pass.

Checked named results include:

- `realFrameProjection_norm_le`: actual one-factor operator norm at most
  `1+18*(p-2)^2`, for `2 <= p <= 3`.
- `matrixPiLpCLM_kronecker_norm_le`: the general counting-`ℓᵖ` Kronecker operator
  norm is at most the product of the two operator norms.
- `tensorFrameProjection_norm_le`: actual tensor operator norm at most
  `(1+18*(p-2)^2)^n`.
- `tensorFrameProjection_clm_idempotent`: the actual continuous linear operator
  is idempotent.
- `tensorFrameProjection_diag`, `tensorFrameProjection_ne_zero`, and
  `tensorFrameProjection_ne_one`: diagonal entries `(1/2)^n`; nonzero for every
  `n`; proper when `n != 0`.
- `tensorFrameProjection_norm_le_exp`: upper bound `exp(18*n*(p-2)^2)`.
- `tensorFrameProjection_norm_tendsto_one`: the operator norm tends to one for
  every parameter family in `[2,3]` with `n*(p-2)^2 -> 0`.

No `sorry` or mathematical axioms were added. A transitive axiom audit is a
separate integration check to run with the other new modules.

The proof of the recursive tensor energy bound locally disables the elaborator's
definitional-transparency restriction to identify the recursive `Fintype`
instance with the product instance. This is a standard Mathlib elaboration
setting; it does not disable kernel checking or introduce an axiom.

These results do not imply a completed main theorem. Tensor complement norms
are separate from the direct tensor projection bound; the planned route uses the
two-dimensional local Hilbert comparison instead. The link between this projector
and the product frame coefficient space has now been checked in
`FrameProjectionRange.lean`.

## Further checked gates

`FrameProjectionRange.lean` now compiles: exact `Q=(4^n)⁻¹ W Wᵀ`, covariance
`Wᵀ W=4^n I`, the identity `QW=W`, equality of the actual `PiLp` operator ranges,
and injectivity of the frame coefficient map. The probability-normalized
coefficient space maps isometrically to this range after multiplying evaluation
by the common scalar `(4^n)^(-1/p)`; the image subspace is unaffected.

`FiniteLpGeometry.lean` also compiles through scalar Clarkson, the finite `PiLp`
parallelogram bound with constant `2^(2-4/p)`, the uniform sum modulus
`epsilon^3/12`, and `UniformConvexSpace` for every exponent in `[2,3]`. These
theorems are for arbitrary `RCLike` scalars, so cover both real and complex fields.
Continuity of the parallelogram constant at `p=2`, with limit one, also compiles.

## Checked outer-sum uniform convexity

Both `LpTwoUniformConvex.lean` and `AmbientUniformConvex.lean` now pass the Lean
compiler and emit their `.olean` files. For `0<eta<=1`, put `delta=eta^3/24`.
The checked pointwise inequality is

`delta^2 * ||u-v||^2 <= 2*delta^2*eta^2*(||u||^2+||v||^2)
  + 2*(2*(||u||^2+||v||^2)-||u+v||^2)`.

If `||u-v|| <= eta*(||u||+||v||)`, the first term suffices. Otherwise normalize
by `max(||u||,||v||)` and use the common cubic modulus. Split again according to
whether `abs(||u||-||v||) >= delta*(||u||+||v||)`. In either case obtain squared
sum deficit at least `delta^2*(||u||^2+||v||^2)`. Summing with `lp` norm-square
identities yields outer uniform convexity. For external distance `epsilon<=2`,
choose `eta=epsilon/4`, then outer sum modulus
`delta^2*epsilon^2/32` is positive. Summation works for an arbitrary dependent
family of real normed spaces with this common block modulus. In particular,
`ambientUniformConvexSpace` is an actual instance for the original `Ambient a`.
The same module proves the block parallelogram constants tend to one under the
parameters' prescribed convergence `p_j -> 2`.

`LpTwoParallelogram.lean` also passes: the common approximate parallelogram bound
transfers to an arbitrary dependent sum, then to the actual ambient tail
submodules (coordinates before N vanish), with constant `2^(2-4/p_N)`.

## Checked ambient projection assembly

`AmbientProjection.lean` uses Mathlib's `lp.mapCLM` to construct actual diagonal
operators, with their coordinate identities, operator bounds, component norm
lower bounds, idempotence, and complementary diagonal identities/bounds. The
missing `lpHolder` dependency was ultimately compiled from its existing local
Mathlib source after two download approval requests were interrupted.

`ReindexedFrameProjection.lean` passes: frame indices are isometrically reindexed
to `Fin(4^n)`, yielding actual projectors on `RecursiveFrameSelection.toBlockParameters`.
The operator norms are bounded by `exp(18*eta)`. A single sufficiently small eta
also bounds every complementary block by `D^2*exp(18*eta)`, uniformly over all
recursive selections, using the dimension-independent local Hilbert threshold.

`RecursiveProjection.lean` passes through the actual alternating diagonal
projection. Even blocks select the frame projector and odd blocks its complement.
For every `D>1`, a positive eta tolerance gives both global norms between one and
`D^2*exp(18*eta)`, with exact coordinate application identities.
`exists_recursive_alternatingProjection_near_one` also passes: for any `B>1`, it
chooses an actual positive eta and constructs P on the recursively selected
ambient space, with idempotence, both norms at least one and strictly below B,
and the exact alternating coordinate formula. This proves the projection/geometry
portion only; the remaining nonembedding/chi obstruction assembly is separate.

## Checked inherited range profiles

`LpSubmodule.lean` passes through `lpDiagonalRangeEquiv`, the exact linear isometry
from the outer lp2 sum of inherited coordinate ranges onto the actual diagonal
range. Its coordinate inclusion preserves norms; its evaluation has norm at most
one; evaluation after inclusion is the identity. The squared norm is exactly the
sum of the selected coordinate square and the complementary remainder square.
The explicit map into the evaluation kernel and its pointwise contraction also
pass. (The pointwise formulation avoids unnecessary nested operator-norm typeclass
search while proving exactly the same contraction.)

`FrameCoefficientReindexedRange.lean` passes the exact coefficient-space
isometries to the Fin(4^n) projection ranges, then to the even alternating block
ranges and the odd complementary block ranges.

`ProjectionAssemblyAudit.lean` prints only `propext`, `Classical.choice`, and
`Quot.sound` for all nine audited assembled results, including the near-one
projection theorem, ambient uniform convexity, inherited range profiles, exact
coordinate splitting, and both coefficient-range identifications.

`LpHeadTail.lean` passes the next connector: contractive restrictions to
the finite head and infinite tail, exact square-norm splitting on ker(eval_j),
and the resulting linear isometric embedding into the two-term lp2 product,
including the corresponding coordinate kernel inside the actual diagonal range.

`DiagonalFrameSummand.lean` passes the complete I,R,J,S package for any
coefficient isometry `e : A ≃ₗᵢ (P_j).range`: I and J preserve norms, R and S
contract, RI=id, SJ=id, RJ=0, JS=id-IR, with exact squared-norm decomposition.

The final witness-recovery helpers in `AmbientProjection.lean` pass:
any operator with the prescribed block coordinates bounds each block norm,
equals its canonical `lpDiagonal` realization, and its complement has the
complementary coordinate formula. These let the main theorem consume the
existential near-one projector without preserving proof witnesses used internally.

`LocalHilbertDualTop.lean` passes the whole-space-submodule bridge from
`DualSubspacesLocallyHilbertWithin E d D` to `LocallyHilbertWithin (StrongDual R E) d D`,
and its bidual specialization. It uses the actual isometric top-submodule equivalence.

`ActualProjectionDPR.lean`, `ActualProjectionDualDPR.lean`, and
`ActualProjectionBidualDPR.lean` now pass. They transfer all six primal, dual,
and bidual DPR obstructions to the actual near-one P and I-P using their exact
coordinate formulas.

`RealMainTheorem.lean` now passes the original `RealMainTheoremStatement`,
without obstruction hypotheses. `RealMainAudit.lean` reports only `propext`,
`Classical.choice`, and `Quot.sound` for the main and all four range/dual results.

`RealMainConsequences.lean` now passes `realCorollary`,
`realUnconditionalCorollary`, and `realSeparableNonprimarity`. The full real
corollary uses the separately proved bidual obstruction to exclude lattice
isomorphisms of the range dual; this stronger assertion is not inferred from
the main statement alone. The consequence axiom audit passes with only the same
three standard axioms. Exact compiler output is saved in
`verification/real-main-axioms.log` and `verification/real-main-consequences-axioms.log`.

`PureFrameDPR.lean` passes the real endpoint needed for complex reuse: the lp2
profile of every real frame coefficient space is isometric to the actual pure
block-frame diagonal range (without alternating parity), and both the profile
and its real continuous dual have infinite DPR. The module also supplies the
generic coordinatewise lp isometry equivalence and infinity transport across
continuous linear equivalences. All eight audited declarations depend only on
the standard three axioms; output is in `verification/pure-frame-dpr-axioms.log`.
