# Finite-frame parameter gate

> Component progress log from 5 September 2026. Checkpoints below are historical; current statement conventions are documented in [README.md](README.md), and final verification status is recorded in [the fresh-build log](verification/fresh-root-build.log).

`FiniteParameterGap.lean` compiled successfully on 5 September 2026, shortly
before 19:06 UTC. It uses the four-point real frame's explicit scalar moments.
No manuscript file has been changed.

The formal definitions retain three separate constants:

* `realFrameWitnessScale n p` is `g = alpha_p^n`, for frame-supported witnesses.
* `realFrameHilbertScale n p` is `H = 2^(n(1/2-1/p))`, the uniform upper bound.
* `realFrameOverlapScale n p` is the revised overlap scale
  `L = alpha_(p')^(-n) (5/4)^(-n(p-2)/(2p)) H^(-4(p-2)/p)`.

They are defined using exponentials of explicit logarithms to simplify the
calculus. Theorems `realFrameAlpha_rpow`, `realFrameWitnessScale_eq`,
`realFrameHilbertScale_eq`, and `realFrameOverlapScale_eq` prove agreement with
the moment and product formulas above. This is a representation choice, not an
additional mathematical assumption.

The exact derivatives of `log alpha_r` and of `log L / n` at exponent two are
`log 2 / 8` and `log(32/25)/8`, respectively. The latter is positive because
`32/25 > 1`. The constant refers to **log L**, not log(gL).

The parameter sequence is `n(k)=(k+1)^3` and `p(k)=2+1/(k+1)^2`. Lean checks
the exact identities `n(p-2)=k+1` and `n(p-2)^2=1/(k+1)`, the resulting limits,
and `L(n(k),p(k)) -> infinity`. The derivative is used as a slope limit;
there is no Taylor remainder, Gamma-function calculation, or numerical
certificate.

The selected audit in `FiniteParameterAudit.lean` passes for the derivative,
overlap divergence, simultaneous existence theorem, exact product formula,
scalar Holder inequality, and scale ordering. All use only `propext`,
`Classical.choice`, and `Quot.sound`; there are no admitted facts or new axioms.

`exists_finiteFrame_parameters` is the construction-facing interface: for
every positive error tolerance `delta` and real target `R`, there exist
`n>0` and `2<p<=3` such that `p-2<delta`, `n(p-2)^2<delta`, and `R<L(n,p)`.
This allows later recursive choices to impose any finite growth threshold
depending on earlier blocks.

`FiniteParameterBounds.lean` also compiles. It proves the scalar Holder
inequality `alpha_p alpha_(p') >= 1` and the ordering `L <= g <= H` for every
`p>=2`. Its finite Holder proof uses the three nonzero frame entries
`sqrt(2),1,1`; the fourth frame entry is zero. The further bridge
`realFrameWitnessScale_rpow` proves the exact powered witness scale
`g(n,p)^p = ((2^(p/2)+2)/4)^n` whenever `p` is nonzero.
The finite coefficient-space moment
identifications, the selection argument, and the recursive global construction
are separate obligations, not conclusions of this scalar parameter gate.

## Actual witness: verified

`ProductFrameWitness.lean` now compiles. The witness is the coordinate vector
at the all-first-coordinate index in the binary tensor coordinates. Its
Euclidean squared norm is one, and finite product averaging gives its exact
powered scalar moment. Using the actual induced norm from
`FrameCoefficientNorm.lean`, `frameCoefficientWitness_norm` then proves that
its norm is precisely `realFrameWitnessScale n p` for positive p whenever the
coefficient norm is defined. This closes the link from the scalar g formula to
an actual vector in the constructed normed coefficient space.

This is one distinguished witness; it does not assert that every direction
has the same norm. The uniform upper comparison remains H.

## Actual normalized coefficient signs: verified

`ProductFrameSignSample.lean` compiled at approximately 19:30 UTC. It defines
normalized independent signs indexed by the finite sign cube in dimension
`card(MomentIndex n)=2^n`, reindexed via `Fintype.equivFin`. Their coordinate
covariance is `I/2^n`, and their Euclidean squared norm is deterministically
one. The actual coefficient norm satisfies
`average ||z||^p <= 3^((p-2)/2)` and
`average ||z||^2 <= 3^((p-2)/p)` for `2<=p<=4`.

The proof uses the compiled finite sign interpolation bound, finite Fubini,
the product frame's constant Euclidean length, and Jensen for the final second
moment. These are the finite replacements for the Gaussian coefficient samples
in the trace estimate. No Gaussian law or integration theorem is assumed.

`FiniteHilbertWitnessAudit.lean` audits the actual witness and covariance
interfaces, and the normalized-sign interfaces. The full audit passed with
only the three standard axioms: `propext`, `Classical.choice`, and `Quot.sound`.

## All normalized frame rows and their actual dual functionals: verified

`ProductFrameRowWitness.lean` defines the exact row
`x_s = (sqrt(2^n))^-1 W_s`. Every row has Euclidean norm one and their
coordinate covariance is `I/2^n`. For every positive exponent r, its frame
evaluation moment is `((2^(r/2)+2)/4)^n`; hence its actual coefficient-space
norm is `g(n,r)`. The four one-factor rows are checked directly, including
the diagonal rows, and finite product averages give the tensor identity.
This avoids building an additional 45-degree symmetry action.

Covariance and finite probability-space Holder give the sharp pairing bound
`|sum_i b_i x_s,i| <= g(n,p') ||b||` for p>1. This constructs an actual
continuous dual functional `frameRowFunctional`, whose norm has that bound
and whose evaluation is exactly `productFrameEval b s / sqrt(2^n)`.
The full module passed Lean and emitted its olean. No norm bound or row
symmetry is postulated; the bound uses the actual coefficient-space norm.

The six selected row identities and functional bounds passed the transitive
axiom audit, again with only `propext`, `Classical.choice`, and `Quot.sound`.

## Scalar overlap estimate: verified

`FiniteOverlapScale.lean` simplifies the actual finite overlap upper expression
to `64 C^3 / L` after multiplication by `g(n,p')`, for `2<=p<=3`, `C>=1`,
and `m<=3*2^n`. The proof first combines every power of C into the exact
exponent `1+2a+8b = 4-4/p`, where `a=(4-p)/(2p)` and `b=(p-2)/(2p)`.
Only then is the exponent bounded by three. The residual frame penalty is
proved to satisfy `g(n,p') * penalty = 1/L` exactly. Conservative elementary
bounds give coefficient 26, which is weakened to the requested 64.
The distinguished witness scale g and the uniform comparison H remain
separate throughout; no replacement of H by g is used.

The actual trace-to-overlap lower bound is weighted:
`1 <= 4 K^2 beta_p^2 theta`. A lower bound `theta>=1/2` would be stronger
than the construction provides; the half bound belongs to retained trace
before Cauchy-Schwarz. The final scalar endpoint therefore retains the weight.
For `D>=2`, `K>=0`, `8K<=D`, and `D^8<L`, the overlap upper bound with `C=DK`
gives `4 K^2 beta_p^2 theta < 1`, using `beta_p^2<=4` and a numerator bound
`4 K^2 beta_p^2 * 64(DK)^3 <= D^8/32`.

The full scalar module and all ten selected transitive axiom checks have
passed. `finite_frame_selection_scalar_bounds` packages both hypotheses
needed by the actual finite obstruction: the trace smallness bound
`(q*beta_p/g) D K^2 <= q/4` and the strict weighted overlap separation
`256 K^2 beta_p^2 (DK)^3 < L`, for `q=2^n` under the same parameter assumptions.
