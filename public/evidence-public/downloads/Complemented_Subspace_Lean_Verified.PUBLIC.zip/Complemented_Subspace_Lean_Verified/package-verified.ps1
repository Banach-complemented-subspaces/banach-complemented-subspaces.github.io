<#
Creates a source-only archive from the live root import closure and an explicit
documentation/helper allowlist. No staging directory or recursive delete is used.
ZIP ordering and timestamps are fixed: identical input bytes give identical
archives on the same .NET compression implementation. The manifest hashes the
exact bytes placed in the ZIP, and excludes only the manifest itself.

Use -ListOnly to inspect the selection without creating or replacing anything.
The default packaging operation requires the completed fresh build/audit log.
#>
[CmdletBinding()]
param(
    [switch]$ListOnly,
    [switch]$ReplaceExisting
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$packageRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$packageRootPrefix = $packageRoot.TrimEnd([char[]]@('\', '/')) + [IO.Path]::DirectorySeparatorChar
$packageName = 'Complemented_Subspace_Lean_Verified'
$packageDestination = [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $packageRoot) ($packageName + '.zip')))
$packagePaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$packageModules = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$packageBuildInputs = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)

function Get-PackageSourcePath([string]$RelativePath) {
    if ([IO.Path]::IsPathRooted($RelativePath) -or $RelativePath -match '(^|[\\/])\.\.([\\/]|$)') {
        throw "Not a relative package path: $RelativePath"
    }
    $sourcePath = [IO.Path]::GetFullPath((Join-Path $packageRoot $RelativePath))
    if (-not $sourcePath.StartsWith($packageRootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Package source escaped the project: $RelativePath"
    }
    $sourceItem = Get-Item -LiteralPath $sourcePath -Force
    if ($sourceItem.PSIsContainer) { throw "Expected a file: $RelativePath" }
    $checkedPath = $sourcePath
    while ($checkedPath.Length -ge $packageRoot.Length) {
        $checkedItem = Get-Item -LiteralPath $checkedPath -Force
        if (($checkedItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Refusing a package source through a reparse point: $checkedPath"
        }
        if ([string]::Equals($checkedPath, $packageRoot, [StringComparison]::OrdinalIgnoreCase)) { break }
        $checkedPath = Split-Path -Parent $checkedPath
    }
    return $sourcePath
}

function Add-PackageFile([string]$RelativePath) {
    $normalized = $RelativePath.Replace('\', '/')
    $null = Get-PackageSourcePath $normalized
    [void]$packagePaths.Add($normalized)
}

function Get-LeanImports([string]$RelativePath) {
    $sourceText = [IO.File]::ReadAllText((Get-PackageSourcePath $RelativePath))
    # Mask nested Lean block comments, line comments, and string contents.
    # Keep newlines so only genuine line-leading import commands are selected.
    $masked = [Text.StringBuilder]::new($sourceText.Length)
    $blockDepth = 0
    $lineComment = $false
    $inString = $false
    $escaped = $false
    for ($position = 0; $position -lt $sourceText.Length; $position++) {
        $current = $sourceText[$position]
        $next = if ($position + 1 -lt $sourceText.Length) { $sourceText[$position + 1] } else { [char]0 }
        if ($lineComment) {
            if ($current -eq "`n") { $lineComment = $false; [void]$masked.Append($current) }
            else { [void]$masked.Append(' ') }
        } elseif ($blockDepth -gt 0) {
            if ($current -eq '/' -and $next -eq '-') { $blockDepth++; $position++; [void]$masked.Append('  ') }
            elseif ($current -eq '-' -and $next -eq '/') { $blockDepth--; $position++; [void]$masked.Append('  ') }
            elseif ($current -eq "`n" -or $current -eq "`r") { [void]$masked.Append($current) }
            else { [void]$masked.Append(' ') }
        } elseif ($inString) {
            if ($escaped) { $escaped = $false }
            elseif ($current -eq '\') { $escaped = $true }
            elseif ($current -eq '"') { $inString = $false }
            if ($current -eq "`n" -or $current -eq "`r") { [void]$masked.Append($current) }
            else { [void]$masked.Append(' ') }
        } elseif ($current -eq '/' -and $next -eq '-') {
            $blockDepth = 1; $position++; [void]$masked.Append('  ')
        } elseif ($current -eq '-' -and $next -eq '-') {
            $lineComment = $true; $position++; [void]$masked.Append('  ')
        } elseif ($current -eq '"') {
            $inString = $true; [void]$masked.Append(' ')
        } else { [void]$masked.Append($current) }
    }
    if ($blockDepth -ne 0 -or $inString) { throw "Unterminated comment/string in $RelativePath" }
    foreach ($importMatch in [regex]::Matches($masked.ToString(), '(?m)^\s*(?:(?:public|private|meta)\s+)*import[ \t]+([^\r\n]+)')) {
        foreach ($moduleName in ($importMatch.Groups[1].Value.Trim() -split '\s+')) {
            if ($moduleName -notmatch "^[A-Za-z_][A-Za-z0-9_']*(\.[A-Za-z_][A-Za-z0-9_']*)*$") {
                throw "Unsupported import token '$moduleName' in $RelativePath"
            }
            Write-Output $moduleName
        }
    }
}

function Add-LocalModuleClosure([string]$ModuleName) {
    if (-not $packageModules.Add($ModuleName)) { return }
    $relative = $ModuleName.Replace('.', '/') + '.lean'
    Add-PackageFile $relative
    [void]$packageBuildInputs.Add($relative)
    foreach ($dependency in @(Get-LeanImports $relative)) {
        if ($dependency -eq 'ComplementedSubspace' -or $dependency.StartsWith('ComplementedSubspace.') -or
            $dependency -eq 'BanLat' -or $dependency.StartsWith('BanLat.')) {
            Add-LocalModuleClosure $dependency
        } elseif (Test-Path -LiteralPath (Join-Path $packageRoot ($dependency.Replace('.', '/') + '.lean'))) {
            throw "Unexpected local import '$dependency': review the package allowlist."
        }
        # External Lean/Mathlib dependencies are supplied by the pinned manifest.
    }
}

function Add-SelectedTree([string]$RelativeDirectory, [string[]]$Extensions) {
    $directoryPath = Join-Path $packageRoot $RelativeDirectory
    $directoryItem = Get-Item -LiteralPath $directoryPath -Force
    if (($directoryItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Refusing a package directory reparse point: $RelativeDirectory"
    }
    foreach ($child in Get-ChildItem -LiteralPath $directoryPath -Force) {
        if (($child.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Refusing a package tree reparse point: $($child.FullName)"
        }
        $relative = $RelativeDirectory.TrimEnd('/') + '/' + $child.Name
        if ($child.PSIsContainer) { Add-SelectedTree $relative $Extensions }
        elseif ($Extensions -contains $child.Extension.ToLowerInvariant()) { Add-PackageFile $relative }
    }
}

Add-LocalModuleClosure 'ComplementedSubspace'
Add-SelectedTree 'BanLat' @('.lean')
Add-PackageFile 'BanLat/LICENSE'
Add-PackageFile 'BanLat/PORTING.md'
Add-SelectedTree 'manuscript' @('.tex', '.bib', '.md')
Add-PackageFile 'manuscript/1-Introduction.tex'
Add-PackageFile 'manuscript/1a-Preliminaries.tex'
Add-PackageFile 'manuscript/README.md'

$packageRequired = @(
    'lakefile.toml', 'lake-manifest.json', 'lean-toolchain',
    'README.md', 'BUILDING.md', 'MainTheoremReview.lean', 'MainRealTheoremDefinitions.lean',
    'WholeProjectAudit.lean', 'package-verified.ps1', 'rebuild-verified.ps1',
    'run-lean.ps1', 'check-lean-direct.ps1', 'check-lattice-dependencies.ps1',
    'get-mathlib-cache.ps1',
    'acceleration-assessment.md', 'complex-realification-shortcut.md',
    'complex-semantic-review.md', 'corollary-scope-assessment.md',
    'finite-analytic-shortcuts.md', 'finite-correction-progress.md',
    'finite-obstruction-progress.md', 'finite-parameter-progress.md',
    'geometry-shortcut-assessment.md', 'lattice-progress.md',
    'local-hilbert-progress.md', 'projection-progress.md', 'real-main-semantic-review.md',
    'recursive-parameter-progress.md', 'shortcut-plan.md', 'statement-review.md'
)
foreach ($relative in $packageRequired) { Add-PackageFile $relative }
foreach ($relative in @('lakefile.toml', 'lake-manifest.json', 'lean-toolchain', 'WholeProjectAudit.lean')) {
    [void]$packageBuildInputs.Add($relative)
}
Add-SelectedTree 'verification' @('.log', '.txt', '.md', '.sha256')

[string[]]$packageSortedPaths = @($packagePaths)
[Array]::Sort($packageSortedPaths, [StringComparer]::Ordinal)
if ($ListOnly) {
    Write-Output $packageSortedPaths
    return
}

$packageBuildLog = Get-PackageSourcePath 'verification/fresh-root-build.log'
$packageBuildText = [IO.File]::ReadAllText($packageBuildLog).TrimEnd()
$packageBuildMatch = [regex]::Match($packageBuildText,
    '(?m)^Fresh root-import build and axiom audit passed UTC: ([^\r\n]+)\z')
if (-not $packageBuildMatch.Success) {
    throw 'The fresh root build and axiom audit have not completed successfully; no archive was created.'
}
$packageBuildFinished = [DateTimeOffset]::Parse($packageBuildMatch.Groups[1].Value,
    [Globalization.CultureInfo]::InvariantCulture).UtcDateTime
foreach ($relative in $packageBuildInputs) {
    $sourceItem = Get-Item -LiteralPath (Get-PackageSourcePath $relative)
    if ($sourceItem.LastWriteTimeUtc -gt $packageBuildFinished) {
        throw "Build input changed after the fresh audit: $relative"
    }
}
if ((Test-Path -LiteralPath $packageDestination) -and -not $ReplaceExisting) {
    throw "Archive already exists. Use -ReplaceExisting to replace this exact archive: $packageDestination"
}
if (Test-Path -LiteralPath $packageDestination) {
    $destinationItem = Get-Item -LiteralPath $packageDestination -Force
    if ($destinationItem.PSIsContainer -or
        ($destinationItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'The archive destination must be an ordinary file.'
    }
}

Add-Type -AssemblyName System.IO.Compression
$packageTemporary = $packageDestination + '.' + [Guid]::NewGuid().ToString('N') + '.partial'
$packageStream = $null
$packageZip = $null
$packageHasher = [Security.Cryptography.SHA256]::Create()
$packageManifest = [Text.StringBuilder]::new()
$packageUtf8 = [Text.UTF8Encoding]::new($false)
$packageTimestamp = [DateTimeOffset]::new(2000, 1, 1, 0, 0, 0, [TimeSpan]::Zero)

function Write-PackageEntry([string]$RelativePath, [byte[]]$Bytes) {
    $entry = $packageZip.CreateEntry($packageName + '/' + $RelativePath,
        [IO.Compression.CompressionLevel]::Optimal)
    $entry.LastWriteTime = $packageTimestamp
    $entryStream = $entry.Open()
    try { $entryStream.Write($Bytes, 0, $Bytes.Length) }
    finally { $entryStream.Dispose() }
}

try {
    $packageStream = [IO.File]::Open($packageTemporary, [IO.FileMode]::CreateNew,
        [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $packageZip = [IO.Compression.ZipArchive]::new($packageStream,
        [IO.Compression.ZipArchiveMode]::Create, $true)
    foreach ($relative in $packageSortedPaths) {
        $bytes = [IO.File]::ReadAllBytes((Get-PackageSourcePath $relative))
        $digest = [BitConverter]::ToString($packageHasher.ComputeHash($bytes)).Replace('-', '').ToLowerInvariant()
        [void]$packageManifest.Append($digest).Append('  ').Append($relative).Append("`n")
        Write-PackageEntry $relative $bytes
    }
    Write-PackageEntry 'SOURCE-MANIFEST.sha256' ($packageUtf8.GetBytes($packageManifest.ToString()))
    $packageZip.Dispose(); $packageZip = $null
    $packageStream.Dispose(); $packageStream = $null
    if (Test-Path -LiteralPath $packageDestination) {
        [IO.File]::Replace($packageTemporary, $packageDestination, $null)
    } else {
        [IO.File]::Move($packageTemporary, $packageDestination)
    }
} catch {
    throw "Packaging failed. Any partial file is retained at '$packageTemporary'. $($_.Exception.Message)"
} finally {
    if ($null -ne $packageZip) { $packageZip.Dispose() }
    if ($null -ne $packageStream) { $packageStream.Dispose() }
    $packageHasher.Dispose()
}

Write-Output "Created $packageDestination"
Write-Output "Included $($packageSortedPaths.Length) source/documentation/log files plus SOURCE-MANIFEST.sha256."
Write-Output "Active root import closure: $($packageModules.Count) local Lean modules."
Write-Output "ZIP SHA256: $((Get-FileHash -LiteralPath $packageDestination -Algorithm SHA256).Hash.ToLowerInvariant())"
