# Faster route for the real tensor estimate

> Historical working note from 5 September 2026. Status labels and proposed routes below record that stage of the implementation. See [README.md](README.md) for the current statements and proof route, and [the fresh-build log](verification/fresh-root-build.log) for final verification status.

Assessment after the implementation trial, 5 September 2026. This derivation was subsequently implemented and verified in `ComplementedSubspace/TensorMoment.lean`, including the arbitrary-vector tensor estimate. It is additional to the frozen original trial source archive. See `shortcut-plan.md` for the latest verification and remaining work.

The real tensor rank-one estimate can be approached directly, avoiding the general maximal-output multiplicativity theorem used in the manuscript. This preserves the exact constant required by the manuscript.

Let T be a real linear map from real matrices into a real Hilbert space. Suppose

\[
\|T(zz^T)\|^2\le r\|z\|_2^4,\qquad r\ge0.
\]

Polarization and rescaling imply

\[
\|T(xy^T+yx^T)\|\le2\sqrt r\|x\|_2\|y\|_2.
\]

Indeed, twice the matrix inside T equals
\((x+y)(x+y)^T-(x-y)(x-y)^T\). The triangle inequality and parallelogram identity give an upper bound \(\sqrt r(\|x\|^2+\|y\|^2)\). For nonzero x,y, replace them by tx and t^{-1}y with equal norms; the mixed matrix is unchanged and this bound becomes \(2\sqrt r\|x\|\|y\|\). If either vector is zero the assertion is immediate.

Now use T = D_n, where D_n is the real circle moment map tensor power, and split a vector at the next tensor level as b = (x,y). Set

\[
A=T(xx^T),\quad B=T(yy^T),\quad H=T(xy^T+yx^T),
\quad a=\|x\|_2^2,\quad c=\|y\|_2^2.
\]

The two-by-two block form of \((D\otimes T)(bb^T)\) is

\[
\frac14\begin{pmatrix}3A+B&H\\H&A+3B\end{pmatrix}.
\]

Its squared Hilbert–Schmidt norm is

\[
\frac{10\|A\|_{\rm HS}^2+10\|B\|_{\rm HS}^2
+12\langle A,B\rangle_{\rm HS}+2\|H\|_{\rm HS}^2}{16}.
\]

The rank-one hypothesis, Cauchy–Schwarz, and the polarization bound give

\[
\frac{10ra^2+10rc^2+12rac+8rac}{16}
=\frac58r(a+c)^2.
\]

Starting with the identity map for zero factors, induction therefore gives

\[
\|D_n(bb^T)\|_{\rm HS}^2\le(5/8)^n\|b\|_2^4.
\]

No assertion that b is a pure tensor is made: x and y are arbitrary vectors at the previous tensor level. The argument uses no positivity, quantum channels, complexification, or general Schatten norms.

## Implementation consequences

The polarization lemma, block identity and induction now compile using the existing `hsSq` infrastructure. `tensor_paired_column_moments_bound` supplies the resulting arbitrary-tensor paired-column estimate without the old rank-one hypothesis. The separate product-frame moment identities and overlap argument still remain.

Two other possible reductions in general infrastructure are to establish the ambient GL bound directly from its coordinate truncations, and to obtain the required dual GL bound using the adjoint retraction and the explicit dual coordinate structure. These routes still require proofs of their approximation and dual-space facts; they are not already available results of the trial.

The installed toolchain and cached dependencies remove the initial setup cost from further work. Independent tensor, geometric, and infinite-sum lemmas can be developed concurrently; parallel agents were already used in the trial, so this should not be counted as an entirely new speed gain. No reliable multiplicative speedup or total completion time has been measured.
