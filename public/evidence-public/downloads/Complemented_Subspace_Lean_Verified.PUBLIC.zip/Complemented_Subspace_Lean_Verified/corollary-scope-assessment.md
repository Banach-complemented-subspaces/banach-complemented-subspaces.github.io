# Exact-scope assessment and possible shortcuts

> Historical working note from 5 September 2026. Status labels and proposed routes below record that stage of the implementation. See [README.md](README.md) for the current statements and proof route, and [the fresh-build log](verification/fresh-root-build.log) for final verification status.

Read-only assessment of the current project and the supplied `1-Introduction.tex` and `7a-Banach-lattices.tex`. No new Lean implementation or compilation was undertaken for this assessment.

## What the current target does and does not say

`RealMainTheoremStatement` includes the prescribed real ambient sum, separability, a compatible lattice order, both near-one projection bounds, and all four range/dual GL–DPR assertions. It remains a proposition definition, without an existence proof.

It requests uniform convexity of the inherited ambient norm. This is a stronger mathematical property of the construction than superreflexivity. A faithful ad hoc statement can explicitly define superreflexivity by the standard equivalent characterization “admits an equivalent uniformly convex complete norm”; the inherited norm is then a direct witness. This convention does not require proving a formal equivalence with finite representability, and should be documented. The current statement has not yet made that definition choice explicit.

The main corollary is not stated: it also needs an ambient **1-unconditional Schauder basis**, absence of any unconditional Schauder basis in the range and dual, a complex example, and, over the reals, non-isomorphism to **any** Banach lattice. Contractive unconditional block expansions in `Ambient.lean` do not themselves supply a scalar Schauder basis. Nor would `¬ HasRealBanachLatticeOrder Z` express the last claim: that only excludes a lattice order compatible with the current norm, whereas a Banach-space isomorphism can transport a different equivalent lattice norm to `Z`.

For exact delivery, separate the real main theorem and the main corollary into explicit targets. Do not silently count further remarks about MAP, shrinking/boundedly complete bases, or Lacey stabilization as part of this chosen scope unless requested.

## Shortcuts that preserve the requested conclusions

1. **Prove the explicit ambient GL bound directly.** Coordinate truncations of the concrete dependent sum have finite-dimensional 1-unconditional ranges. A finite-rank perturbation of the identity can send an arbitrary finite-dimensional subspace exactly into such a range. Its inverse norm approaches one. This establishes `chiGL X ≤ 1`, or even `chiDPR X ≤ 1`, without a general theorem about Banach lattices. The existing `chiGL_range_le_projection_norm` then gives the inherited range bound.

2. **Avoid general GL duality.** Identify the dual of this explicit ℓ²-sum with the ℓ²-sum of the finite block duals. Those dual coordinate spaces also have 1-unconditional bases. Apply the already implemented retraction theorem to the adjoints of the inclusion and projection, using `J* P* = id` and preservation of operator norm under dualization. This gives the exact `chiGL Z* ≤ ‖P‖` bound, as the manuscript itself does over the complex field. General Pisier GL duality is unnecessary for this route. The ℓ²-dual identification and its norms still require proofs.

3. **Reuse one exact finite-rank correction argument.** For a finite-dimensional `V`, extend a finite coordinate family by Hahn–Banach and use
   `T = id + Σ_i (S_m v_i - v_i) ⊗ f_i`.
   For sufficiently accurate truncation, `T` is invertible and `T(V)` lies in the finite coordinate span. Pulling that span back proves that an unconditional Schauder basis implies finite DPR constant. This can discharge the no-basis corollary from `chiDPR = ∞` and also supply the explicit ambient GL estimate. It avoids developing a general theory of all basis constants beyond the needed perturbation and multiplier bounds.

4. **Alternatively use the manuscript's direct no-basis obstruction.** The finite-selection argument in `6-Infinite-sum.tex` permits the proposed superspace to be the entire space. Once formalized in that strength, taking `F = Y` directly excludes every unconditional basis. This avoids the general basis-to-DPR implication, but only if the finite-selection lemma genuinely handles an infinite unconditional basis; the finite-dimensional DPR result alone is insufficient.

5. **Use a documented standard definition of superreflexivity.** An ad hoc development can choose “admits an equivalent uniformly convex norm” as its definition of superreflexivity. Uniform convexity of the inherited norm then gives a direct witness. This is a legitimate standard equivalent characterization, provided the definition choice is explicit. If the target instead defines superreflexivity through finite representability/reflexivity, the equivalence is an additional substantial theorem; replacing that predicate by `UniformConvexSpace` without explanation is not a formal proof of it. Proving uniform convexity of the actual variable-exponent sum remains necessary in either version.

Mathlib already supplies `GeneralSchauderBasis` and `UnconditionalSchauderBasis` in `Mathlib/Analysis/Normed/Module/Bases.lean:106,139`, including `UnconditionalSchauderBasis.exists_norm_proj_le` at line 224. These are genuine infinite basis structures. Their `enormProjBound` bounds finite **coordinate projections**, not arbitrary modulus-one multipliers. A projection bound of one must not be silently presented as a 1-unconditional constant in the manuscript's multiplier convention. For the explicit ambient coordinates, prove the multiplier contraction directly from the coordinatewise norm formulas.

## Preferred nonlattice shortcut: dual lattices and a direct bidual obstruction

The manuscript's general deduction uses two independent ingredients:

- DPR finiteness is invariant under bounded linear isomorphism, quantitatively with a distortion factor;
- every real Banach lattice has finite DPR constant (the cited result is the stronger equality `chiDPR = 1`).

The first is a manageable transport of finite superspaces and bases. The second has not been found in BanLat. The actual proof on p. 397 of FJT1975 first approximates finite-dimensional subspaces of a **sigma-order-complete** lattice by spans of disjoint vectors and applies a perturbation. For an arbitrary lattice it passes to the order-complete bidual and uses the **principle of local reflexivity**. This last step is a substantial dependency absent from the audited sources. [FJT1975, author-uploaded full text](https://www.researchgate.net/publication/265462069_On_Banach_lattices_and_spaces_having_local_unconditional_structure_with_applications_to_Lorentz_function_spaces), [published article](https://doi.org/10.1016/0021-9045(75)90023-4).

**There is a narrower route for this exact construction that avoids general local reflexivity.** Prove DPR finiteness only for order-complete Banach lattices, and use both the primal and dual DPR obstructions already required in the main theorem:

1. If `Z` is isomorphic to a Banach lattice `L`, dualizing gives `Z*` isomorphic to `L*`. BanLat already proves that `L*` is an order-complete Banach lattice. Its finite DPR constant contradicts `chiDPR Z* = ∞`.
2. If `Z*` is isomorphic to a Banach lattice `L`, dualizing gives `Z**` isomorphic to `L*`. The preferred route is to prove **DPR infinity directly for the bidual**, by repeating the same finite selection obstruction, as detailed below. This does not require identifying the whole constructed space with its bidual.

This route avoids proving Milman–Pettis or reflexivity-to-order-completeness for arbitrary lattices. It also avoids proving DPR=1 for every Banach lattice. It preserves the universal quantifier over hypothetical target lattices. For these contradictions a finite bound is sufficient; proving the exact equality DPR=1 is optional.

### Direct bidual obstruction: mathematical route checked

For each selected block, write `Y = E_j ⊕₂ W_j` and further `W_j = A_j ⊕₂ B_j`, where `A_j` is the finite earlier head and `B_j` the later tail. Dualizing these **two-term** decompositions twice gives isometric decompositions

`Y** = E_j** ⊕₂ W_j**`, and `W_j** = A_j** ⊕₂ B_j**`.

Finite-dimensional canonical bidual isometries identify `E_j**` with `E_j` and `A_j**` with `A_j`. Thus the earlier-head Hilbert comparison retains the factor `G_(j-1)` and the distinguished block retains its norm and finite obstruction constants exactly.

For the tail, express the approximate parallelogram inequality as the operator bound `||H|| <= sqrt(nu)` on `B_j ⊕₂ B_j`, where `H(x,y) = (x+y,x-y)/sqrt(2)`. Under the isometric two-term dual identification, its adjoint is the same normalized Hadamard operator. The adjoint norm bound therefore transfers the upper inequality to `B_j*` and then `B_j**` **with the same nu**. The lower inequality follows from `H²=id`; no loss is accumulated through dualization. Exact equality of adjoint operator norms is not needed, only the standard nonincrease bound.

Apply the approximate-parallelogram-to-local-Hilbert theorem to each at-most-`3q_j` dimensional projection into `B_j**`. It gives the same tail factor 2. Combining its Hilbert norm with the earlier-head one gives `D_j=max(2,G_(j-1))` on every such finite-dimensional subspace of `W_j**`. Any finite superspace of the canonical `E_j` in `Y**` splits as `E_j ⊕₂ (F ∩ W_j**)`, because its distinguished coordinate projection remains inside `F`. The original selection/overlap contradiction therefore applies with exactly the same `q_j`, `D_j`, `G_j`, and `Lambda_j`; hence `chiDPR Y** = infinity`. Dualizing the constructed equivalence `Y ≃ Z` twice transports this to `Z**`.

This reduction is sound at the mathematical level and avoids any global reflexivity or countable-sum dual identification **for this bidual obstruction**. It still requires proved isometric duality for two-term ℓ²-sums, finite-dimensional canonical bidual isometries, adjoint compatibility with Hadamard, and the qualitative local-Hilbert lemma. A mere bounded equivalence of product duals would introduce distortion and would not justify the unchanged separation constants. The global dual GL estimate may have independent countable-duality requirements; this shortcut does not settle that separate issue.

The notation in the preceding argument follows the original manuscript. For the new finite-frame construction, replace earlier-head `G` bounds by the corresponding `H` bounds, and use the revised overlap scale `L`, exactly as in `finite-analytic-shortcuts.md`. The bidual argument preserves those revised bounds as well, because the finite head isometries and dual Hadamard estimates introduce no extra loss.

An alternative, if the countable dual identifications are already available, is to prove the concrete bounded linear equivalence `Z ≃ Z**` by applying the explicit ℓ²-sum dual description twice and handling the projection range. That remains a valid route, but is no longer necessary for the nonlattice deduction.

The essential general ingredient is now **order-complete lattice discretization**, and BanLat provides genuine parts of it:

| Available declaration | Exact use and remaining work |
| --- | --- |
| `StrongDual.instConditionallyCompleteLattice`, `Dual.lean:375`; `StrongDual.instBanachLattice`, line 454 | The dual of any Banach lattice is an order-complete Banach lattice. Actual instance bodies are present. |
| `HasProjectionProperty.of_isOrderComplete`, `Substructures/Band/PPP.lean:56` | Every band admits a projection; the sigma-order-complete version supplies principal projections at line 70. |
| `ProjectionBand.bandProjection`, `Projection.lean:80`, with positivity at 159, domination by identity at 185, and identity/zero on the respective bands at 230/248 | Construct spectral threshold cuts for finite vectors dominated by a positive unit. |
| `ProjectionBand` Boolean algebra, `Projection.lean:744`; `bandProjection_inf`, `bandProjection_comm`, `bandProjection_compl`, lines 797/824/881 | Refine finitely many cuts into a common family of disjoint cells. |
| `abs_sum_of_pairwise_isVLDisjoint`, `Disjoint.lean:426`; `linearIndependent_of_pairwise_isVLDisjoint`, line 447 | Nonzero disjoint cell vectors form a basis of their span, with unconditional constant one by the solid norm. |

All these are in the [audited BanLat commit](https://github.com/davidmunozlahoz/banlat/tree/5c9360ccd9cef27b749f3cabda6348fd2529d1a3). No Freudenthal spectral approximation theorem, simultaneous finite-family disjoint approximation theorem, or DPR conclusion was found. A plausible new proof takes `u = sum_i |x_i|`, uses principal-band projections associated with `(x_i - t*u)^+` at finitely many grid thresholds, proves the resulting step approximations have order error at most `epsilon*u`, and refines all the grids into common disjoint cells. The solid norm gives arbitrarily small original-norm error. The shared finite-rank correction then converts approximation into an exact finite superspace. This is concrete and substantially narrower than a representation-theory detour, but is still a new spectral approximation development, not a ready-made one-line library application.

BanLat also supplies `finiteDimensional_iff_latticeIso_pi` in `BanLat/Atom.lean:1063`, `OrderIdeal.principalKakutaniEquiv` in `BanLat/AMSpace/Kakutani.lean:200`, and representation/order-continuity infrastructure in `BanLat/L1repr/`. These do not alone construct a finite-dimensional almost-unconditional **superspace of a given finite-dimensional subspace in the original norm**. A finite-dimensional subspace of a lattice need not itself be a sublattice. The principal-ideal representation uses its gauge norm; transporting its unconditional bounds directly back to the original norm introduces uncontrolled distortion. Order-error approximations from the band route avoid that norm issue.

In particular, a blanket claim that every finite family can be approximated by vectors in the span of finitely many disjoint elements is unsafe for arbitrary lattices: in `C[0,1]` with the supremum norm, simultaneously approximating the constant function and the identity function this way is obstructed by connectedness. General lattice discretization requires a more careful argument than simple-function approximation.

An alternative restriction to hypothetical reflexive/order-continuous lattices needs transfer to that class and the relevant approximation theorem. No reflexivity-to-order-continuity bridge was found in BanLat, and mathlib's `Analysis/Convex/Uniform.lean:26` explicitly lists Milman–Pettis as TODO. The dual-lattice route above is preferable. BanLat is also pinned to Lean/Mathlib 4.32.1, while the trial uses Lean 4.34.0-rc2, so reuse needs version alignment or a selective port.

## Complex case: prefer the direct finite-frame route

During this audit the other agents found a direct finite real/complex frame approach. This is preferable to introducing complexification. The proposed complex tensor estimate checks mathematically: if `T(A) = sum_k L_k A L_k*`, the Kraus-index Gram matrices and Cauchy–Schwarz give

`||T(x y*)||HS^2 <= ||T(x x*)||HS * ||T(y y*)||HS`.

Writing `A=T(xx*)`, `B=T(yy*)`, `K=T(xy*)`, the claimed one-factor output is the block matrix `[[2A+B,K],[K*,A+2B]]/3`. Its Hilbert–Schmidt norm squared is

`(5||A||HS^2 + 5||B||HS^2 + 8 Re<A,B>HS + 2||K||HS^2)/9`.

If each rank-one output satisfies `||T(xx*)||HS^2 <= r ||x||^4`, the Gram bound and ordinary Cauchy–Schwarz make this at most `(5r/9)(||x||^2+||y||^2)^2`. Thus this specific tensor estimate needs finite Kraus algebra and Cauchy–Schwarz, not King's general theorem. This is a checked mathematical reduction, **not a claim that the complex Lean proof is already compiled**. The finite-frame identities, tensor Kraus closure, conjugation, and the subsequent complex obstruction remain required.

For reference, the abandoned transfer option has the following nontrivial condition.

Plain complexification is not enough. A complex unconditional basis realifies to an unconditional basis of the underlying real space, but that underlying space is related to `Z ⊕ Z`, not to `Z` alone. Passing absence of DPR/bases from `Z` to its complexification by complemented-subspace inheritance would assume exactly the false inheritance principle this manuscript refutes.

A potentially shorter route than redoing every analytic estimate over ℂ is:

1. Strengthen the real obstruction to the doubled construction and its dual.
2. Complexify each real finite `ℓ_p → ℓ_p` projection. Its operator norm is preserved: integrate the real estimate applied to `Re(e^{it} z)`, using the identity `∫ |Re(e^{it} w)|^p dt = c_p |w|^p`. Applying this blockwise preserves arbitrarily-near-one projection bounds in the mixed ℓ²-sum.
3. Identify the complex range's realification with a uniformly isomorphic doubled real construction; compare `‖(x+iy)‖_p` with `(‖x‖_p²+‖y‖_p²)^(1/2)`.
4. Transfer the dual using the existing isometric real-linear equivalence `StrongDual.extendRCLikeₗᵢ`, in `Mathlib/Analysis/Normed/Module/RCLike/Extend.lean:91`.
5. Realify any hypothetical complex unconditional basis and contradict the doubled real obstruction.

The first step is essential and is not automatic from the existing one-copy argument. Duplicating a block leaves another copy with the same exponent in its complement, which does not satisfy the original later-block local-Hilbert smallness condition. One must adapt the obstruction to the whole doubled block, with controlled constants, or prove an independent square-stability result. Thus this is a credible mathematical direction to test, not an already verified shortcut. A scalar-generic proof over `RCLike` may ultimately be simpler than introducing and proving this transfer infrastructure.

## Assessment of a twelve-hour completion target

The existing trial supports rapid progress on definitions, norm transport, finite-dimensional algebra, and assembly. An ad hoc proof can omit general GL duality, local reflexivity, Milman–Pettis, King's general theorem, a general basis monograph, and unrelated stabilization results if the narrower routes above are completed.

It cannot omit the requested dual obstruction, both real complementary ranges, all quantitative norm bounds, the universal nonlattice conclusion, or a valid complex no-basis argument. The best corollary route now specifically adds order-complete lattice spectral approximation, finite-rank correction, and exact finite-product duality sufficient to repeat the obstruction in the bidual. Those are manageable mathematical subproblems but have not yet been measured through Lean implementation. Alongside the still-unproved overlap/local-Hilbert/selection/construction core, they remain critical dependencies. Twelve hours is an ambitious implementation experiment with exact end-to-end success criteria, not a defensible completion commitment from current evidence. A theorem conditional on any of these missing ingredients would not count as the requested full formalization.
