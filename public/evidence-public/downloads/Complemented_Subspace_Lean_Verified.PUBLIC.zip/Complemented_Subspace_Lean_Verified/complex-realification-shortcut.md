# Complex theorem through the verified real obstruction

> Historical working note from 5 September 2026. Status labels and proposed routes below record that stage of the implementation. See [README.md](README.md) for the current statements and proof route, and [the fresh-build log](verification/fresh-root-build.log) for final verification status.

The source complex unconditional-basis theorem asks for one complex
projection with norm arbitrarily close to one, and for the absence of an
unconditional basis in its range and continuous dual. It does not require
both complementary ranges. Pure tensor projections therefore suffice.

There is a shorter route than porting the trace and overlap arguments to
complex matrices. Use the complexification of the same finite four-point
real frame, with one fewer tensor factor in each complex block.

Write a complex coefficient vector as a+ib. If its tensor order is m, its
probability norm to the power p is the finite average of
`(f_a(t)^2 + f_b(t)^2)^(p/2)`. The real coefficient vector `(a,b)` of order
m+1 has norm to the power p given by the average over t of

`(|sqrt(2)*f_a(t)|^p + |sqrt(2)*f_b(t)|^p
  + |f_a(t)+f_b(t)|^p + |f_a(t)-f_b(t)|^p)/4`.

The two expressions are uniformly comparable because the extra four-point
frame is isotropic in real dimension two. For p in [2,3], the pointwise
probability-frame norm is between the Euclidean norm and
`2^(1/2-1/p)` times that norm. In particular, a fixed constant two suffices,
independently of m. Averaging in t proves an actual real linear equivalence
between the complex coefficient space of order m, regarded as real, and
the already verified real coefficient space of order m+1. Fixed constants
are sufficient here; no almost-isometric claim is needed.

For the actual recursive real orders n_j>0, use complex orders n_j-1 and
the same p_j. The complex tensor projection norm is bounded by
`exp(18*(n_j-1)*(p_j-2)^2)`, hence by `exp(18*eta)`. Its ambient is the actual
complex counting-norm finite-lp sum, already defined in ComplexAmbient.
ComplexAmbientSchauder supplies its actual sequential 1-unconditional
basis for all complex multipliers of modulus at most one.

The intended assembly has these concrete components:

1. An actual finite coefficient realification equivalence with uniform
   forward and inverse bounds, together with the coefficient-to-complex-
   projection-range isometry. The finite-obstruction worker owns this.
2. The existing real pure-frame diagonal projection sum, using
   `s.blockFrameProjection` and the good-index predicate `True`. The
   generic real primal and dual infinite DPR consumers already cover it.
3. A real continuous linear equivalence of the two entire lp2 sums,
   obtained by applying the uniformly bounded block equivalences
   coordinatewise. Normalized coefficient norms and actual counting
   projection-range norms must be related by their explicit scalar
   normalizations; no dimension-dependent scale may be suppressed.
4. A complex unconditional Schauder basis yields a real unconditional
   Schauder basis for the same norm by splitting each vector into b_i
   and i*b_i and each coordinate into real and imaginary parts. The
   local-Hilbert worker owns ComplexRealDPR. The generic real
   Schauder-to-DPR theorem then gives finite real DPR.
5. Mathlib already provides the exact dual realification isometry:
   `StrongDual.extendRCLikeₗᵢ (𝕜 := ℂ) (F := E)` identifies the continuous
   real dual with the continuous complex dual regarded as real. The
   inverse takes the real part. Combining it with the real dual of the
   global equivalence transfers the existing real dual DPR obstruction.

Thus both exclusions follow from DPR invariance under genuine bounded
linear isomorphisms of whole spaces. No DPR inheritance under complemented
subspaces is used. The construction also avoids a complex local-Hilbert
compactness argument, complex trace/overlap estimates, complex sphere
integration, the complex multiplicativity theorem, and finite conditional
expectation sampling.

The manuscript's complex sphere frame is not identified with this finite
complexified real frame. This is an alternative existential construction.
The finite signs module over complex scalars remains useful but is not
needed by this route. Alternating complex complementary ranges would
require additional work and are outside the stated complex target.

The comparisons and final assembly were implementation tasks when this
route was written. As of 21:28 UTC, item 4 and the exclusion wrappers for
item 5 have compiled in `ComplexRealDPR.lean`. Its seven selected axiom
checks all contain only `propext`, `Classical.choice`, and `Quot.sound`.
The realified basis is an actual Mathlib unconditional Schauder basis,
indexed by a disjoint union of two copies of the original index. A finite
convex-cube estimate controls complex scalar multipliers by four times a
subsum bound and proves the required unconditional convergence.

The ready endpoints are
`not_hasComplexUnconditionalSchauderBasis_of_real_equiv` and
`not_hasComplexUnconditionalSchauderBasis_dual_of_real_equiv`. They accept
the whole-space real equivalence and respectively the real primal or
dual infinite-DPR theorem. Status of the remaining construction and
equivalence modules belongs in the project README and their own audits.

## Final complex theorem: verified

The remaining construction and whole-space equivalence have now compiled.
`ComplexCorollary.lean` proves the unconditional theorem
`complexCorollary : ComplexCorollaryStatement`. It supplies the actual
complex projection, its strict norm bound, the actual ambient sequential
1-unconditional basis, and both range/dual basis exclusions. The final
transitive audit completed at 21:40 UTC with exactly `propext`,
`Classical.choice`, and `Quot.sound`; its output is persisted in
`verification/complex-corollary-axioms.log`.

`ComplexCorollaryAssembly.lean` isolates the final existential assembly
from the whole-range equivalence construction. The final theorem supplies
that premise with the actual proved equivalence, so it has no unproved
geometric or obstruction hypothesis.
