param(
    [Parameter(Mandatory = $true)]
    [string[]]$Modules
)

$ErrorActionPreference = 'Stop'
$shortcutRuntime = (Resolve-Path (Join-Path $PSScriptRoot '../../tmp/lean_library_definition_audit_2026-09-05/lean-4.34.0-rc2-windows/bin')).Path
$env:Path = $shortcutRuntime + ';' + $env:Path
$env:MATHLIB_CACHE_DIR = Join-Path $PSScriptRoot '.cache/mathlib'
$shortcutPackages = Get-ChildItem -Directory -LiteralPath (Join-Path $PSScriptRoot '.lake/packages')
$env:LEAN_SRC_PATH = ($shortcutPackages | ForEach-Object { $_.FullName }) -join ';'

Push-Location $PSScriptRoot
try {
    & '.lake/packages/mathlib/.lake/build/bin/cache.exe' get @Modules
    $shortcutCacheExit = $LASTEXITCODE
} finally {
    Pop-Location
}
exit $shortcutCacheExit
