param([switch]$Resume)

$ErrorActionPreference = 'Stop'
$rebuildExitCode = 0
$rebuildMutex = New-Object System.Threading.Mutex($false, 'Local\Codex_ComplementedSubspace_Lean_20260905')
$rebuildMutexHeld = $false
$rebuildOldPath = $env:Path
$rebuildOldThreads = $env:LEAN_NUM_THREADS
$rebuildOldCache = $env:MATHLIB_CACHE_DIR
$rebuildLogPath = Join-Path $PSScriptRoot 'verification/fresh-root-build.log'

try {
    try {
        $rebuildMutexHeld = $rebuildMutex.WaitOne()
    } catch [System.Threading.AbandonedMutexException] {
        $rebuildMutexHeld = $true
    }

    $rebuildProjectRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
    $rebuildProjectPrefix = $rebuildProjectRoot.TrimEnd([char[]]@('\', '/')) + [IO.Path]::DirectorySeparatorChar
    $rebuildBuildTarget = [IO.Path]::GetFullPath((Join-Path $rebuildProjectRoot '.lake/build'))
    if (-not $rebuildBuildTarget.StartsWith($rebuildProjectPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The resolved build directory is outside the project.'
    }
    $rebuildExpectedTarget = [IO.Path]::GetFullPath($rebuildProjectPrefix + '.lake' + [IO.Path]::DirectorySeparatorChar + 'build')
    if (-not [string]::Equals($rebuildBuildTarget, $rebuildExpectedTarget, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The build directory does not match this project''s .lake/build directory.'
    }
    foreach ($rebuildCheckedPath in @((Join-Path $rebuildProjectRoot '.lake'), $rebuildBuildTarget)) {
        if (Test-Path -LiteralPath $rebuildCheckedPath) {
            $rebuildCheckedItem = Get-Item -LiteralPath $rebuildCheckedPath -Force
            if (($rebuildCheckedItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Refusing to clean through a reparse point: $rebuildCheckedPath"
            }
            $rebuildResolvedPath = (Resolve-Path -LiteralPath $rebuildCheckedPath).Path
            if (-not $rebuildResolvedPath.StartsWith($rebuildProjectPrefix, [StringComparison]::OrdinalIgnoreCase)) {
                throw "The existing build path resolves outside the project: $rebuildResolvedPath"
            }
        }
    }
    $rebuildConfig = Get-Content -LiteralPath (Join-Path $rebuildProjectRoot 'lakefile.toml') -Raw
    if ($rebuildConfig -notmatch '(?m)^name\s*=\s*"complemented_subspace_trial"\s*$') {
        throw 'The root package name no longer matches the verified clean command.'
    }
    if ($rebuildConfig -match '(?m)^\s*buildDir\s*=') {
        throw 'A custom buildDir needs a new path validation before cleaning.'
    }

    $rebuildRuntime = (Resolve-Path -LiteralPath (Join-Path $rebuildProjectRoot '../../tmp/lean_library_definition_audit_2026-09-05/lean-4.34.0-rc2-windows/bin')).Path
    $rebuildLakeExe = Join-Path $rebuildRuntime 'lake.exe'
    $env:Path = $rebuildRuntime + ';' + $env:Path
    $env:LEAN_NUM_THREADS = '2'
    $env:MATHLIB_CACHE_DIR = Join-Path $rebuildProjectRoot '.cache/mathlib'
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $rebuildLogPath) | Out-Null
    if ($Resume) {
        if (-not (Test-Path -LiteralPath $rebuildLogPath)) {
            throw 'A resumed build requires the existing fresh-build log.'
        }
        $rebuildPriorLog = Get-Content -LiteralPath $rebuildLogPath -Raw
        if ($rebuildPriorLog -notmatch '(?m)^lake --no-cache clean complemented_subspace_trial\r?$') {
            throw 'The existing log does not record the initial root-only clean.'
        }
        "Resuming root-import build after source repair UTC: $([DateTime]::UtcNow.ToString('o'))" |
            Tee-Object -FilePath $rebuildLogPath -Append
    } else {
        "Fresh root-import build started UTC: $([DateTime]::UtcNow.ToString('o'))" |
            Set-Content -LiteralPath $rebuildLogPath
    }
    "Validated clean target: $rebuildBuildTarget" | Tee-Object -FilePath $rebuildLogPath -Append

    function Invoke-VerifiedLake {
        param([Parameter(Mandatory=$true)][string[]]$RebuildArguments)
        ('lake --no-cache ' + ($RebuildArguments -join ' ')) |
            Tee-Object -FilePath $rebuildLogPath -Append
        & $rebuildLakeExe --no-cache @RebuildArguments 2>&1 |
            Tee-Object -FilePath $rebuildLogPath -Append
        $rebuildCommandExit = $LASTEXITCODE
        if ($rebuildCommandExit -ne 0) {
            throw "Lake command failed with exit code $rebuildCommandExit."
        }
    }

    Push-Location -LiteralPath $rebuildProjectRoot
    try {
        if (-not $Resume) {
            Invoke-VerifiedLake -RebuildArguments @('clean', 'complemented_subspace_trial')
        }
        Invoke-VerifiedLake -RebuildArguments @('build', '+ComplementedSubspace:olean')
        Invoke-VerifiedLake -RebuildArguments @('env', 'lean', '-j1', '-M8192', 'WholeProjectAudit.lean')
    } finally {
        Pop-Location
    }
    "Fresh root-import build and axiom audit passed UTC: $([DateTime]::UtcNow.ToString('o'))" |
        Tee-Object -FilePath $rebuildLogPath -Append
} catch {
    $rebuildExitCode = 1
    $rebuildFailure = 'Fresh verification failed: ' + $_.Exception.Message
    if (Test-Path -LiteralPath (Split-Path -Parent $rebuildLogPath)) {
        $rebuildFailure | Tee-Object -FilePath $rebuildLogPath -Append
    } else {
        Write-Output $rebuildFailure
    }
} finally {
    $env:Path = $rebuildOldPath
    $env:LEAN_NUM_THREADS = $rebuildOldThreads
    $env:MATHLIB_CACHE_DIR = $rebuildOldCache
    if ($rebuildMutexHeld) {
        $rebuildMutex.ReleaseMutex()
    }
    $rebuildMutex.Dispose()
}

exit $rebuildExitCode
