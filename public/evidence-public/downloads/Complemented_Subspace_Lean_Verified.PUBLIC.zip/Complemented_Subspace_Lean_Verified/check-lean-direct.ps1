param(
    [Parameter(Mandatory=$true)][string]$LeanFile,
    [switch]$EmitOlean
)
$ErrorActionPreference = 'Stop'
$directCompileMutex = New-Object System.Threading.Mutex($false, 'Local\Codex_ComplementedSubspace_Lean_20260905')
$directCompileMutexHeld = $false
try {
    try {
        $directCompileMutexHeld = $directCompileMutex.WaitOne()
    } catch [System.Threading.AbandonedMutexException] {
        $directCompileMutexHeld = $true
    }
    $directStatusPath = Join-Path $PSScriptRoot 'verification/direct-compiler-status.json'
    $directStatus = @{
        leanFile = $LeanFile
        startedUtc = [DateTime]::UtcNow.ToString('o')
        powershellPid = $PID
        status = 'running'
    }
    $directStatus | ConvertTo-Json | Set-Content -LiteralPath $directStatusPath
$directRuntime = (Resolve-Path (Join-Path $PSScriptRoot '../../tmp/lean_library_definition_audit_2026-09-05/lean-4.34.0-rc2-windows/bin')).Path
$env:Path = $directRuntime + ';' + $env:Path
$directLibraryPaths = @((Join-Path $PSScriptRoot '.lake/build/lib/lean'))
$directPackages = Get-ChildItem -Directory -LiteralPath (Join-Path $PSScriptRoot '.lake/packages')
foreach ($directPackage in $directPackages) {
    $directLibraryPaths += Join-Path $directPackage.FullName '.lake/build/lib/lean'
}
$env:LEAN_PATH = $directLibraryPaths -join ';'
Push-Location $PSScriptRoot
try {
    $directArguments = @($LeanFile)
    if ($EmitOlean) {
        $directOutput = Join-Path $PSScriptRoot ('.lake/build/lib/lean/' + [IO.Path]::ChangeExtension($LeanFile, 'olean'))
        $directOutputDirectory = Split-Path -Parent $directOutput
        New-Item -ItemType Directory -Force -Path $directOutputDirectory | Out-Null
        $directArguments += @('-o', $directOutput)
    }
    & (Join-Path $directRuntime 'lean.exe') @directArguments
    $directExit = $LASTEXITCODE
    $directStatus.status = 'finished'
    $directStatus.exitCode = $directExit
    $directStatus.finishedUtc = [DateTime]::UtcNow.ToString('o')
    $directStatus | ConvertTo-Json | Set-Content -LiteralPath $directStatusPath
} finally {
    Pop-Location
}
} finally {
    if ($directCompileMutexHeld) {
        $directCompileMutex.ReleaseMutex()
    }
    $directCompileMutex.Dispose()
}
exit $directExit
