# Complex shortcut: independent semantic review

The initial review was made on 5 September 2026 at 21:35 UTC. A subsequent
review caught the finite-basis convention described below; the definition and
three proof wrappers have been corrected. The final root build and transitive
axiom audit passed for the corrected statements at 22:26 UTC. No change to the complex frame
construction or its estimates was needed.

## Finite bases count

The manuscript explicitly includes finite bases in finite-dimensional spaces.
The initial sequential-only predicate was too weak: a zero projection would
have a range and dual without an ℕ-indexed basis. The corrected
`HasUnconditionalSchauderBasis` is the disjunction of a basis indexed by `Fin n`
for some n and a basis indexed by ℕ. In particular, the empty basis counts.
The negative range and dual conclusions now exclude both cases. The existing
real and complex DPR lemmas accept arbitrary index types, so the correction
requires only case splits in three proof wrappers. The ambient still has an
actual ℕ-indexed 1-unconditional basis, which is a sufficient stronger witness.

## Match to the manuscript

`ComplexCorollaryStatement` is the complex instance of the supplied
`1-Introduction.tex`, theorem `thm:main`: for every positive tolerance, a
complex Banach space with a sequential 1-unconditional Schauder basis has a
complex-linear idempotent of norm strictly below one plus that tolerance,
whose range and continuous complex dual have no unconditional Schauder
basis. The real-only nonlattice conclusions are correctly absent from this
complex statement. The later paragraph about particular shrinking and
boundedly complete Schauder bases is not an additional conjunct of this
target.

## Norms and scalar fields

`ComplexAmbient` is the actual dependent `lp` sum with outer exponent two
and finite complex `PiLp` blocks. Its Banach model packages those existing
normed-group, complex normed-space and completeness instances. Projection
bounds are proved on arbitrary complex input vectors through complex
modulus energies and complex tensor slices; they are not inferred merely
from the real operator norm.

`ComplexFrameCoefficient` has the norm induced by its injective embedding
`4^(-n/p) W_n`. Its exact norm-to-the-p-th-power formula is the mean of the
complex moduli to the p-th power. The embedding range is proved equal to
the actual complex projection range. The Gram formula's ordinary transpose
is valid here because every entry of `W_n` is real.

`IsOneUnconditional` quantifies every complex multiplier of modulus at most
one. `ComplexAmbientSchauder` proves precisely that condition, including all
complex phases, and proves convergence over all finite scalar coordinate
sets. `ComplexRealDPR` constructs the real basis from `b_i` and `i*b_i`, with
continuous real and imaginary coordinate functionals and unconditional
expansion in the same inherited norm.

## Whole-space comparison and the order shift

The explicit block realification sends `a+i*b` to the real coefficient pair
`(a,b)`. Adding one four-row factor gives mean square exactly `|z|^2` and,
for `p >= 2`, actual norm inequalities
`norm_complex <= norm_real <= 2*norm_complex`.
Thus the forward and inverse bounds are uniform in both block order and
the chosen exponents. `LpUniformEquiv` lifts the block equivalences to the
entire outer sum, while `lpDiagonalRangeEquivScalar` identifies that sum
isometrically with the entire diagonal range. `predecessorComplexRangeRealEquiv`
therefore compares full spaces, not a selected complemented subspace.
The DPR step uses invariance under this whole-space isomorphism; it never
asserts DPR inheritance under arbitrary projections.

Each real recursive order is positive. Consequently `(order-1)+1=order`
is proved before the coefficient reindexing, and the complex ambient
dimension `4^(order-1)` is positive. Order one is harmless: the complex
zero-fold frame is defined and acts on a one-dimensional complex block.

## Dual and final conclusions

`complexDualRealIsometry` is Mathlib's actual real linear isometry between
the continuous complex dual and continuous real dual: forward evaluation
takes real parts, and the inverse sends `f` to `x ↦ f(x)-i*f(i*x)`.
It preserves operator norms. Composing it with the dual of the full range
equivalence correctly connects the complex dual to the real dual of the
verified pure frame profile. Both real DPR obstructions are available for
that pure profile. Completeness of the projection range follows from its
closedness as an idempotent range; the strong dual is complete.

No source-level `sorry`, `admit`, new `axiom`, unsafe declaration or trust
override was found in the reviewed shortcut and consumer modules. The finite
basis correction changes the statement predicate and its elimination wrappers;
the construction and analytic estimates are unchanged.
