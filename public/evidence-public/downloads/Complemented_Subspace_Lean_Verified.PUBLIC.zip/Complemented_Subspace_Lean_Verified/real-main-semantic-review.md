# Independent semantic review of the real main theorem

> Dated semantic review. For current statement conventions and final verification status, see [README.md](README.md) and [the fresh-build log](verification/fresh-root-build.log).

Reviewed on 2026-09-05 against `manuscript/1-Introduction.tex` and
`manuscript/1a-Preliminaries.tex`, together with `TheoremStatement.lean`,
`LocalUnconditional.lean`, the actual recursive projections, and the finite
and infinite dual DPR consumers. This is a mathematical interface review;
the project-wide compilation and axiom audit are separate checks.

No mathematical mismatch was found in the reviewed real statement,
definitions, or finite-dual interfaces.

- The finite basis constant uses every real multiplier of modulus at most
  one. The maximum with one agrees with the manuscript's convention and
  only affects the harmless zero-space case.
- The DPR infimum ranges over all finite-dimensional superspaces in the
  same ambient space with their inherited norms. Its outer supremum
  explicitly excludes the zero initial subspace and explicitly requires
  finite dimensionality. Infinite-dimensional spaces are not admitted
  accidentally through a zero `finrank` value.
- The GL auxiliary norm is an arbitrary positive-definite seminorm on a
  finite real coordinate space. It gives a genuine complete finite
  normed space with a 1-unconditional basis. The two implemented transport
  directions compare the certified-bound costs with actual operator-norm
  costs without increasing the infimum. The second map is not required
  to be injective, as required by the manuscript.
- `Ambient` is the actual dependent counting-norm finite-lp sum with outer
  exponent two. Dimensions are positive. Exponents lie in `(2,3]`, are
  antitone, and converge to two. Indexing from zero instead of one makes
  no mathematical difference; the chosen recursive sequence is in fact
  strictly decreasing.
- The lattice predicate preserves the ambient addition, real scalar
  multiplication, complete metric, and norm. It supplies a compatible
  lattice order and solid norm. It does not merely ask for an equivalent
  lattice norm.
- Both complementary maps are actual bounded operators on this same
  ambient space. Idempotence is explicit. Both norm inequalities are
  strict and use the given ambient norm. The range and range dual GL
  bounds use their actual inherited and continuous operator norms and
  the norm of their respective projection.
- The dual DPR consumer considers every finite superspace of a nonzero
  finite dual summand. It uses the actual dual of that superspace, the
  finite-dimensional bidual isometry for the frame summand, and the
  exact two-term lp2 dual isometry. No infinite-dimensional reflexivity
  hypothesis is inserted or silently assumed.
- The local dual estimate quantifies over arbitrary subspaces V of the
  complementary dual and then over small finite subspaces of V*. This
  is the stronger property needed by the consumer. Its distortion is
  exactly `2D`, and the consumer uses the matching `16K <= D` scalar
  separation bound. The recursive construction supplies both this
  small-subspace threshold and `D^8 < L` with the same parameters.
- Even and odd indices supply unbounded families of genuine frame
  summands for the two complementary ranges. Their lower bounds force
  the DPR constants to infinity without assuming that any infimum is
  attained. In particular the separation conclusions cannot be vacuous
  statements about the zero space.

The remaining terminology distinction is already documented in the target:
the Lean statement asks for uniform convexity of the actual ambient norm.
This mathematically implies the manuscript's superreflexivity assertion,
but the general implication or characterization of superreflexivity has
not itself been formalized here. Also, this statement is expressly the real
main theorem; it does not assert the complex theorem or all subsequent
corollaries merely by its name.

`realMainTheorem` has now compiled and passed its transitive axiom audit.
`RealMainConsequences.lean` also proves the full real corollary and separable
nonprimarity statement; the range-dual nonlattice conclusion uses the separate
bidual DPR obstruction. `MainTheoremReview.lean` remains a display of statement
aliases, with its status comments updated to identify the actual proof modules.
