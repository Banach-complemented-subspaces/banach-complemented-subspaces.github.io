# Recursive construction parameters

> Component progress log from 5 September 2026. Checkpoints below are historical; current statement conventions are documented in [README.md](README.md), and final verification status is recorded in [the fresh-build log](verification/fresh-root-build.log).

`RecursiveParameters.lean` compiled at approximately 19:37 UTC on 5 September
2026. It implements actual recursive simultaneous choices rather than merely
assuming a suitable parameter sequence exists.

The generic interface is `exists_recursiveFrameSelection`: for a fixed positive
quadratic-error tolerance eta and any positive geometry tolerance theta(n), it
returns integer orders n_j>0, exponents 2<p_j<=3, and head bounds D_j satisfying:

* the exponents strictly decrease to two;
* n_j(p_j-2)^2 < eta at every stage;
* D_j >= j+2 and D_j dominates every earlier full ambient Hilbert bound
  `(4^n_i)^(1/2-1/p_i)`;
* L_j > D_j^8, hence L_j tends to infinity;
* p_j-2 < theta(n_i) whenever i<j.

The proof uses a list of previous choices. A finite minimum of their positive
tolerances and `1/(j+1)` supplies the next allowable exponent error. The
previously verified scalar existence theorem supplies the next integer order
and exponent with arbitrarily large L and sufficiently small quadratic error.
No effective recurrence bound or general dependent-choice axiom is added:
ordinary natural recursion and Lean's standard classical choice suffice.

For the actual geometry, theta(n) is selected from continuity of
`nu(p)=2^(2-4/p)` at p=2 and the verified local Hilbert threshold for dimension
`3*2^n` and distortion two. The construction `recursiveFrameSelection` includes
this choice, and `recursiveFrameSelection_later_parallelogram` verifies the
required relation between each later block and every earlier threshold.

The full ambient bound is retained explicitly. Using only the distinguished
witness scale g here would be invalid for complementary ranges. The chosen
head bound is the maximum of two and the earlier ambient bounds, plus j; the
extra j guarantees divergence while preserving the manuscript's inequalities.

The conversion `RecursiveFrameSelection.toBlockParameters` supplies actual
ambient dimensions N_j=4^n_j and the selected p_j to the existing `Ambient`
construction. The further assembly of the ambient projection and the global
non-DPR conclusion is outside this parameter module.

The selected audit in `RecursiveParametersAudit.lean` passes for the recursive
existence theorem, overlap divergence, actual ambient parameter conversion,
local Hilbert threshold, and later-block threshold relation. All use only
`propext`, `Classical.choice`, and `Quot.sound`.
