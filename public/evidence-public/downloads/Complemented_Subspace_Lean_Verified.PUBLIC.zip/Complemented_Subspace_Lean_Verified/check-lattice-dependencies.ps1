param([switch]$RecheckAll, [string]$RootModule = 'BanLat.Dual')
$ErrorActionPreference = 'Stop'
$latticePortSeen = [Collections.Generic.HashSet[string]]::new()
$latticePortOrder = [Collections.Generic.List[string]]::new()
function Add-LatticeDependency([string]$LatticeModule) {
    if (-not $latticePortSeen.Add($LatticeModule)) { return }
    $latticePortFile = Join-Path $PSScriptRoot ($LatticeModule.Replace('.', '/') + '.lean')
    $latticePortText = Get-Content -Raw -LiteralPath $latticePortFile
    foreach ($latticePortMatch in [regex]::Matches($latticePortText, '(?m)^import (BanLat\.[A-Za-z0-9_.]+)')) {
        Add-LatticeDependency $latticePortMatch.Groups[1].Value
    }
    $latticePortOrder.Add($LatticeModule)
}
Add-LatticeDependency $RootModule
foreach ($latticePortModule in $latticePortOrder) {
    $latticePortRelative = $latticePortModule.Replace('.', '/') + '.lean'
    $latticePortSource = Get-Item -LiteralPath (Join-Path $PSScriptRoot $latticePortRelative)
    $latticePortOutput = Join-Path $PSScriptRoot ('.lake/build/lib/lean/' + $latticePortModule.Replace('.', '/') + '.olean')
    if (-not $RecheckAll -and (Test-Path -LiteralPath $latticePortOutput)) {
        if ((Get-Item -LiteralPath $latticePortOutput).LastWriteTimeUtc -gt $latticePortSource.LastWriteTimeUtc) {
            continue
        }
    }
    Write-Output "Checking $latticePortModule"
    & (Join-Path $PSScriptRoot 'check-lean-direct.ps1') -LeanFile $latticePortRelative -EmitOlean
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
Write-Output 'All selected BanLat dependencies compiled.'
