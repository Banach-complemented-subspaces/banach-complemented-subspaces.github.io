param([string[]]$LakeArguments = @('build'))

$ErrorActionPreference = 'Stop'
$trialRuntime = (Resolve-Path (Join-Path $PSScriptRoot '../../tmp/lean_library_definition_audit_2026-09-05/lean-4.34.0-rc2-windows/bin')).Path
$env:Path = $trialRuntime + ';' + $env:Path
$env:MATHLIB_CACHE_DIR = Join-Path $PSScriptRoot '.cache/mathlib'
Push-Location $PSScriptRoot
try {
    & (Join-Path $trialRuntime 'lake.exe') --no-cache @LakeArguments
    $trialExitCode = $LASTEXITCODE
} finally {
    Pop-Location
}
exit $trialExitCode

