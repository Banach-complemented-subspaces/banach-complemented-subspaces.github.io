# Geometry shortcuts for the Lean formalization

> Historical working note from 5 September 2026. Status labels and proposed routes below record that stage of the implementation. See [README.md](README.md) for the current statements and proof route, and [the fresh-build log](verification/fresh-root-build.log) for final verification status.

This is a mathematical and library feasibility audit using the supplied `6-Infinite-sum.tex`, `7a-Banach-lattices.tex`, and the pinned local Mathlib source. The elementary Hilbert complement bound below was subsequently compiled in `HilbertComplement.lean`. The other geometry reductions remain mathematical plans; see `shortcut-plan.md` for current verification.

## 1. Replace Passer's quantitative theorem by qualitative compactness

The construction only uses an existential threshold: for each integer k and D > 1, sufficiently small parallelogram defect implies every space of dimension at most k is D-Hilbertian. It never evaluates the threshold numerically. Thus no explicit approximate Jordan-von Neumann rate is needed.

A sufficient lemma is:

> For each k and D > 1, there exists nu > 1 such that every real normed space E with dim E <= k and
> `||x+y||^2 + ||x-y||^2 <= 2*nu*(||x||^2+||y||^2)`
> admits a Hilbert norm h with `h(x) <= ||x|| <= D*h(x)` for every x.

The reverse inequality follows by applying the displayed inequality to x+y and x-y. Here is a self-contained compactness proof.

1. In each positive dimension d, choose coordinates in which the norm q satisfies
   `2^(-(d-1))*||a||_infinity <= q(a) <= d*||a||_infinity`.
   Auerbach bases and John's ellipsoid are unnecessary. Induct on dimension: choose a unit vector e and a norm-one Hahn-Banach functional f with f(e)=1; apply induction to ker f. The projection x -> x-f(x)e has norm at most two. The resulting basis vectors have norm one and their coefficient functionals have norm at most 2^(d-1).
2. These normalized norms form a compact family in the topology of uniform convergence on compact sets. They are uniformly d-Lipschitz, pointwise bounded, and the norm axioms and the two displayed bounds are closed under pointwise limits. Use Tychonoff plus Arzela-Ascoli.
3. If the assertion fails, take such norms with parallelogram constants tending to one. A convergent subnet/subsequence has a genuine norm q_infinity satisfying the exact parallelogram identity. The lower normalization bound prevents a seminorm degeneration.
4. The existing `InnerProductSpace.ofNorm` supplies an inner product for q_infinity.
5. Uniform convergence on the infinity-norm unit sphere implies `(1-t)*q_infinity <= q_n <= (1+t)*q_infinity` eventually, for any t>0. Choose t so `(1+t)/(1-t) < D`, and rescale q_infinity. This contradicts failure of D-Hilbertianity.
6. Take the minimum of the finitely many dimension thresholds, with dimensions zero and one handled directly.

Relevant existing Mathlib ingredients:

- `Analysis/Normed/Module/HahnBanach.lean`: `exists_dual_vector`.
- `Topology/UniformSpace/Ascoli.lean`: `ArzelaAscoli.isCompact_of_equicontinuous` and related compactness theorems.
- `Analysis/InnerProductSpace/OfNorm.lean`: `InnerProductSpace.ofNorm`.
- Finite-dimensional spheres are compact; finite-dimensional linear maps are continuous.

The normalization induction and the compact family of norms are **new formalization work**. I found no Auerbach or approximate Jordan-von Neumann theorem in the checked Mathlib, TauCeti, or BanLat sources. This route removes a sophisticated quantitative theorem, but is still a plausible multi-hour proof-engineering task rather than an already available lemma. A naive limit of arbitrarily chosen coordinate norms is invalid: the uniform lower bound is essential.

## 2. Eliminate Stern's projection theorem using dimension two

Suppose every subspace of X of dimension at most two is D-Hilbertian, P is a nonzero bounded idempotent, and D >= 1. Then the following weaker bound suffices:

> `||I-P|| <= D^2 * ||P||`.

For each x, the space span{x,Px} is invariant under P and has dimension at most two. Transfer its norm to a Hilbert norm with distortion D, use the Hilbert projection-complement estimate, and transfer back. If P vanishes on this small space, the estimate follows from the global fact ||P||>=1.

Even the Hilbert step can be proved directly without spectral theory or an orthonormal basis. For x=y+z with y=Px and Pz=0, put t=<y,z> and

`w = ||z||^2*y - t*z`.

Then `Pw=||z||^2*y`, and direct expansion gives

`||z||^2*||y||^2*||x||^2 - ||w||^2 = ||z||^2*(||y||^2+t)^2 >= 0`.

When y,z are nonzero, applying the operator norm bound to w and cancelling gives `||z|| <= ||P||*||x||`. The remaining zero cases are immediate, with ||P||>=1 used when y=0. This proof uses inner-product expansions and scalar algebra only.

Since the local-Hilbert threshold works for arbitrary D>1, we can arrange D approaching one as p approaches two. Together with the already intended ||R_n|| -> 1, this gives ||I-R_n|| -> 1. The exact constant `2^(1-2/p)` is not required by the existential main theorem. This removes Stern completely **provided** the qualitative local-Hilbert lemma is established.

## 3. Remove quotient identifications from the dual obstruction

The manuscript identifies V* with W/V_perp. For the local-Hilbert part, this can be avoided.

Define the approximate parallelogram property by the norm bound on the normalized Hadamard map

`H(x,y) = ((x+y)/sqrt(2), (x-y)/sqrt(2))`

on the two-term l2 sum. Under the elementary isometry

`(S direct_sum_2 S)* = S* direct_sum_2 S*`,

the Banach adjoint of H is the same Hadamard map. Thus the property with constant nu passes from S to S*, to every subspace V of S*, and then to V*. Applying the qualitative finite-dimensional lemma gives the needed local-Hilbert conclusion for V*.

This avoids the quotient W/V_perp, proving surjectivity of its evaluation map onto V*, and invoking reflexivity just for that identification. Only the dual of a **two-term** l2 sum is needed here; a theorem identifying the dual of an arbitrary countable sum is not required for this local step. The head/tail comparison maps still need to be transported, with their distortion D_j.

An alternative direct proof of dual stability uses, for x,y in S,

`(f+g)(x)+(f-g)(y) = f(x+y)+g(x-y)`

followed by Cauchy-Schwarz and near-norm-attaining vectors for f+g and f-g. This may be cheaper than introducing the explicit two-term dual isometry. It needs no abstract reflexivity theorem.

The full main theorem's other dual conclusions still need their own work: coordinate approximation in the ambient dual, the dual block decomposition if used for FDD/MAP, and preservation of the DPR obstruction under the constructed isomorphisms do not disappear.

## 4. Uniform convexity cannot be silently discarded

The supplied real target uses the actual l2 sum of finite lp blocks. Although each block is finite-dimensional and strictly convex, this alone does not prove the infinite sum is uniformly convex: a common modulus is needed. Likewise, an approximate parallelogram inequality with a fixed constant greater than one is not itself a uniform-convexity proof.

A tailored proof can use Clarkson only for finite scalar-coordinate blocks with 2 <= p <= 3, followed by a direct two-case estimate on block norms and normalized block directions for their l2 sum. Any positive common modulus is sufficient; the exact `epsilon^3/24` in the manuscript need not be preserved. There is no need to formalize arbitrary measure-space Lp uniform convexity or a reusable general theorem on all direct sums. Nevertheless, finite-coordinate Clarkson and the l2 aggregation remain substantive new estimates: searches found no ready-to-use versions in the checked sources.

The currently compiling `RealMainTheoremStatement` asks for `UniformConvexSpace` and explicitly does not prove the implication to the manuscript's superreflexivity assertion. An exact formalization of all published corollaries must resolve that bridge or use an explicitly agreed equivalent definition of superreflexivity. Calling the current target an already exact statement of every corollary would overstate its scope.

## Suggested timing experiment and assessment

The most informative geometry experiment is to implement, with no new axioms:

1. The elementary Hilbert complement bound above.
2. Stability of approximate parallelogram bounds under continuous duals.
3. The normalized-norm compactness theorem in a fixed but arbitrary dimension.

The first is a small, concrete compiler gate. The third is the decisive integration risk. These shortcuts are mathematically sound and remove major named results, but the local geometry path is not yet compiled and does not support high confidence in a 12-hour whole-paper deadline. A successful first 60–90 minutes on the first two gates and visible progress on compactness would provide meaningful timing evidence. Failure to bridge the norm-family compactness API within a few hours would be a reason to revise the 12-hour expectation promptly.

The estimates above are feasibility judgments, not measured Lean completion times. The main finite packet construction, parameter recursion, infinite-dimensional DPR argument, Banach-lattice nonisomorphism corollary, and complex case are outside this geometry audit.
