# Finite correction and local constants

> Component progress log from 5 September 2026. Checkpoints below are historical; current statement conventions are documented in [README.md](README.md), and final verification status is recorded in [the fresh-build log](verification/fresh-root-build.log).

The three modules `FiniteCorrection.lean`, `BasisTransport.lean`, and
`FiniteApproximation.lean` compile with the pinned compiler. The first two
passed at approximately 18:01 and 18:03 UTC; the complete approximation module
passed after its second diagnostic pass later in the same implementation run.
They were included in the integrated 730-declaration transitive axiom audit,
which passed with only the standard three axioms.

The proof uses Hahn--Banach to extend the coordinates of a finite basis. Given
errors d_i and extended coordinates f_i, set U = sum_i f_i tensor d_i. The
proved bound is ||U|| <= sum_i ||f_i|| ||d_i||. If that sum is at most epsilon<1,
the actual ambient automorphism T=id+U has norm at most 1+epsilon and inverse
norm at most (1-epsilon)^(-1). It maps the original basis to its prescribed
approximants exactly.

Pulling a common approximating finite span back through T produces a genuine
finite superspace in the original ambient norm. Conjugating every basis
multiplier gives its quantitative unconditional bound. Finally, arbitrarily
small corrections give chiDPR<=C and chiGL<=C with no loss in the final constant.
The proof handles nonattained infima; it does not select an optimal basis.

This single argument replaces separate approximation-correction arguments in
the planned ambient, Schauder-basis and lattice applications. Those applications
must still establish `HasFiniteUnconditionalApproximations E C`; the current
theorems do not assume or assert that every Banach space has this property.

Checks used `check-lean-direct.ps1 -LeanFile <module> -EmitOlean`. This helper
uses the exact pinned Lean kernel and dependency artifacts without retaining
a Lake process during individual diagnostics. Final integration still uses
the ordinary project build and whole-project axiom audit.

Further root modules compiled during the sustained run:

- `DenseContractions`: strong convergence of contractive continuous linear
  maps that fix every vector in a dense set eventually.
- `AmbientBasis`: actual scalar coordinates, their biorthogonality and linear
  independence, dense span, contractive finite scalar multipliers and
  unconditional norm-convergent expansion.
- `AmbientSchauder`: a genuine natural-number enumeration gives the exact
  `HasOneUnconditionalSchauderBasis ℝ (Ambient a)` predicate in the corollary.
- `FrameCoefficient`: a fresh coefficient-space type carries the norm induced
  by `(4^n)^(-1/p) W` into counting `PiLp`, with actual finite dimensionality,
  completeness and linear isometric embedding.
- `FrameCoefficientNorm`: its norm to the power p equals the finite average
  of the absolute pth powers of the frame evaluation. The powered lower and
  upper Hilbert comparisons use the verified product-frame estimates.
- `FrameCoefficientRange`: an actual linear isometric equivalence onto the
  tensor projection's range, using the inherited counting-PiLp norm.

These statements preserve the original local-structure definitions. In
particular, scalar unconditional convergence is stronger information than
the previously verified expansion by whole finite-dimensional blocks.
