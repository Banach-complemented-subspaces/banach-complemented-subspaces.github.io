# Main theorem: semantic review against the LaTeX source

This document distinguishes the mathematical review from the compiler and axiom
checks recorded below.
Reviewed sources: `output/pdf/csp_revised/1-Introduction.tex`,
`1a-Preliminaries.tex`, and `7a-Banach-lattices.tex`.

## Exact scope

The real main theorem quantifies over every real `rho > 0`. Its witnesses are
positive integer dimensions `N j`, real exponents `p j` in `(2, 3]` decreasing to
2, and a continuous linear idempotent on the counting-norm space

```
X = lp (fun j => PiLp (p j) (fun _ : Fin (N j) => Real)) 2.
```

This line abbreviates the actual compiled `Ambient` definition; exponent
coercions are explicit in its source. The paper explicitly defines its natural
numbers as `{1,2,...}`, so positivity of all dimensions must not be omitted.
Indexing the sequence from Lean's zero instead of the paper's one is harmless.
`Antitone p` and convergence to 2 express the stated downward convergence;
strict decrease is an optional stronger conclusion, not required by the notation.

The ambient space is a separable, superreflexive real Banach lattice. The proof
in fact establishes uniform convexity for its inherited norm, as does the Lean
implementation. `IsSuperreflexiveByRenorming` packages the standard uniformly
convex renormability characterization using an actual Banach model and bounded
linear isomorphism. The general equivalence with a finite-representability
definition is not formalized here. Calling an arbitrary predicate
`Superreflexive`, or substituting ordinary reflexivity, would not formalize the
claimed property.

Put `Q = id - P`. Required projection conditions and inequalities are:

1. `P.comp P = P`.
2. `norm P < 1 + rho` and `norm Q < 1 + rho`.
3. For each of the range and continuous dual of `P`, the GL constant is at most
   `norm P` and the DPR constant is infinity.
4. For each of the range and continuous dual of `Q`, the GL constant is at most
   `norm Q` and the DPR constant is infinity.

The ranges carry their inherited norms. Submodule subtype norms provide this
directly. Duals are continuous linear maps to the scalar field with the operator
norm. It is insufficient to choose independent renormings of the range and dual
when recording these quantitative bounds.

## Local unconditional constants

The constants are extended nonnegative reals. Using `ENNReal` makes empty infima
equal infinity, as required; real-valued `sInf` without extra conventions does
not. The exact definitions are:

- The unconditional bound on a finite basis permits every scalar multiplier
  family with absolute values at most one. Restricting to signs requires a
  proved equivalence over the reals; the complex statement permits all complex
  multipliers, not merely real signs.
- `u(F)` is an infimum over basis constants. A basis realizing this infimum is
  not assumed.
- The local DPR value for a nonzero finite-dimensional `V <= Z` is the infimum
  of `u(F)` over finite-dimensional submodules `F` of the SAME `Z` containing V.
- The local GL value is the infimum of products of operator norms over exact
  factorizations of the inclusion `V -> Z` through a finite-dimensional auxiliary
  normed space having a 1-unconditional basis. The second factor need not be
  injective; the auxiliary space need not embed in Z.
- The global values are suprema over all nonzero finite-dimensional submodules V.

Flattening the two DPR infima into a single infimum over superspaces and bases
is mathematically sound. Encoding the finite GL bound by exact witnesses at the
claimed bound is generally stronger than the source: arbitrary epsilon slack
must be allowed unless an attainment theorem is proved. The ENNReal infimum
definition avoids this pitfall.

Auxiliary finite spaces may be represented on `Fin n -> Real` with arbitrary
norms and their coordinate bases, since transporting a finite-dimensional space
and chosen basis gives such a representation. The representation must permit
arbitrary norms; fixing its usual sup norm would alter the definition severely.
If this representation is used, equivalence to the intrinsic definition is a
separate useful theorem, not an unmentioned library fact.

## Lean construction issues

- The finite `PiLp` or `WithLp` norm requires `Fact (1 <= p j)`. A subtype
  restriction `p j` in `(2,3]` does not automatically register that instance.
- For GL bounds with values in `ENNReal`, compare with `(nnnorm P : ENNReal)`
  or `ENNReal.ofReal (norm P)` using the library's actual notation.
- A projection range is a submodule; completeness follows from closedness of
  the range of a continuous idempotent. Proving or installing this fact is
  preferable to introducing an additional unrelated Banach structure.
- `P.range` and `Q.range` can be used as types through submodule coercions.
  Writing their duals as continuous maps to Real avoids naming discrepancies
  between versions of the dual-space API.
- The norm of `id - P` is not controlled by the norm of P alone. The source's
  second bound uses Stern's projection estimate and a modified alternating
  construction. Treating the complementary-range theorem as an automatic
  consequence of the first range would omit substantive mathematics.
- The complex corollary is distinct from the real main theorem. A real-only
  definitions file should state its scope explicitly.

## Implementation review

The initial implementation of `ComplementedSubspace/LocalUnconditional.lean`
was reviewed against the source. Its real multiplier convention, inherited
submodule norms, exclusion of the zero initial subspace, both DPR infimum
levels, and arbitrary-norm GL coordinate representation match the intended
mathematics. No semantic defect was found in those definitions. Its `u(0)=1`
convention has no effect on the constants of nonzero spaces.

The implementation now proves both GL witness conversions:
`ofUnconditionalBasis` transports arbitrary finite normed auxiliary spaces to
coordinates with the exact operator-norm cost; `Aux`, `auxA`, and `auxB` turn a
coordinate witness into an actual finite-dimensional complete normed space and
bounded operators with no increase in cost. These are proved constructions,
not axiom declarations. An equality to a separately defined intrinsic infimum
is not separately declared.

`ComplementedSubspace/GLRetraction.lean` adds proof bodies for transport of
individual factorizations, their exact cost multiplication, passage to local
infima and global suprema, and the projection-range GL upper estimate. The
ambient assertion `chiGL X <= 1` is an explicit hypothesis of the final
projection estimate; it has not been smuggled in as an axiom.

`ComplementedSubspace/DPRtoGL.lean` was independently reviewed mathematically.
The multiplier family contains the identity and is closed under composition;
the finite C-bound justifies its seminorm supremum, and the identity multiplier
gives the lower norm bound needed for positive definiteness. The finite and
infinite fixed-basis-constant cases are separated correctly. Passing to basis
and superspace infima introduces no attainment assumption. No semantic defect
was found in that source.

## Early compiler and axiom checks (historical checkpoint)

The runtime is Lean 4.34.0-rc2. The actual build uses mathlib commit
`4cbb42e75a050e830b7cf0f2ae748d7644f59cf7`; the relevant API signatures were
rechecked against that source after setup.

- `HilbertOverlap.lean` passed its first compiler check and its subsequent Lake
  build. It has benign unused-variable and unused-simp-argument linter warnings.
- `GLRetraction.lean` passed after corrections to API names and explicit subtype
  and extended-norm coercions; none of its mathematical claims were weakened.
  Its Lake build succeeded, with one benign `letI` style warning.
- `TheoremStatement.lean` checked and built with no warnings. It imports the
  separately compiled `AmbientSeparable.lean`.
- `HilbertOverlapAudit.lean` checked axiom dependencies of the synthesis bound,
  paired-column bound, circle-map self-adjointness, exact single-circle 5/8
  identity, and single-circle paired bound.
- `GLRetractionAudit.lean` checked the retraction construction, local-infimum
  inequality, global-constant inequality, and projection-range norm estimate.

Every audited proof depends only on `propext`, `Classical.choice`, and
`Quot.sound`. No `sorryAx` or added mathematical axiom appears in those audits.

`RealMainTheoremStatement` defines the proposition subsequently proved by
`realMainTheorem` in `RealMainTheorem.lean`. It includes actual Banach-lattice
order axioms and all four range/dual conclusions, and asks for uniform
convexity as the stronger property of the paper's constructed ambient space.
The corollary uses the explicit `IsSuperreflexiveByRenorming` characterization;
no equivalence with finite representability is assumed as an axiom.

## Final review of the ambient lattice and comparison arguments

At the final review, `AmbientLattice.lean`, `DPRtoGL.lean`, and
`TheoremStatement.lean` were reread against their actual definitions and
hypotheses. No mathematical defect was found.

`AmbientLattice.lean` adds coordinate `LE`, `LT`, `Max`, `Min`, and `Lattice`
instances, followed by ordered-addition, positive-scalar monotonicity, and
solid-norm properties. It declares no new `Norm`, `NormedAddCommGroup`,
`NormedSpace`, or metric instance. Thus the finite counting `PiLp` norms and
the existing dependent `lp` norm are retained. Suprema and infima belong to
the dependent sum because their fiber norms are dominated by the sum of the
two original fiber norms. Norm solidity is then proved using those original
finite-product formulas and `lp.norm_mono`.

The `DPRtoGL.lean` renorming is an explicit auxiliary `Seminorm` value, not a
replacement norm instance on the original ambient space or its subspaces.
The identity multiplier gives the lower bound by the original norm. The
unconditional-constant bound gives the upper bound and ensures that the
suprema used in the renorming are bounded. The constructed GL factorization
has certified bounds `C` and `1`. Its use of the exact constant of a FIXED
basis is valid, while the subsequent infima over all bases and superspaces
require no optimal witness. The infinity case is handled separately.

The final target retains the existing scalar multiplication, complete metric,
range norms, and dual operator norms. It quantifies an actual projection with
both strict norm bounds and all four local-structure separations. There is
no vacuous replacement of an existence assertion by a conditional theorem,
and no hidden assumption of the main result. The recursive parameter choice,
exceptional projection, and all four range/dual DPR obstructions are proved
and assembled in `RealMainTheorem.lean`.

The terminology boundary remains explicit: the main target uses uniform
convexity, and the corollary uses uniformly convex renormability. For the GL
step, `chiGL_range_le_projection_norm` correctly retains `chiGL X <= 1` as an
input to that generic lemma. `AmbientFiniteApproximation.lean` proves this
input and its ambient-dual counterpart for the actual constructed space;
the final main theorem has no remaining ambient GL hypothesis.

The final real main theorem, real corollary, and separable nonprimarity
statement have compiled and passed transitive axiom audits. Their proof bodies
are in `RealMainTheorem.lean` and `RealMainConsequences.lean`; the separate
complex corollary proof is in `ComplexCorollary.lean`. This review and
`MainTheoremReview.lean` explain those statements rather than replace the proofs.

## Final finite-basis convention correction

The manuscript counts finite bases as well as ℕ-indexed bases. The corollary
predicate `HasUnconditionalSchauderBasis` has been corrected to include both.
Its finite case includes `Fin 0`, so a zero or finite-dimensional range cannot
qualify merely by lacking an infinite sequence of basis vectors. The real and
complex negative-basis proofs use their existing arbitrary-index DPR lemmas
in each case. The final `verification/fresh-root-build.log` checks the corrected
definition and proofs; earlier individual corollary logs predate this correction.
The real main theorem's GL/DPR statement and standalone definitions are unchanged.
